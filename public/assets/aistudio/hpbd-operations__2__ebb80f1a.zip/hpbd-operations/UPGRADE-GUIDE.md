# Upgrade 1.4.1 →1.5.0

Backup database and current plugin. Upload this ZIP and select **Replace current with uploaded**. Keep the existing folder slug `hpbd-operations`. Do not delete/uninstall. Clear application/page caches and open fresh workspace tabs. No current data is reset. The points journal is installed additively on init.

Open Complaints / Issues as manager. The main list has no default date or owner filter for managers. Older issue records are visible directly below. Use Find older issues to convert legacy order notes/statuses, task Issue records and work Issue records into shared complaints; follow each next-batch link. Import does not silently resolve the original workflows.

Use Staff messages, My profile and Points / Rankboard. Username changes require the current password and use the new login thereafter; the account ID remains unchanged. Points start with post-update activity. Manager Reconcile can backfill attributed existing Woo orders,50 per page; it does not infer historical task actors.

Verify a non-production order and known roles on your host before ordinary use. This deliverable was tested locally; it has not been installed on healthpointbd.com.
