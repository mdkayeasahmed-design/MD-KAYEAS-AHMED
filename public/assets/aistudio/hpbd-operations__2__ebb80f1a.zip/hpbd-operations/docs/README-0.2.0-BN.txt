HEALTH POINT BD OPERATIONS — 0.2.0
পরীক্ষার সংস্করণ; সম্পূর্ণ production automation নয়।

আপডেট করবেন যেভাবে
১. পরীক্ষার WordPress-এ Plugins > Add New Plugin > Upload Plugin।
২. hpbd-operations-0.2.0.zip নির্বাচন করে Install Now চাপুন।
৩. একই plugin আগে থাকলে Replace current with uploaded চাপুন। পুরোনো plugin Delete করবেন না।
৪. প্রয়োজন হলে Activate করুন। HPBD Operations খুলুন।
৫. আগের HP-TEST অর্ডার এবং নতুন Edit/Filter/Website orders/Inbox/সংযোগ ট্যাব পরীক্ষা করুন।
ZIP-এর মূল folder আগের মতো hpbd-operations; আলাদা duplicate plugin নয়।
আগের hpbd_ops_record, hpbd_ metadata ও পেজ ID অপরিবর্তিত। পুরোনো অন্যান্য plugin-এর code/data পরিবর্তন হয় না। তবে তাদের সঙ্গে compatibility পরীক্ষা প্রয়োজন।

কাজ করে
- বিদ্যমান server-side login ও staff/manager permission
- নতুন অর্ডার, তথ্য Edit, status, customization-এর হুবহু লেখা
- NP/Embroidery/Engraving একাধিক নির্বাচন ও আলাদা তালিকা
- Search: নাম, ফোন, reference, পণ্য; Source, Status, Priority, date filters
- Urgent, দায়িত্বপ্রাপ্ত কর্মী, internal note, issue
- Manager-only amount reduction এবং অনুমোদনের checkbox দিয়ে CSV export
- CSV-তে New Order-এর পাঁচ কলাম; customization lists-এ পাঁচটি প্রাসঙ্গিক কলাম
- 1000-এর বেশি result হলে export বন্ধ; তারিখ ছোট করতে হবে (নীরবে বাদ দেয় না)
- নতুন অর্ডার form double submission আটকানো
- কে কখন কোন field পরিবর্তন করেছেন তার history (পুরোনো value snapshot নয়)
- WooCommerce-এর একই site-এর orders, product catalog, price/stock/variant link দেখা
- External bridge-এর signed incoming message/receipt, Inbox, manual reply requests
- Secrets encrypted; signature/timestamp/size validation; unique event deduplication

WooCommerce-এর গুরুত্বপূর্ণ সীমা
Website orders আলাদা read-only tab। Operations অর্ডার WooCommerce-এ তৈরি হয় না, আর WooCommerce order থেকে নিজে নিজে Operations record হয় না। একই সাইটে data API দিয়ে পড়ে; test site-এ healthpointbd.com-এর data আসে না। কোনো order/payment/stock পরিবর্তন করা হয় না। HPOS-friendly APIs ব্যবহার হয়েছে, কিন্তু actual store-এ HPOS/legacy উভয় mode পরীক্ষা হয়নি।

কর্মী তৈরি
Users > Add New > HPBD Operations Staff অথবা HPBD Operations Manager role দিন। Existing user-এর role বদলালে আগের role-এর ক্ষমতা হারাতে পারেন; নতুন কর্মী account সুবিধাজনক। Administrator access পাবেন। Public customer registration কোনো staff permission দেয় না।
Frontend: সেটআপ > Open Operations। /hpbd-operations/ সাধারণ URL; আগের slug conflict হলে WordPress-এর তৈরি URL ব্যবহার করুন। Hosting/CDN cache-এ এই URL exclude করতে হবে।

সংযোগের সত্যিকারের অবস্থা
এখানে সরাসরি Meta, WhatsApp Cloud API, bKash, Nagad বা Pathao adapter নেই। Generic bridge protocol আছে। একটি আলাদা provider-specific bridge service সেই platform-এর authentication, webhook verification, user consent, message window, templates, idempotency এবং API errors সামলাবে। এই plugin-এর HMAC endpoint সরাসরি Meta-তে webhook URL হিসেবে দিলে কাজ করবে না।
Connections-এ endpoint/secret বসানোকে verified integration বলা হয় না। Enabled মানে bridge request গ্রহণের অনুমতি দেওয়া হয়েছে। সফল end-to-end test না করা পর্যন্ত provider সংযুক্ত হয়েছে দাবি করবেন না।
Payment/courier receipt সবসময় review_required। এটি verified payment বা booked courier নয়। Reply-এর bridge_accepted মানে bridge গ্রহণ করেছে, delivered নয়। timeout/অস্পষ্ট response হলে unknown; provider result না দেখে পুনরায় পাঠাবেন না। কোনো automatic retry নেই।

এখনও বাকি
Native provider adapters ও account approvals; WooCommerce দুইদিকে sync; payment verification ও advance rules; stock reservation; chat-order confirmation automation; website ordinary order auto-confirm; AI answer/image/voice; comment-to-DM; staff availability/routing ও 30-minute timers; customization preview consent; Pathao booking; notification/fallback/marketing consent; return/exchange workflow; PDF/Word export; dashboard financial/staff reports; backups/import।

পরীক্ষা
১. পুরোনো order দেখুন। Edit দিয়ে নোট/Urgent/কর্মী দিন; Reload করে দেখুন।
২. NP+Engraving একসঙ্গে নতুন নমুনা order দিয়ে দুটো tab দেখুন।
৩. Search, date/source/status filters এবং approved CSV মিলিয়ে দেখুন।
৪. staff account দিয়ে amount কমানো ও Connections পরিবর্তন blocked কি না দেখুন।
৫. private/incognito browser এবং customer account-এ portal data না দেখানো নিশ্চিত করুন।
৬. Website orders/catalog-এ test WooCommerce data মিলিয়ে দেখুন।
৭. bridge contract অনুযায়ী signed test message পাঠিয়ে Inbox দেখুন; পরিবর্তিত body/পুরোনো timestamp প্রত্যাখ্যাত হয় কি না দেখুন।
৮. provider sandbox-এ reply test করে provider delivery status আলাদাভাবে মিলিয়ে নিন।

যাচাইয়ের সীমা
PHP 8.3 WebAssembly runtime-এ WordPress stubs দিয়ে unit tests হয়েছে। সম্পূর্ণ WordPress/WooCommerce installation বা আপনার custom plugin-গুলোর সঙ্গে end-to-end পরীক্ষা হয়নি। API credentials দেওয়া হয়নি; বাস্তব provider delivery/payment/courier পরীক্ষা হয়নি। প্রথমে নমুনা তথ্য দিয়ে ব্যবহার করুন।
