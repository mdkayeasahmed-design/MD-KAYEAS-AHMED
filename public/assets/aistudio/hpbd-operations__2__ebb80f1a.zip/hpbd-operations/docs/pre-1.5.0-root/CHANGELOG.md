Health Point BD Operations1.4.1 - Reviewed workflow corrections
25 October2026, Bangladesh. Base1.4.0. Developer: Md Kayeas Ahmed /01929779381.

Current fixes
1. Billing contact and delivery destination remain distinct. A separate original billing address stays intact; a different shipping recipient, including a blank recipient surname, and separate shipping phone are retained. The same address transformation now runs during quote/build and save, so billing-based taxes match the approved quote. Tax-exempt and explicitly foreign-destination orders require a reviewed financial/country workflow instead of silent repricing or country conversion.
2. Configured optional non-production item fields are seeded and saved. Unknown private provider item metadata blocks product replacement rather than being discarded. The protection runs in seed, quote and apply; skipping the UI cannot bypass it. Original ThemeComplete text/option pricing support from1.4.0 retained; unsupported provider uploads still require review.
3. Order revision fingerprints now include product/variation IDs, subtotals, tax class and complete raw item metadata in addition to existing fields. Independent metadata edits invalidate stale previews. Status updates return a fresh saved-order revision after native/plugin status callbacks.
4. Daily-work completion validates each current product customization against a completed exact-source task. One completed task in a queue cannot stand in for another item's unfinished/missing task; changed source text and superseded tasks cannot approve current work.
5. Customization completion and daily-work updates share the order-edit lock. Work cannot be completed concurrently while that order is being replaced through the reviewed editor.
6. Native completed orders no longer create a fresh Queued daily-work record. Existing work history still receives native status events. Existing records are retained for review; no history is deleted or guessed complete.
7. Moderator issue creation verifies exact own WooCommerce order ownership before private order/provider fields are parsed. Unlinked private Operations records cannot bypass this scope. Assigned issues remain accessible to their authorized owner/assignee.
8. Existing-order work imports use stable ascending native Order ID order, so newly arriving orders at the end do not shift earlier date-ordered pages. New orders still enter automatically; historical import remains reviewed50-order pages.

Retained1.4.0 features
Selected-only C codes; no/none/empty defaults excluded; same-ID product/customer editor with price/shipping/provider validation; automatic daily work/customization source tasks; assigned issues and stock-shortage/order notes; named actor history; persistent personal notifications with seen/archive/action links; delivery print/invoice access and invoice-to-issue link; frontend team setup/search; inventory supplier/purchase cost/stock-in/out/adjustment journal. Original logo and print CSS/design/25-30-35 density unchanged.

Current validation
PHP8.3 syntax33 files; JavaScript syntax11 files.
Native workflow/regression77 HPOS +77 legacy; includes per-item task completion, locking, private metadata, optional text retention, billing/recipient preservation, native tax calculation, stale raw metadata and ownership-before-provider-parsing checks.
Native print/activity regressions120 per storage mode.
Provider/smart-entry backend53 per mode +UI17 per mode.
WordPress AJAX/JSDOM workflow62; editor/issue/seen UI13; print DOM29; variant picker2; focused negative-selector tests4.
Total644 behavioral assertions; full expected completion markers verified. Synthetic status-hook metadata test verifies the returned revision and a subsequent update. Native stock reduction/restock and same-order edit balances are tested in the workflow suite. A managed-stock confirmation fixture reached WooCommerce's stock-reservation rejection in isolated SQLite staging; production MySQL reservation SQL/concurrent traffic was not verified. The existing native reservation guard is retained; do not infer that production reservation is verified from these passing stock-balance tests.
No new print-layout authoring in1.4.1; prior1.4.0 visual/A4 evidence is historical, with identical print assets. JSDOM is not a physical browser/device/printer or HTTP transport test. No real SMS/mail/external message, production stock write or live installation performed. This fixes identified cases and does not certify every possible hosting/provider issue.

Install
Back up database/current plugin; upload hpbd-operations-1.4.1.zip and choose Replace current with uploaded. Do not delete/uninstall. Clear asset caches and reopen old portal tabs; old edit previews must be recalculated because revision verification improved. Review the store's actual provider mappings and managed-stock confirmation on staging before live use. Existing SQL schema remains0.10.0; no data reset or migration. New records and logs from1.4.0 retained.
Rollback: replace code with saved1.4.0 ZIP. Code rollback does not reverse orders, stock or other live data changes. Use the database backup for data rollback.

Known scope retained
Paid/refunded/discounted/custom-fee/multiple-package/courier-booked orders need financial/provider review before product replacement. Inventory is one native Woo stock balance; store labels are descriptive rather than per-warehouse quantities. Receipt costs are a journal, not an accounting payable/profit/tax engine. Issue/status notifications are persistent in-app records, not WhatsApp/SMS/push alerts. Source task preparation depends on normal WordPress shutdown/cron execution; interrupted submission markers require review rather than blind retries.
