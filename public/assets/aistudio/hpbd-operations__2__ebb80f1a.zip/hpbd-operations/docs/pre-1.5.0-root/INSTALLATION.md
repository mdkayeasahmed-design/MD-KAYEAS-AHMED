# Install 0.10.0

Back up first. WordPress → Plugins → Add New → Upload `hpbd-operations-0.10.0.zip` → **Replace current with uploaded**. Do not Delete/Uninstall. Same existing shortcode `[hpbd_operations]`, plugin directory and private portal URL.

Reload portal tabs. Assign dedicated staff roles through existing Team & Permissions / WordPress Users as an authorized Administrator. Select Classic in Interface preset only if you want the previous stored theme. Verify physical order creation, actual fields/shipping/payment and delivery-to-customization handoff on staging before the main site. Detailed target checks and rollback are included.
