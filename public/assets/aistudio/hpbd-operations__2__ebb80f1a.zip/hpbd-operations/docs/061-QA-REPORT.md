# HPBD Operations 0.6.1 — executed QA and release gates

Date: 23 October 2026 (Asia/Dhaka). Baseline: unchanged 0.6.0 ZIP, SHA256 `58345de07fad6d3f12c8c8b89c7b9f01dafdc55adc6b50a5e442a133fd3bc56e`. Installable incremental **staging candidate**. No main-site change or production order/message/booking was made.

## Executed checks against 0.6.1

| Suite | Result |
| --- | --- |
| Original/manual/bridge/Pathao stub regressions | **81 passed**, retaining the original regression behaviors. |
| Real WP/Woo core/order/tax/shipping/export/auth/routing and historical upgrade paths | **260 passed**. Includes original 0.2.0 and earlier incremental release preservation, HPOS and legacy storage, SQLite integrity. |
| Actual supplied provider classes and Meta diagnostics | **138 passed**, 49 provider + 20 Meta checks per storage mode. |
| Earlier feature acceptance and 0.5.5 → current preservation | **224 passed**: 15 preservation + 93 feature + 4 AJAX checks per mode. Historical fixture names remain 060, but runner mounts current 0.6.1. |
| New 0.6.0 → 0.6.1 preservation / production preparation | **138 passed**, 69 per mode. Existing options/meta/IDs retained; exact text, explicit queues, canonical aliases, existing/completed/native-seeded tasks, invalid/empty/private references, stale task/source previews, authorization, closed-order/manual-rework limits and partial-write safety. |
| New actual WP AJAX preview / prepare | **10 passed**, 5 per mode. Guest denial, forged nonce, authenticated preview, reviewed creation and same-ID retry response. |
| Combined assertions | **851 passed** = 81 stub + **770 within real WordPress/WooCommerce**, some external responses mocked. These are not browser or provider delivery tests. |
| PHP syntax | **20 runtime PHP files passed** under PHP 8.3 token parser. |
| JavaScript syntax | **4 sources passed**: workspace.js, pathao.js, refresh.js and extracted inline theme/navigation code. |
| Preservation | All **121** baseline file paths remain. Original production, order, integration, provider, ThemeComplete, Pathao and order-tools runtime modules plus logo/bridge contract are byte-identical. See docs/FILE-PRESERVATION-061.json. |
| ZIP validation | Same plugin directory/main file, unique safe paths, no symlinks, CRC and packaged-byte checks required before distribution; no provider source bundled. |

Environment: actual WordPress **6.8.3**, WooCommerce **10.2.2**, PHP-WASM **8.3**, @php-wasm **3.1.54**, separate SQLite databases with HPOS and legacy order storage. Woo CRUD is real in integration suites. Source files, raw results and suite runners are included under docs/; test code is stored as non-executable `.txt` in the plugin package. Current suites mount 0.6.1; older labels in fixtures identify their origin, not the code tested.

Production-specific failures include an intentionally injected second-task insert error. The helper retains the first task ID and unresolved marker; repeat submissions cannot silently replay the batch. Review does not change order stock/native status or send Woo email. Native checkout seeding cannot duplicate a reviewed field task. Existing manual task editors are retained; this helper does not prohibit deliberately separate manual work.

## Dependencies and remaining gates

- No browser executable was available. Actual preview selection/keyboard/mobile interaction, screen contrast, print page density/Bangla fonts, browser PDF and real multipart upload/download still require target-site staging checks. PHP HTML and JS syntax validation do not replace them.
- Local real Woo tests use SQLite. Target MySQL managed-stock reservation and concurrent create/update/checkout/import remain **BLOCKED** for production readiness; unsupported reservation SQL fails closed. This increment adds no stock writes. The preview is checked at submission, not a database-wide freeze against unrelated manual editors.
- Actual account/API delivery remains **BLOCKED** for Pathao, Meta, SMS, payment and AI. Reviewed provider classes/hook paths are exercised locally with external HTTP and mail intercepted. No real merchant booking, paid AI call, customer SMS/email or remote Meta sync was performed. Unknown provider versions require review.
- Inherited provider versions: ThemeComplete 6.5; Pathao 2.1.1 (local structural/source checks); Meta for WooCommerce 3.7.8; Alpha SMS 1.0.19; WPC size chart 2.3.5; City Select 1.0.10 + supplied BD filter 0.1.0; city shipping 1.0.3; Pre-Orders 2.3.1; BP custom status 2.1. Existing reviewed adapters remain unchanged; detecting them does not establish account delivery.
- Only explicit field production mappings are imported. Variations, product titles or unknown metadata are not guessed. Shared Operations text is copied exactly to each approved queue, with warning. Text held only on a linked Operations record, untraced edited manual tasks, complex unsupported provider fields and intentional rework require manual review.
- New tasks default to Queued/Unassigned; assignment remains in the original editor. No bulk historical backfill or automatic retry. The helper does not alter Woo status/stock, notify customers or book couriers.
- The broader master roadmap is still **PARTIAL**: full chat automation, broadcasts/reminders/feedback schedules, payment verification, design previews, complete refund/discount UI and arbitrary two-way customer/product edits are not completed by this increment.
- Main-site backup restoration/deployment and all-site plugin compatibility were not performed. Use the upgrade/rollback guides and actual test-site validation before rollout.

Original 0.6.0 QA with detailed inherited AI/notification boundaries is archived at docs/060-QA-REPORT.md. Current feature statuses: FEATURE-CHECKLIST.md. Workflow: PRODUCTION-REVIEW-061.md.
