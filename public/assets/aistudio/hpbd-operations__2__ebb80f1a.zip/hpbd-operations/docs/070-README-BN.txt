HEALTH POINT BD OPERATIONS 0.7.0
ইনস্টলযোগ্য in-place update; পূর্ণ production অনুমোদন নয়।

আগের plugin directory, shortcode [hpbd_operations], dashboard URL, roles,
permissions, database, original forms এবং bridge contracts রাখা হয়েছে।

এই আপডেট:
- নতুন অর্ডার: WooCommerce product search, actual variants ও website option fields,
  multiple items, shipping preview এবং reviewed Pending order creation। একই preview
  আবার submit করলে একই অর্ডার ফেরত দেয়। Original Operations-only form লিংকে আছে।
- প্রতিটি item-এর আলাদা optional Staff NP/Embroidery/Engraving instruction। বানান,
  বাংলা, newline এবং backslash অপরিবর্তিত। এই instruction নিজে কোনো fee যোগ করে না;
  paid customization-এর জন্য configured website option নির্বাচন করতে হবে।
- All Orders Quick view drawer-এ original form ও তার handler বজায় থাকে।
- Compact/Comfortable toggle, কম spacing, responsive 3-column product catalog,
  optional form details collapsed, সহজ task cards-এ product label।
- All Orders: incomplete index হলে direct WooCommerce + Operations fallback।
  Indexed history ও direct view আলাদা বেছে নেওয়া যায়; 25/50/100 rows।
- Daily print default: direct current WooCommerce + Operations, canonical dedup,
  A4 25/30 density target; long instructions সম্পূর্ণ থাকে। CSV/XLSX আগের মতো।
- Portal খোলা অবস্থায় nonced bounded index worker; WP-Cron আটকালেও Sync/Resume।
  Complete হলে আবার শুরু হয় না; list দেখতে reload করুন।
- Connection center: existing setup-এ যাওয়ার সহজ লিংক ও সঠিক dependency information।
  এটি native Messenger/WhatsApp login service নয়।

সীমা:
Direct view-তে প্রতিটি origin সর্বোচ্চ 500 candidates এবং মোট 500 distinct orders;
বেশি হলে date range ছোট করতে হবে। Print batch সর্বোচ্চ 100 matching orders।
কোনো order silently বাদ দিয়ে partial batch দেখানো হয় না। পুরোনো বড় history-এর জন্য
indexed view ও index backfill ব্যবহার করুন। Index worker প্রতি run-এ সর্বোচ্চ
100 pages; প্রয়োজন হলে Resume। Customization-এর direct Woo view আগের মতো আছে।

Messenger/WhatsApp auto-login, পূর্ণ customer chat automation, real SMS delivery,
Pathao merchant booking এবং target-host compatibility এখনো production-verified নয়।
AI order suggestions-এর জন্য নিজের configured provider প্রয়োজন। এই upgrade কোনো
বাস্তব message, booking বা payment পাঠিয়ে পরীক্ষা করা হয়নি।

প্রথমে backup নিয়ে test/staging site-এ পরীক্ষা করুন। প্রয়োজনীয় target-host gates
TEST-REPORT.txt এবং FEATURE-CHECKLIST.md-তে দেওয়া আছে।
