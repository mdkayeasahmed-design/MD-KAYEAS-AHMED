# 0.5.5 → 0.6.0 preservation plan
Source ZIP SHA256: a1a3eab4591b3561ac30d3baa00c15e57853a50c33938c1b9fad055bb9664571.
All 85 source files were read/digested before modification; binary logo visually inspected.
Keep every shipped path; no delete/reset/uninstall operation, provider credentials, existing roles, shortcode, page ID, original status names or channel contracts changed.
Add independent modules for Dhaka display/settings/index health, canonical unified order control, optional signed AI suggestions, task views and read-only Meta catalog diagnostics.
Existing update/create validation, Woo CRUD/stock reservation, quote fingerprints and unknown courier locks remain authoritative.
Options: new hpbd_ops_release_settings and hpbd_ops_release_schema only, schema version 1. No bulk data migration. Existing options are not rewritten during activation.
Index created timestamps standardized to UTC through incremental rebuild. Display and day boundaries explicitly Asia/Dhaka. Old audit rows retain original time; unknown source timezone labelled rather than guessed.
Production keeps task IDs, metadata, exact instructions and revision locks. New board/table renders existing tasks.
Print adds density/column sizing without trimming text; no guaranteed rows per page for arbitrarily long contents.
Deploy to isolated WordPress/WooCommerce test environment, run original regression suite and new acceptance tests, report provider/browser/MySQL gates separately.
Rollback: replace plugin files using original 0.5.5 ZIP, retain all data; restore database only from a reviewed full backup with newer orders reconciled.

AI connection includes optional direct OpenAI with encrypted own API key, bounded structured output and no automatic actions; disabled by default. Original signed bridge contracts stay unchanged.
