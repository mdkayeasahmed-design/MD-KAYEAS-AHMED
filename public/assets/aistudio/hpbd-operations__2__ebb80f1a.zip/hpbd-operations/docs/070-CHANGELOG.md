# 0.7.0

See CHANGELOG.txt for this release, FEATURE-CHECKLIST.md for the exact delivery status and docs/062-CHANGELOG.md for the previous release.
