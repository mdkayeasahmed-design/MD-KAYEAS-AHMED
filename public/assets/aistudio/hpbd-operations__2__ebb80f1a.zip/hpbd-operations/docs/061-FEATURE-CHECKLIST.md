# HPBD Operations 0.6.1 — incremental release checklist

Baseline: previous working 0.6.0. All 121 original paths remain. This is an installable staging candidate; the full master roadmap is not claimed complete.

| Update | Status | Scope / verification |
| --- | --- | --- |
| Reviewed task preparation from existing orders | IMPLEMENTED / TESTED | Explicit Woo field mappings or Operations custom queues; exact text, selected fields, optional due date, staff approval; real WP/Woo HPOS and legacy tests. |
| Existing task and native seed protection | IMPLEMENTED / TESTED | Canonical linked aliases, Completed tasks, durable request IDs, native checkout field seeds, stale preview rejection and partial-write inspection. Deliberate unrelated manual tasks are still permitted. |
| Task → canonical order links | IMPLEMENTED / TESTED | Original display order ID; unavailable private records show no link; permission guarded. |
| Original data/settings/authentication/integrations | PRESERVED / TESTED | Actual 0.6.0 → 0.6.1 fixtures plus older regression upgrade paths. No schema reset, secret changes, automatic history import or provider calls. |
| Shared or unsupported customization | PARTIAL | Shared Operations text must be reviewed; linked-record-only text, unmapped variants and untraced edited tasks require manual reconciliation. No guessed mappings. |
| Browser/mobile and production database validation | BLOCKED | PHP render and JS syntax checked; actual browser interaction/printing, multipart uploads and target MySQL concurrency not run. |
| Live Pathao/Meta/SMS/payment/AI delivery | BLOCKED / unchanged | Existing adapters retained. Credentials/accounts, target staging validation and explicit approval for live actions are still required. |

Use PRODUCTION-REVIEW-061.md for the workflow. The inherited 0.6.0 feature checklist below remains applicable except that current release is 0.6.1.

---

# HPBD Operations 0.6.0 — feature and release checklist

Baseline: user-supplied **0.5.5**, upgraded in place. This is an installable **staging candidate**, not completion of the full omnichannel master roadmap. IMPLEMENTED describes code, TESTED describes executed checks, PARTIAL describes scope limits, BLOCKED describes dependencies/gates not verified. A feature can be implemented and still have an operational gate.

| Area | Status | Evidence / remaining requirement |
| --- | --- | --- |
| Same plugin identity, directory, main file, shortcode, dashboard URL/page ID and roles/caps | IMPLEMENTED / TESTED | Original files retained; actual 0.5.5 → 0.6.0 preservation in HPOS and legacy storage. No delete/reset migration. |
| Existing Operations records, exact customization, tasks, original settings, encrypted bridge and provider options | TESTED | Real upgrade fixtures compare old metadata/options/IDs; additive migration repeat is idempotent. |
| Existing manual new/edit/status, NP/Embroidery/Engraving lists, filters, CSV, catalog, inbox, help and signed bridges | IMPLEMENTED / TESTED | Regression suite retained. Original all-Operations list/filter/CSV reachable through “Original Operations list & CSV”. |
| Actual logo retained; extra HP mark removed | IMPLEMENTED / TESTED | Logo bytes identical; rendered private screens contain no duplicate mark. |
| Green branding and contrast repairs, retained light/dark/system/theme/mobile settings | IMPLEMENTED / PARTIAL | CSS, JS syntax and actual PHP render checked. Visual browser/mobile/keyboard QA remains BLOCKED. Accent settings retained; readable text color computed for chosen action color. |
| Asia/Dhaka AM/PM for index, global search, order history and inbox; local day filters | IMPLEMENTED / TESTED | Explicit UTC conversion/boundary checks. Original timestamps and WordPress global timezone retained. Legacy source timezone must match historical site configuration. |
| Index health, actual errors, schedule status, manager restart | IMPLEMENTED / TESTED | `cycle complete` is treated as state, not an error. Raw JSON only under technical details. WP-Cron must run. |
| Combined All Orders and canonical linked-order counting | IMPLEMENTED / TESTED | Actual Woo + Operations rows; explicit link resolves to Woo ID; links/tasks retained. List/count depend on local index freshness. |
| Guarded Woo/Operations status updates and linked-record reflection | IMPLEMENTED / TESTED / PARTIAL | Explicit mappings, revisions/locks, paid/COD checks, native event count; independent production/fulfillment. Conflicting native changes flagged, not blindly rewritten. Arbitrary cross-record customer/product synchronization is not included. |
| Production board + list, queue/status/mine/overdue/text filters, order lookup, quick progress, details/history | IMPLEMENTED / TESTED / PARTIAL | Real task saves, preserved original metadata, stale rejection and duplicate-token protection. Counts per page labelled; no drag/drop dependency. Browser interaction QA BLOCKED. |
| Existing AJAX product search, multi-line Woo entry, exact website variants and configured product fields | IMPLEMENTED / TESTED | Actual Woo/ThemeComplete tests: price, choices, conditional fields, quantity, exact Unicode/slashes, tax/shipping, previews and idempotency. Complex unsupported provider rules fail closed. |
| AI optional, manual/local parser still works | IMPLEMENTED / TESTED | Disabled by default; no automatic customer messages/orders; editable, explicitly reviewed suggestions only. |
| Direct OpenAI API key connection | IMPLEMENTED / TESTED with mocked HTTP / BLOCKED for actual account | Encrypted manager-only key; strict schema/source evidence; bounded output; refusals/quota/truncation handled. Own paid API account/model access and staging smoke test required. No paid call made. |
| Signed AI bridge alternative | IMPLEMENTED / TESTED with mocked HTTP / BLOCKED for actual service | Signed request and response, correlation, consent, input/rate limits; external bridge implementing AI-BRIDGE-CONTRACT.md required. |
| Daily print no hover/moving controls, compact New Order columns, 25 default / 30 option | IMPLEMENTED / TESTED structurally / PARTIAL | Product column 51% on screen / 58% in print; Include screen-only; full text retained. Real A4/Bangla/page-density testing on user's printer/browser BLOCKED. Long rows flow to additional pages. |
| All inherited print lists, selected canonical batches, CSV/XLSX, order slips/invoices/labels | IMPLEMENTED / TESTED / PARTIAL | Real dataset, exact IDs, reviewed exports, valid XLSX tested. PDF uses browser Print/Save PDF; server PDF generator, certified invoice/provider labels not supplied. |
| Pathao existing plugin reuse | IMPLEMENTED / TESTED structurally / BLOCKED for merchant end-to-end | Original reviewed 2.1.1 adapter retained byte-for-byte, credentials reused, unknown booking locks retained. No real/sandbox booking made. |
| Meta for WooCommerce catalog diagnostics | IMPLEMENTED / TESTED / PARTIAL | Actual supplied 3.7.8 provider in both Woo storage modes: connection facts, eligibility, price inputs, variants and saved IDs. No token disclosure, second sync or Pixel/Purchase event. Remote approval/account state unverified. |
| Existing Alpha SMS / Woo transactional notifications | IMPLEMENTED hook path / TESTED local events / BLOCKED for delivery | Normal Woo events once; no additional HPBD SMS send. Operations-only, packing and task-specific messages require extra provider rules/adapters. |
| Other supplied providers | TESTED within inherited bounds / PARTIAL | Size chart 2.3.5; WC City Select 1.0.10 + supplied BD filter; city shipping 1.0.3; ThemeComplete 6.5. Pre-order split/schedule/payment and unknown custom status meanings remain native/provider workflows. |
| Permission, nonces, encrypted secrets, HMAC, XSS/SQL and duplicate safeguards | IMPLEMENTED / TESTED within stated scope | 81 stub regressions, real permission/nonce/oversize cases, evidence/signature validation. No claim of formal penetration certification. |
| MySQL managed-stock/concurrency and real HTTP multipart uploads | BLOCKED | Local tests use real WordPress/WooCommerce with SQLite under PHP-WASM. Unsupported reservation SQL fails closed. Target MySQL staging and browser uploads required. |
| Full chat automation, broadcasts, reminders, feedback scheduling, payment verification, design preview approvals, full refunds/discount UI | PARTIAL / NOT IMPLEMENTED in this increment | Existing bridges/native authorized editors remain. This ZIP is not a claim that the entire original ten-feature roadmap is complete. |

Read QA-REPORT.md, STATUS-SYNC-060.md, AI-BRIDGE-CONTRACT.md, UPGRADE-GUIDE.md and ROLLBACK-GUIDE.md before staging installation. Target-site verification is required before main-store rollout.
