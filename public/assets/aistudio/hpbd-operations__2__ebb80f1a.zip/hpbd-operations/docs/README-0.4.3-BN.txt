HPBD Operations 0.4.3 — বাংলা সেটআপ নির্দেশিকা

গুরুত্বপূর্ণ: এটি বিদ্যমান Health Point BD Operations প্লাগইনের visual/responsive upgrade। এটি পুরো master roadmap-এর সব feature সম্পূর্ণ করে না। প্রথমে staging সাইটে পরীক্ষা করুন।

ইনস্টল
1. WordPress ও WooCommerce-এর ব্যাকআপ নিন—database এবং wp-content/files দুটোই।
2. সম্ভব হলে staging copy-তে পরীক্ষা করুন।
3. WordPress Admin → Plugins → Add New Plugin → Upload Plugin-এ ZIP আপলোড করুন।
4. একই plugin folder/identity `hpbd-operations`-এর upgrade হিসেবে ইনস্টল করুন। Duplicate folder বা দ্বিতীয় কপি সক্রিয় করবেন না। WordPress যদি overwrite/replace নিশ্চিত করতে বলে, সঠিক existing plugin নির্বাচন করে তবেই এগোন।
5. Activate/upgrade-এর পর HPBD Operations পেজ খুলে login ও role permission যাচাই করুন।
6. পুরোনো order, search, production queue, print center, settings ও diagnostics দেখুন। WooCommerce order status/payment/stock বাস্তব staging order-এ যাচাই করুন।
7. CSS cache থাকলে browser cache clear করে আবার দেখুন।

নিরাপত্তা
- Live site-এ দেওয়ার আগে backup restore প্রক্রিয়া পরীক্ষা করুন।
- API key বা merchant secret সাধারণ staff-কে দেবেন না।
- Courier/Meta/WhatsApp/AI/payment integration-কে Connected ধরে নেবেন না; Settings/Diagnostics-এ বাস্তব credential ও provider test দরকার।
- Timeout/unknown courier booking হলে যাচাই ছাড়া আবার booking করবেন না।
- Production data delete/reset করার কোনো ধাপ এই upgrade-এ নেই।

এই build-এ যা বদলেছে
- Version 0.4.3.
- Teal/blue + navy responsive visual refinement.
- Mobile navigation overflow, narrow-screen form layout, focus outline এবং touch target refinement.
- Database schema বা order business logic-এ নতুন destructive migration নেই।

যা এখনো নিশ্চিত নয়
- এই package-এ live WordPress browser QA, actual courier API, real AI request, Meta/WhatsApp sending, payment verification, SMS, production printing ও MySQL concurrency পরীক্ষা করা হয়নি।
- পূর্ণ feature/QA সীমাবদ্ধতা `docs/0.4.3-QA-REPORT.txt` এবং `FEATURE-CHECKLIST.md`-এ আছে।
