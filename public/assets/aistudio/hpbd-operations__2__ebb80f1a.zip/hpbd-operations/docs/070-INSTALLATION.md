# Installation

Use UPGRADE-GUIDE.md. This is an in-place plugin update. Do not uninstall or reset. Target-host staging acceptance is required before main-store rollout. Read TEST-REPORT.txt and FEATURE-CHECKLIST.md.
