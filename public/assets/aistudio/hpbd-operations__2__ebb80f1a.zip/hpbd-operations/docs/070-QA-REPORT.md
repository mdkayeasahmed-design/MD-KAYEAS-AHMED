# Current release quality status

Use TEST-REPORT.txt for the measured 0.7.0 results. Historical reports under docs describe their own versions and do not certify 0.7.0 or the live store. See FEATURE-CHECKLIST.md for unimplemented, partial and blocked items.
