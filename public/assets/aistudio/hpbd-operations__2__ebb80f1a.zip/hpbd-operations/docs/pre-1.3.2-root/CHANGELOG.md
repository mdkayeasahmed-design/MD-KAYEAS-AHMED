HPBD Operations 1.2.7 - Centered print identity and tighter column spacing

HEALTH POINT BD is centered, uppercase, larger and bold, with the exact existing address/phones centered below it. Original logo retained. Daily customer/date/C columns narrowed to22/11/8 percent; Product now48 percent on paper (45 percent on screen plus3 percent Include checkbox). Serial4%, ID7%. This removes unused horizontal space while keeping phone below customer name, native payment title, minute precision Bangladesh time, cancellation validation, invoice access, and25/30/35 density.

Changed runtime files: hpbd-operations.php, includes/workspace.php (version only); includes/print-design.php (shared brand colgroup); assets/print-design.css (scoped styling). No order/API/data changes. Database schema remains0.10.0.

Current validation: PHP8.3 syntax30 files; print DOM29 regression assertions. Actual CSS rendered with existing native Woo sample HTML updated only for the shared header colgroup: A4 sample25 rows1 page,55 at30 density2 pages,35 rows1 page, native invoice1 page; compact screen rendered. This release did not rerun the native backend suite; prior1.2.6 reports are historical. No physical printer/browser/device or live deployment test. Long content is preserved and may require more paper.

Back up before installing. Upload this ZIP, choose Replace current with uploaded, clear CSS caches and open a fresh print preview. Do not delete/uninstall the plugin. Previous root documentation retained under docs/pre-1.2.7-root.
