HEALTH POINT BD OPERATIONS 0.8.0 — IN-PLACE UPDATE

আগের hpbd-operations directory, shortcode [hpbd_operations], dashboard URL,
roles/capabilities, database, পুরোনো অর্ডার, settings, secrets ও bridge contract রাখা হয়েছে।
Main site-এ দেওয়ার আগে backup এবং নিজের staging/host-এ acceptance test প্রয়োজন।

এই সংস্করণে ব্যবহার:
1. সব অর্ডার: একটি অর্ডারের একটি সংক্ষিপ্ত সারি। নাম/ফোন/পণ্য/source/status/মোট
   একসঙ্গে দেখা যায়। বড় লেখা শুধু তালিকার সারিতে সংক্ষিপ্ত; Quick view-তে সম্পূর্ণ
   তথ্য, status update ও history আছে। Print/export/customization লেখা সংক্ষিপ্ত হয় না।
2. মেনু খোঁজা সরানো হয়েছে। উপরের Search everything দিয়ে order/customer/product/
   task/staff/incoming message খোঁজা যায়। প্রতি group সর্বোচ্চ 20টি ফল। Order history
   local index ব্যবহার করে; message search সর্বশেষ 2000 integration event-এর মধ্যে।
3. Global order search-এ status, source ও WooCommerce/Operations-only dropdown আছে।
   সব অর্ডার একসঙ্গে অথবা storage/source অনুযায়ী আলাদা দেখা যায়।
4. Production-এ All customization orders, My tasks, NP/Embroidery/Engraving এবং
   Print these tasks shortcut আছে। Unassigned কাজ Take task দিয়ে নিজের নামে নিন;
   progress dropdown দিয়ে পরিবর্তন করুন। আগের board/list ও সম্পাদকও আছে।
5. পরিচিত, explicit native customization variation থাকলে সেই পণ্যের নাম লেখার field
   খুলবে। লেখা না দিলে preview বন্ধ হবে। অন্য attribute থেকে queue অনুমান করা হয় না।
   Website-এর আসল option/variant/price ব্যবহার হয়। Optional staff instruction নিজে
   fee যোগ করে না। Priced customization-এর জন্য website option নির্বাচন করুন।
6. Language থেকে বাংলা/English বদলান। মূল interface-এর label বদলাবে; order ID,
   customer data, exact names, customization, status-এর stored value বদলাবে না।
   কিছু feedback/error, provider technical message ও পুরোনো দীর্ঘ help text ইংরেজিতে থাকতে পারে।
7. শিরোনামের পাশের ছবি বা My profile খুলে নিজের নাম/ছবি দিন। Role/permission,
   login, password বা email এখান থেকে পরিবর্তন হয় না। Display name WordPress
   account-এর; photo শুধু HPBD portal-এর private avatar। Sidebar/print-এ আসল logo।
8. Bell notification-এ নিজের কাজ, সাম্প্রতিক pending order ও index error দেখবেন।
   Read marker নিজের account-এ থাকে। এটি in-app notification, SMS/WhatsApp/push নয়।
9. HPBD Operations Dashboard শিরোনামে ক্লিক করলে Daily order processing খুলবে।
   ঢাকা সময়ের কাজের দিন বেছে New Order, NP, Embroidery, Engraving ও combined
   customization print preview খুলুন। Print/export-এ আগের manager approval বজায় আছে।
10. Order print ও task print-এ প্রতি batch সর্বোচ্চ 100 records; পরের batch স্পষ্ট
    লিংকে আছে। Task count এবং distinct order count আলাদা। Task print-এর আগে current
    server data মিলিয়ে নেয়; preview-এর পর task/order বদলালে নতুন preview প্রয়োজন।
11. একই লেখা দুই item-এ থাকলেও native task identity আলাদা থাকে। নতুন tasks-এর
    source key/item ID রাখা হয়; পুরোনো tasks নিজের মতো অপরিবর্তিত থাকে।
12. Sync/Resume চাপলে fresh cycle হয়; cron event না থাকলে/overdue হলেও নতুন bounded cycle
    শুরু করতে পারে। এটি শুধু local index বদলায়, অর্ডার/status/message নয়।

WOO / AI SYNC
নতুন dashboard order একটি native Woo Pending order; Confirm করলে সেই অর্ডারই
update হয়। Native Woo CRUD দিয়ে website বা অন্য plugin তৈরি/update করা orders
hooks ও reconciliation দিয়ে dashboard-এ আসে। দ্বিতীয় কপি তৈরি করা হয় না।
শুধু free-text পুরোনো Operations record-এ product/variant/price অনুমান করে Woo order
তৈরি হয় না। Original review/link-existing-Woo ব্যবস্থা আছে। অজানা AI plugin যদি
Woo APIs বা বিদ্যমান bridge ব্যবহার না করে, তার নির্দিষ্ট adapter প্রয়োজন।
পূর্ণ customer chatbot বা Messenger/WhatsApp OAuth service এই release-এ নেই।

LIMITS
Direct order read সর্বোচ্চ 500 candidates প্রতি origin / 500 distinct result;
বেশি হলে date filter ছোট করুন অথবা indexed history ব্যবহার করুন। Order print
100 per batch, task print 100 per batch। বৃহৎ কাজেও কোনো hidden truncation নয়।
Notification scope সর্বশেষ 20 assigned tasks + সর্বশেষ 20 indexed orders-এর
pending/problem status + index errors; badge এই visible subset-এর unread সংখ্যা।

UPGRADE-GUIDE.md, ROLLBACK-GUIDE.md, FEATURE-CHECKLIST.md, TEST-REPORT.txt এবং
WORKBENCH-080.md পড়ুন। Real provider delivery, actual browser/mobile/A4 print,
মূল host/MySQL concurrency যাচাই ছাড়া production-ready দাবি করা হয়নি।
