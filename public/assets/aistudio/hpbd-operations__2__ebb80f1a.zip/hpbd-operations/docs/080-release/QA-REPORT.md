# 0.8.0 quality status

Measured tests and their environment/limits are in TEST-REPORT.txt. Every feature status is in FEATURE-CHECKLIST.md. Historical reports in docs apply to their own versions. No local result is a blanket main-site, account or physical-print certification.
