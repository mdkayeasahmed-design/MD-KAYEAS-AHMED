# Install/update

Use UPGRADE-GUIDE.md and retain a backup. Upload hpbd-operations-0.8.0.zip as a replacement of the existing plugin, keeping hpbd-operations. Never uninstall/reset. Target-host staging acceptance and provider validation remain required; see TEST-REPORT.txt.
