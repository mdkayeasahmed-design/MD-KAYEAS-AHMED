# 0.8.0 feature status

This is an installable safe in-place upgrade. **The merchant's main-site release gate remains open.** Local application tests do not certify the target hosting, accounts or physical browser/printer. The full original customer-chatbot master plan is not represented as completed.

| Requested change | Status | Evidence / limit |
|---|---|---|
| Preserve working plugin/data/settings/contracts | IMPLEMENTED / TESTED | All 236 baseline paths retained; actual upgrades, exact old metadata/options/caps, source manifest and original 46-assertion regression. |
| One order per line | IMPLEMENTED / TESTED structurally | Dedicated single-line grid summary; full content in details/drawer. Horizontal mobile scroll. Physical target browser layout still needs review. |
| Global header search instead of menu-only search | IMPLEMENTED / TESTED | Orders/customers/products/tasks/staff/messages; dropdown order filters. Indexed orders, 20 per group, recent-message bound documented. |
| Easy production / all customization / my tasks | IMPLEMENTED / TESTED | Shortcut navigation, real queue data including taskless mapped orders, self claim, revision checks, original board/list and task editors retained. |
| Identical names on separate items | IMPLEMENTED / TESTED | Source/seed/item provenance and one-to-one fallback prevent a single task matching multiple independent items. |
| Separate/combined NP, Embroidery, Engraving printing | IMPLEMENTED / TESTED for data and interaction | Order customization layout and task selection; explicit pagination, manager review, stale-state preflight, distinct order counts. Real A4/Bangla/font/device review remains. |
| বাংলা / English | IMPLEMENTED / TESTED for core labels | User preference and runtime label translation preserve data/input/status values. Provider technical text and every legacy help paragraph are not fully translated. |
| Notification option | IMPLEMENTED / TESTED, in-app | Real scoped workload/errors; per-user read markers. Not external push, WhatsApp or SMS delivery. |
| Dashboard → daily processing | IMPLEMENTED / TESTED | Title/shortcut/navigation, Dhaka date, daily order list and print links. Batches over 100 are explicit. |
| Staff/manager/admin own profile and photo | IMPLEMENTED / TESTED application layer | Own display name/private image, remove/fallback, role/ID/email mass-assignment denial, authenticated image bytes/nonce/headers. Actual multipart upload transport on target host remains unverified. |
| Product variants, exact customization name and references | IMPLEMENTED / TESTED for configured adapters | Existing website options/shipping/price use Woo APIs. Recognized native selector requires a nonempty instruction; per-item staff controls do not invent a fee. Unknown provider/selector meanings still need explicit mappings. |
| Woo website/dashboard order synchronization | IMPLEMENTED / TESTED within native CRUD scope | Same canonical Woo order, existing safe status transitions, hooks, explicit mappings, repairable background index; source/storage filters. Native Pending creation precedes confirmation. |
| Arbitrary unknown AI plugin stores | PARTIAL / BLOCKED | Woo-CRUD or existing bridge integration works within those contracts. No direct adapter can be claimed for unspecified plugin code/storage. Legacy text-only orders are not guessed into stock-reserving Woo orders. |
| Existing Pathao / Meta / payment / SMS contracts | PRESERVED / local regression TESTED | Real merchant login/rates/booking/delivery/payment/refund and remote account checks still require configured providers and approval. Active-version detection improves renamed/network-active plugin diagnostics, not account verification. |
| Complete automatic Messenger/WhatsApp AI conversations | BLOCKED / NOT DELIVERED | Existing signed bridge and optional staff-reviewed order AI remain; no native OAuth broker/full automatic customer chatbot is bundled. |
| Security and performance | Targeted tests passed | Caps/nonces, own profile/attachments, no secret search, bounded lists, stale revision and print guards. No independent penetration test, native MySQL load/concurrency certification or target-host compatibility claim. |
| Server PDF engine / real browser print certification | BLOCKED | Browser Print / Save PDF retained; server-side Bangla PDF library not bundled. |

Use TEST-REPORT.txt for measured counts and environment, WORKBENCH-080.md for limits and workflow, UPGRADE-GUIDE.md and ROLLBACK-GUIDE.md before installing.
