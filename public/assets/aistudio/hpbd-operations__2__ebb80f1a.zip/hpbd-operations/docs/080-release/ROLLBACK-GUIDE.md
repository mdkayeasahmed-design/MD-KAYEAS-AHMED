# Roll back 0.8.0

1. Pause operational changes while assessing rollback. Take a current full backup first.
2. Restore the saved previous `hpbd-operations` code directory/ZIP through a supported replacement procedure. Do not uninstall or delete data/options. Keep the same directory, shortcode, WordPress salts and dashboard URL.
3. An ordinary code rollback needs no database reset. New personal preferences/read markers/photo IDs and task source metadata are additive and can remain. Older code ignores unsupported UI preferences; historical and newly created orders/tasks remain in their original storage.
4. Staff photos use the existing private file table; rollback does not delete them or other reference attachments. The older version may not display the new avatar. Original official branding remains available.
5. New orders are native Woo orders, not simulated records. Keep them and reconcile actual transactions. A whole-database restore can erase post-backup orders, payments and courier activity; assess and reconcile these before any database restoration.
6. Check existing role/capability access, records, native orders, statuses, exact customization, source/seed protections and provider settings after rollback. Refresh all open browser tabs/previews.

0.7.0 backup SHA256 is in UPGRADE-GUIDE.md. No automatic destructive rollback procedure is included.
