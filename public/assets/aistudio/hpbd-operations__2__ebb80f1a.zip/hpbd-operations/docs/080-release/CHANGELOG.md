# 0.8.0

See CHANGELOG.txt, WORKBENCH-080.md and FEATURE-CHECKLIST.md. Previous root docs are retained under docs/070-*.
