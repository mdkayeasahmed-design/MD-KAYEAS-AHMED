# সংযোগ সেটআপ — 0.8.0

প্রথমে existing dashboard → **সংযোগ / Connections** খুলুন। Open setup মানে সেটিংস খোলা; account Connected বা delivery verified বোঝায় না। কোনো saved key/secret মুছে নতুন করে বসানোর প্রয়োজন নেই।

| সংযোগ | এখন কী ব্যবহার করবে | কী প্রয়োজন / কী যাচাই বাকি |
|---|---|---|
| WooCommerce | একই WordPress-এর Woo CRUD | আলাদা Woo API key লাগে না। Woo সক্রিয় এবং staff permission প্রয়োজন। |
| Pathao | বিদ্যমান reviewed Pathao plugin / আগের courier bridge | Installed version ও merchant settings মিলতে হবে। Diagnostics দেখুন। অনুমোদিত staging booking ছাড়া সফল booking দাবি করবেন না। |
| Meta for WooCommerce | বিদ্যমান Meta plugin-এর নিজস্ব setup | Product catalog/pixel sync-এর সংযোগ; এটি Messenger/WhatsApp inbox সংযোগ নয়। |
| Messenger / Facebook Comments | HPBD-এর আগের signed channel bridge | Channel-সামঞ্জস্যপূর্ণ provider/service, তার account permission, incoming webhook verification, policy enforcement এবং delivery receipts দরকার। Native OAuth/login service এই ZIP-এ নেই। |
| WhatsApp | HPBD-এর আগের signed WhatsApp bridge | Compatible provider/service ও অনুমোদিত business setup; Business app ব্যবহারের সঙ্গে API setup সামঞ্জস্য provider-এর মাধ্যমে যাচাই করতে হবে। |
| AI order suggestions | আগের optional provider / signed AI bridge | Manager settings-এ নিজের configured provider। কর্মী consent ও review ছাড়া AI suggestion final order হবে না। পূর্ণ automatic customer chatbot এই release-এ নেই। |
| SMS / payment / notifications | বিদ্যমান compatible plugin বা signed bridge | Native Woo hooks/adapter rules ঠিক থাকতে হবে। শুধু staff task status বদলালে automatic SMS আছে বলে ধরে নেবেন না। |

Generic bridge-এর URL, secret, event id, HMAC এবং reply acknowledgement-এর হুবহু contract **INTEGRATION-CONTRACT.md**-তে আছে। Website integration নিজের endpoint অনুযায়ী তা বাস্তবায়ন করতে হবে। Endpoint বসানো বা plugin active দেখা সংযোগের প্রমাণ নয়।

Main-site ব্যবহারের আগে synthetic order দিয়ে: incoming → inbox → reviewed reply → provider receipt; order status → configured notification → actual delivery receipt; approved courier booking → consignment → tracking—এই পথগুলো আলাদাভাবে যাচাই করুন। বাস্তব message/order/booking-এর আগে আপনার অনুমোদন প্রয়োজন।

Native Woo CRUD দিয়ে তৈরি AI/plugin orders একই hooks/index ব্যবহার করে। অজানা custom AI storage-এর জন্য নির্দিষ্ট adapter প্রয়োজন; দেখুন WORKBENCH-080.md।
