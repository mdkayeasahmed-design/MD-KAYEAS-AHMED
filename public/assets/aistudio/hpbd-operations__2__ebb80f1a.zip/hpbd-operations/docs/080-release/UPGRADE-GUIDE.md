# Update 0.7.0 → 0.8.0

1. Back up the full database, existing `hpbd-operations` directory and WordPress configuration/salts. Keep the actual currently installed version's ZIP. The supplied 0.7.0 backup SHA256 is `5930a8fb2c317b74692c7235a89de9c9dd96771ccc799aec9b7a2b19f17a57dc`.
2. Test on a staging copy first. WordPress → Plugins → Add New → Upload Plugin → `hpbd-operations-0.8.0.zip` → replace the existing plugin. Keep directory `hpbd-operations`. Do not uninstall, reset data, or install a second parallel copy.
3. Open the same dashboard URL and reload it so new versioned assets load. Existing login/roles/capabilities are reused. Refresh any open order/task/print preview after updating; stale fingerprints correctly fail closed.
4. Check All Orders: one line per canonical order. Use source/storage dropdowns for Website/Woo, channel and unlinked Operations records; Quick view retains editing/status/history. Test both wide and mobile screens.
5. Try header global search. Make sure index backfill has completed; Sync/Resume now repairs an absent/overdue reconciliation event through bounded foreground pages. This does not replace a correctly configured hosting cron for periods when nobody opens the portal.
6. Select বাংলা/English. Verify exact customer/customization text is unchanged. Interface preference is private to each user; it does not reset the WordPress site language/timezone or rewrite stored statuses.
7. Click the header image → My profile. Save only your own display name and JPEG/PNG photo. Verify save/removal, nonce access, target-host upload limits and private avatar display. Sidebar/print must retain the official supplied branding.
8. Test All customization orders, NP/Embroidery/Engraving, My tasks, Take task, original manual task editor and quick progress updates. Review unsupported/missing native name mappings before creating production tasks. Native selector fields are recognized only through explicit mapping rules.
9. Click the dashboard title for Daily processing. Choose the work date in Asia/Dhaka. Review New Orders / NP / Embroidery / Engraving / combined customization lists. More than 100 results use explicit independently reviewed batches. Task print has its own queue/own/date/status filters and checked-row selection.
10. Test manager print approval and stale-data denial. Check actual A4 layout, 25/30 short-row density, full long text and Bangla fonts on intended devices. CSV/XLSX retain their previous verification.
11. Verify one synthetic new Woo order: select real products/variants/name/shipping → preview → create Pending → confirm the same native ID → verify website/admin/dashboard reflect the permitted update. Opening a page never creates a production order or sends a customer message.
12. Native Woo/API/AI plugins using Woo CRUD are covered by existing hooks and reconciliation. Arbitrary custom AI-plugin storage needs its specific reviewed adapter. Do not infer product/stock/price from legacy text-only records; use the preserved review/link flow.
13. Run target-host/provider acceptance before main-store use. No real booking, notification, payment or account change was performed by this development task. Read the open gates in TEST-REPORT.txt and FEATURE-CHECKLIST.md.

## Preservation and migration

Every one of the 236 baseline files was read/inventoried before changes. No path is deleted; root documentation is archived. The same plugin identity and existing schemas remain. No reset/down-migration is introduced. New user metadata and source metadata on newly created tasks are additive; previous options/secrets/records/task instructions are retained. The normal stored plugin version advances through the existing upgrade mechanism. The signed bridge contract and branding image remain byte-identical.
