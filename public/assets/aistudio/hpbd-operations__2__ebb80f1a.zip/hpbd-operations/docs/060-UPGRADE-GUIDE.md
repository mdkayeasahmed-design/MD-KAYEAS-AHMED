# Safe 0.5.5 → 0.6.0 upgrade

Source is the supplied 0.5.5 ZIP, SHA256 `a1a3eab4591b3561ac30d3baa00c15e57853a50c33938c1b9fad055bb9664571`. All 85 source files were read/digested before changes, and the actual logo inspected. All source paths remain; source audit and preservation plan are in docs/.

Back up database, wp-content and original ZIP before staging replacement. Keep WordPress salts for existing encrypted credentials. Upload the updated ZIP through WordPress and replace the same plugin; retain `[hpbd_operations]`, existing page ID/URL and staff roles. No uninstall or reset is needed.

New options: `hpbd_ops_release_settings` and `hpbd_ops_release_schema=1`. Migration adds preferences and queues a search rebuild; it does not rewrite existing orders, original workspace/connector/provider settings, audit rows or roles. New audit UTC metadata and explicit Woo Operations-state metadata are additive. The local index gradually standardizes to UTC; check cycle completion/failures before trusting historical day filters. Existing unknown order/courier request locks are retained.

Defaults: production board with list alternative; print density 25 with 30 alternative; AI disabled. Existing appearance configuration stays intact. Legacy audit source timezone is initially captured from WordPress; verify it against historical site configuration. Portal display uses Asia/Dhaka without changing global WP settings.

Direct AI setup and separate API billing: AI-BRIDGE-CONTRACT.md. Canonical order/status behavior and native notification limits: STATUS-SYNC-060.md. Target-site verification and outstanding gates: QA-REPORT.md. Do not merge this release into the main store merely because isolated tests pass.

---
Historical upgrade notes follow.

# Safe 0.5.5 upgrade

0.5.x releases are **visual/additive** (design system, overview stats, mobile drawer, status chips, toast). Schema and integration logic remain on the 0.4.x foundation. Marker target is now 0.5.5.

1. Back up database + `wp-content` (including the current `hpbd-operations` plugin folder).
2. Upload `hpbd-operations-0.5.5.zip` → Replace current with uploaded. Do **not** Delete/uninstall.
3. Confirm roles, shortcode page, records, provider settings and workspace options are intact.
4. Spot-check Overview, Create Woo order, Search, Production, Print and mobile menu.
5. Live Pathao/SMS/Meta and MySQL concurrency still require your staging environment.

---

# Safe 0.4.2 upgrade

1. Use a test/staging copy first. Back up the current HPBD plugin ZIP and a complete current database/wp-content snapshot including Woo orders, original Operations records/options, private file table, events, tasks and write locks. Keep WordPress salts unchanged. Existing provider ZIPs and configuration should also be backed up.
2. Keep the separate provider plugins installed. This HPBD ZIP contains no ThemeComplete/Pathao/SMS/Meta/other provider source and activates none of them. Reviewed versions are listed in PROVIDER-INTEGRATIONS.md. Do not upgrade providers during this test without a separate compatibility review.
3. Upload hpbd-operations-0.4.2.zip through Plugins > Add New > Upload, then Replace current with uploaded. **Do not Delete/uninstall/reset the existing HPBD plugin.** Same folder and main file, shortcode/page ID, roles/caps, URLs, bridge options/secrets and status meanings remain.
4. No existing order/configuration reset or destructive migration is included. Version moves to 0.4.2. New `epo_queues` preference is a default until explicitly saved; schema stays at 1 because no new table is required. Unknown saved workspace keys are retained when settings are saved. Old provider secrets are not moved/re-encrypted.
5. Open Diagnostics as manager and verify provider versions/storage/encryption/tables/cron/index/unknown requests. A detected version is not an API delivery test. Configure payments/shipping/SMS/Meta/Pathao in their existing plugin settings, not in a duplicate HPBD account store.
6. Create Woo order: search product, choose actual attributes, add each product line, wait for website options to load, choose supported custom fields, upload only requested references, confirm customer/destination, select actual shipping and review complete total before creating a test Pending order. Unsupported provider configuration stops creation with a reason; do not work around it by removing the provider.
7. City selectors come from City Select and installed thana filter. Source division choices are not supplied by those plugins; retain optional manual division mapping if needed. A city rate missing/duplicated/invalid requires fixing original provider configuration. No staff-cart shipping quantity is used.
8. Configure product/field-UID production queues explicitly in Workspace settings. Test one dashboard order and one ordinary website checkout with exact Bangla/backslash/custom names and references. Existing site orders must remain readable; no old-order task backfill is automatically run.
9. With outbound transports disabled or sandboxed, validate old manual create/edit/status/CSV/inbox/bridge HMAC, Woo HPOS/legacy order IDs, stock, variations, conditional fields/prices/tax/shipping, duplicate tokens/events, manager-only restrictions, website notes/status/provider workflows and provider emails/SMS/Meta. Test on the actual theme, desktop/mobile, uploaded/downloaded files and A4 Bangla printing.
10. Production release requires MySQL reservation concurrency, real browser/multipart/print and actual provider sandbox/account checks. Pre-order/split/pay-later creation and unknown custom-status changes remain in their original workflows. Do not run production orders/notifications/bookings as tests without explicit approval.

Historical upgrade guide: docs/041-UPGRADE-GUIDE.md. Original contract: INTEGRATION-CONTRACT.md. New adapter details: PROVIDER-INTEGRATIONS.md.
