## 0.6.0 — canonical operations workspace, based on supplied 0.5.5

- Preserve plugin identity, source paths, existing shortcode/page, roles, data/configuration, signed bridge contracts, original workflow and logo; additive preferences only.
- Remove duplicate HP mark; repair header/notice/export contrast in retained appearance modes, preserve accent controls with readable button text, green branding and mobile quick access.
- Replace raw overview index JSON with meaningful health/schedule/error status; use explicit Dhaka display/day boundaries and UTC indexing. Remove decorative fabricated overview trends.
- Unified canonical All Orders, original list/CSV fallback, guarded explicit status mappings, linked-record reflection and conflict notices; keep native stock/payment/notification checks.
- Board/list production views, filters, order lookup, quick progress preserving task metadata, duplicate-task request tokens, Dhaka history; print includes old tasks attached to linked Operations IDs.
- Optional direct OpenAI and signed AI bridge, encrypted manager-only credentials, explicit staff consent, evidence-checked editable suggestions, manual fallback and no automatic order/action execution.
- Compact A4 New Orders widths, product column emphasis, 25/30 density, screen-only Include checkbox, no hover motion, source filter retained, full text preserved.
- Read-only Meta Catalog diagnostics using actual reviewed 3.7.8 provider; original Pathao adapter retained; no duplicate courier, catalog, Pixel or SMS sender.
- New regression/upgrade/acceptance and AJAX checks; real provider/source tests, staging gates and rollback/AI/status documents included.

## 0.5.5 — Full design preview parity

- Overview: sparklines, dual CTAs, stat cards.
- Mobile: drawer menu search, section labels (Workspace/System), bottom-bar active indicator.
- Tables: auto status chips + attention row for pending.
- Toast on save; Inter + Noto Sans Bengali fonts.
- Search results in panel layout; filter bar card styling.
- Still additive/visual — no schema or integration logic changes.

## 0.5.4 — Design preview v2 applied to plugin UI

- Overview page uses stat cards + panel layout matching the Professional Design v2 preview.
- Shared CSS for stats, topbar, buttons, panels, cards, tables aligned with preview tokens.
- Continues visual-only path from 0.5.3; no schema/handler/integration changes.
- Same plugin folder, shortcode, CPT, capabilities.

## 0.5.3 — Professional Design System v2 (visual only)

- Incremental update of 0.5.2 Professional Blue Header build.
- Visual-only: design tokens, header/panels/tables/buttons, mobile bottom-bar indicator, drawer polish, skeleton/empty/toast utilities, status chips.
- No data, schema, handler, or integration changes.
- Same plugin folder, shortcode, CPT, capabilities, and all prior integrations.

# Changelog

## 0.4.5 — Upgrade marker safety and release metadata

- Make the runtime schema/version upgrade check monotonic: an older or missing `hpbd_ops_version` marker can advance to 0.4.5 only after the existing installer reports success; a newer marker is not overwritten by older code.
- Align plugin header, workspace asset version, and workspace module version to 0.4.5 for reliable cache invalidation.
- Preserve existing plugin slug/folder, shortcode, custom post type, metadata, options, roles/capabilities, and provider integrations.
- No destructive migration, table deletion, or data reset added.
- Retain the 0.4.4 server-side field-length validation and prior provider/workspace behavior.

## 0.4.4
- Added server-side length limits for manual order fields.
- See historical details in `CHANGELOG.txt` and `docs/0.4.4-QA-REPORT.txt`.

## 0.5.5-ready — WordPress install readiness pass

- Defined `HPBD_OPS_FILE` and `HPBD_OPS_VERSION` for stable `plugins_url` resolution.
- Asset cache-busting unified (portal, workspace, pathao scripts/styles).
- Default workspace tab is **Overview** (design parity).
- Styles enqueue only on admin HPBD page or frontend shortcode pages (no global frontend CSS leak).
- Pathao script version aligned to 0.5.5.
- Installation / upgrade / feature checklist / QA docs updated for 0.5.5.

## 0.5.5 desktop layout — approved preview applied

- Fixed left navy sidebar with brand lockup (logo + HEALTH POINT BD OPERATIONS).
- Desktop: hide hamburger Menu, bottom bar, and drawer backdrop (≥901px).
- Clean header: hide redundant HP mark when logo is present; card-style header bar.
- Default sidebar width 236px to match design preview.
- Mobile drawer / bottom bar behavior preserved below 901px.

## 0.5.5 layout polish (arrange, do not over-hide)

- Hide only what is not needed on each breakpoint:
  - Desktop: mobile Menu button + bottom bar (sidebar replaces them).
  - Mobile: empty top strip (Menu docks into header).
- Keep logo, HP mark, title, user/Logout, Overview content, bottom nav.
- Mobile header is one row: brand · user · Menu.
- Desktop header is one row: brand (logo + HP + title) · user/Logout.

## 0.5.5 cross-device layout (standard placement)

Industry-style breakpoints:
- **Desktop ≥1024:** left sidebar + content header (logo · HP · title · user/Logout). No Menu button, no bottom bar.
- **Tablet 768–1023:** top header with Menu; full nav in side drawer; no bottom bar.
- **Mobile ≤767:** sticky top app bar (logo · HP · title · user · Menu) + bottom tab bar; full nav in drawer.
- **≤380:** drop logo image, keep HP mark + title for space.

Only breakpoint-inappropriate chrome is hidden; branding and Logout stay available.

## 0.5.5 full menu on all devices

- Every navigable tab appears in the main nav (including Book Courier / Pathao).
- Desktop: full sidebar list (Workspace + System sections).
- Tablet & mobile: quick bottom shortcuts + **All menu** opens complete drawer.
- Bottom bar horizontally scrollable so more tools fit; Menu stays sticky at the end.
- Edit / order-detail links stay contextual (need a record ID) — not removed from workflows.
