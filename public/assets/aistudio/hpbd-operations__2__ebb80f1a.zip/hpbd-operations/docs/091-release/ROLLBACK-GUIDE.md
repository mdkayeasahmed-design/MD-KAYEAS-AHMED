# Rollback 0.9.1 → 0.9.0

Restore the backed-up 0.9.0 ZIP using WordPress Upload → Replace. Do not uninstall or reset data. Both versions enforce the same limited work profiles; this patch adds no role/schema/configuration changes. Discard old preview/export tokens and reload after rollback. C will return to the old blank-column behavior.

If reverting further to 0.8.0 or older, first revoke the new limited work profiles’ Operations access/sessions: those old versions do not enforce the new scopes. Full details and database restore cautions are in docs/090-release/ROLLBACK-GUIDE.md. Never blindly overwrite new real transactions with an old database.
