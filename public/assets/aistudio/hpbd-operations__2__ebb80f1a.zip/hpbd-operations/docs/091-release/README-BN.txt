HEALTH POINT BD OPERATIONS — 0.9.1

C কলামের সংশোধন:
Engraving = EN
Embroidery = EMB
Nameplate = NP
একই অর্ডারে একাধিক customization থাকলে EN / EMB / NP (প্রযোজ্যগুলো),
প্রতিটি code একবার। Customization না থাকলে C খালি।
New Orders preview, browser print/Save PDF এবং CSV/XLSX একই mapping ব্যবহার করে।
Mapped Woo fields, provider/staff fields, explicit Operations flags ও production
tasks থেকে code আসে; শুধু product name দেখে customization আন্দাজ করা হয় না।
অচেনা website field থাকলে Customization setup-এ exact mapping দিন।
Optional field খালি থাকলে ভুল code বসবে না। Explicit customization আছে কিন্তু
লেখা missing হলে code থাকবে এবং missing information-ও দেখাবে।

আগের ডেটা/settings/permissions/shortcode/URL অপরিবর্তিত। Backup নিয়ে Plugins →
Upload ZIP → Replace current with uploaded। Delete/Uninstall নয়। পুরোনো print
preview/export token বাদ দিয়ে নতুন preview খুলুন; snapshot-এর structure বদলেছে।
এই patch-এ ৫৪৯টি isolated check পাস করেছে; মূল ৪৬টিও আলাদা পাস (৮১টির subset)।
Actual healthpointbd.com field/provider mapping ও physical printing যাচাই হয়নি।

আগের পূর্ণ workflow ও role setup নির্দেশনা docs/090-release/README-BN.txt-এ।
