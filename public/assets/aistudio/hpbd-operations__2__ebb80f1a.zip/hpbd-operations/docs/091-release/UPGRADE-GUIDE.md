# Upgrade 0.9.0 → 0.9.1

Back up files/database and retain `hpbd-operations-0.9.0.zip` (SHA256 `5207ac25ff6511377f97cd5555ddd3ab3bd45bebf0f2bb33044e7b99387e5446`). Upload `hpbd-operations-0.9.1.zip` through WordPress Plugins and choose **Replace current with uploaded**. Never Delete/Uninstall. Same directory, main plugin, shortcode and URL. No data/configuration/permission reset.

Discard previously open print previews/export tokens and reload to generate a fresh approved batch. Snapshot data now includes explicit queue flags. Verify known example orders with EN, EMB, NP and combined customization. If codes are blank for an unrecognized website field, map that exact field in Customization setup; do not infer a production task solely from a product title. Print, CSV and XLSX use the same code formatter.

All existing target-site/provider validation requirements remain: docs/090-release/UPGRADE-GUIDE.md. No live site was changed by development/testing.
