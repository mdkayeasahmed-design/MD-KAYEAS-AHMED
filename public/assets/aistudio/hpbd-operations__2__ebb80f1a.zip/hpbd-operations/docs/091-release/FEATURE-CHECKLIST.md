# 0.9.1 patch checklist

| Feature | Status | Evidence |
|---|---|---|
| Engraving → EN; Embroidery → EMB; Nameplate → NP | IMPLEMENTED / TESTED | Eight combinations and real Woo/Operations/task fixtures |
| Combined codes, no duplicates, no optional-blank false positive | IMPLEMENTED / TESTED | Shared formatter, missing text retained as warning |
| Same C mapping in preview, browser print, CSV and XLSX | IMPLEMENTED / TESTED | Rendered table and CSV values; parsed XLSX D2 |
| Existing data/settings/roles/contracts/logo/URL | PRESERVED / TESTED where applicable | Baseline inventory and existing regression fixtures; no storage migration |
| Unknown provider metadata recognition | PARTIAL | Explicit existing field mappings required; never guess by product name |
| Target live site/provider/printer verification | BLOCKED | Requires target staging/device/merchant validation; no live action performed |

The full 0.9.0 checklist, including all existing integration requirements, remains in docs/090-release/FEATURE-CHECKLIST.md.
