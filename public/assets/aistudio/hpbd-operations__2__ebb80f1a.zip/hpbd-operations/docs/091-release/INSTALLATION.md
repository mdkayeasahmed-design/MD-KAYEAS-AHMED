# Install 0.9.1

Backup → WordPress Plugins → Add New → Upload `hpbd-operations-0.9.1.zip` → **Replace current with uploaded**. Do not Delete/Uninstall. Reload daily print preview; C codes now show EN / EMB / NP as applicable. All existing 0.9.0 role/provider setup remains. See UPGRADE-GUIDE.md and ROLLBACK-GUIDE.md.
