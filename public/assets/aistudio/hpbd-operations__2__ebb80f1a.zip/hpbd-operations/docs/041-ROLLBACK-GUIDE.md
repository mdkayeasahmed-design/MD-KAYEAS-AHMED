# 0.4.1 → 0.4.0 rollback

Keep hpbd-operations-0.4.0.zip and a current database/files backup. Pause writes, reconcile in-flight destinations/shipments, upload 0.4.0 and choose Replace current with uploaded. Do not uninstall/delete or restore an old database over newer orders. Existing data is retained; the old UI will not expose new fulfillment/destination/diagnostic tools. WooCommerce retains saved delivery/customer changes and exact original order/item IDs. Additive metadata and destination request locks should be kept for re-upgrade.

For rollback further to the original 0.2.0, follow the original guide below.

# Rollback without deleting order data

1. Pause staff writes and inspect any in-flight order, reply or courier request. An unknown result requires provider/order reconciliation; code rollback cannot undo an external shipment, email or payment.
2. Preserve a current database/wp-content backup before rollback, including any orders created since upgrade. Do not restore an old full database over new customer orders.
3. In WordPress, upload the original `hpbd-operations-0.2.0.zip` and choose Replace current with uploaded. Do not click Delete or run an uninstall/reset tool. Alternatively replace only the plugin directory's code from the original ZIP while retaining the database.
4. The original init migration may set its own version option back to 0.2.0; original event table schema is unchanged. Saved portal page, roles, manual records, old metadata and bridge configuration remain accessible.
5. New tables, files, production tasks and new Woo orders remain in the database. The 0.2 UI does not display/manage the new modules; use WooCommerce for new Woo orders. Do not remove the new tables or locks if you plan to re-upgrade.
6. Disable the new scheduled `hpbd_ops_reconcile` event through your staging/host cron tooling if needed. While old code is active its callback is absent and it cannot change any order. Re-upgrading re-registers indexing.
7. Pathao is a separate plugin. Existing consignment metadata/shipments are unaffected by replacing HPBD code. Keep the Pathao plugin in place. Never rebook a shipment as a rollback step.
8. Re-test original dashboard login, manual order workflows and bridge authentication with test data. WP salts must be retained or original encrypted bridge secrets must be entered again.

Schema reversal is deliberately non-destructive: unused additive objects are retained. A manual schema removal needs a separate data-export and retention decision and is not included.
