# HPBD Operations 0.5.5 — Installation and Upgrade

1. **Back up first.** Take a database backup and a complete `wp-content` backup. Save the currently installed HPBD ZIP and provider plugin versions/settings. Test on staging before production.
2. In WordPress, open **Plugins → Add New Plugin → Upload Plugin** and upload `hpbd-operations-0.5.5.zip`.
3. Use the WordPress replace/overwrite flow if offered. Keep the existing plugin folder/slug `hpbd-operations`; do not delete the plugin or use an uninstall/reset procedure.
4. Activate/complete the upgrade if WordPress prompts. The plugin's existing runtime installer advances its version marker only after its installer reports success. This release adds no intentional destructive migration. Visual design updates (0.5.x) are additive CSS/JS only.
5. Sign in as an authorized operations staff/manager and open **HPBD Operations**. Verify the existing workspace page/shortcode, records, settings and permissions. Confirm Overview sparklines, status chips, mobile drawer and toast behavior.
6. On staging, test a record create/edit, status change, search/filter, printing, order lookup, and any configured courier/provider workflows. Check browser console and PHP/WordPress logs.
7. For WooCommerce sites, test with the site's actual HPOS configuration. Live Pathao/provider calls require the site's own credentials and provider-approved sandbox procedure.
8. Deploy to production only after staging checks pass. Keep the backup and rollback ZIP available.

If anything fails, stop and restore the backup/previous plugin package using the site's normal recovery process. See `ROLLBACK-GUIDE.md`. Do not run database deletion or reset commands as an upgrade workaround.
