# Existing 0.2.0 inventory / preservation audit

All eight archive entries were inspected before editing: main PHP (17650 B), includes/integrations.php (21178 B), assets/portal.css (2770 B), assets/logo.jpg (21274 B; visually inspected), README-BN.txt (7545 B), INTEGRATION-CONTRACT.md (5230 B), TEST-REPORT.txt (1799 B), CHANGELOG.txt (703 B). Original source archive retained byte-for-byte.

## Main plugin

Identity/class: Health Point BD Operations, hpbd-operations/hpbd-operations.php, HPBD_OPS_Pilot. Main shortcode `[hpbd_operations]`, admin slug hpbd-operations, saved frontend page option hpbd_ops_page_id. Existing page is never recreated/replaced while valid. Staff-only no-cache/noindex portal; ordinary customers/anonymous requests cannot obtain records. Login/logout remain standard WordPress.

Existing roles/caps: hpbd_ops_staff(read,hpbd_ops_access), hpbd_ops_manager(read,hpbd_ops_access,hpbd_ops_manage), original administrator grants. No cap/role/shortcode rename. Main activation/save implementation remains the original; new modules are additive.

Storage: private, nonpublic/non-REST hpbd_ops_record CPT. Existing metadata keys: hpbd_customer, hpbd_phone, hpbd_products, hpbd_source, hpbd_amount, hpbd_address, hpbd_custom_text, hpbd_custom, hpbd_reference, hpbd_state, hpbd_priority, hpbd_assignee, hpbd_note, hpbd_issue, hpbd_audit. Original IDs/reference display and audit compatibility retained.

Statuses: Pending / Confirmed / Customization / Ready to pack / Packed / Delivered / Issue / Cancelled.
Sources: Messenger / Facebook Comment / WhatsApp / Website / Manual.
Custom groups: NP / Embroidery / Engraving independently selectable. Priority Normal/Urgent.

Original navigation: Website orders, catalog, Inbox, all orders, NP, Embroidery, Engraving, new, hidden edit, connections, help. Original create/edit/status forms, source/state/priority/date/search filters, pagination, audit views and CSV approval remain. Enhanced modules add tabs without removing original tabs.

Original guards: cap + nonce on writes; CPT/type/status/source allowlists; BD phone normalization; bounded amount; manager-only reductions; authorized staff assignment; exact customization text/slashing; unique UUID create reservation; escaped HTML. The full original save method, states/sources/field/select and activation workflows are retained.

## Integration module

Table `${prefix}hpbd_ops_events`: id, UNIQUE event_key, channel, kind, thread_id, sender, body, state, created_at, channel/date index. Existing bridge config option hpbd_ops_connectors: enabled, HTTPS endpoint, encrypted secret. Blank secret retains old value.

Channels: messenger, facebook_comments, whatsapp, website_chat, payment, courier, notifications. POST route hpbd-ops/v1/bridge/{channel}. HMAC SHA256(secret,timestamp+'.'+rawbody), 300-second skew, 64 KiB raw cap; scalar schema/16 KiB text limit, unique per-channel event dedup. Payment/courier/notification receipts remain review_required. AES-256-GCM and existing WP salt-derived key/IV/tag layout unchanged.

Existing manual reply: cap+nonce, 4000-character limit, original thread binding, UUID reservation before HTTPS, signature and Idempotency-Key, redirects off. Exact accepted/event_id acknowledgment produces bridge_accepted, 4xx rejected, ambiguous unknown; no blind retry or delivered claim. Facebook comment private reply remains provider-dependent.

Original CSV: manager+nonce+approval checkbox, existing list filters, hard1000 max, UTF-8 BOM, formula-safe values. Original New Order five columns and custom-list columns retained. Woo catalog and order views retain CRUD reads; order list adds details and Pathao links. Existing Inbox/Connections/help routes remain accessible.

## Original assets/docs

Original logo SHA256 remains `73706358baf34a12bd05455eee707531df41d19f73e543f018dd139ba5079d31`. portal.css remains byte-identical; new workspace.css is separately scoped. Old README/test report archived in docs. Original bridge contract remains with a version-scope clarification. Changelog retains old entries.

No source record deletion, option purge, database reset, old status mapping, duplicate Woo/CPT creation, live-site operation or real notification/booking was performed as part of development.
