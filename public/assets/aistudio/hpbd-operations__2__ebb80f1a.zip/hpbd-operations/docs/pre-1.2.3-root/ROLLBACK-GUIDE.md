# Rollback from1.2.2

Replace files with the previous1.2.1 ZIP without uninstalling. No schema or saved order/payment change was introduced. Clear related assets and reopen the portal; the earlier header/sidebar placement returns. Keep the database and incoming orders intact. Prior fee/SMS rollback details remain in earlier archived guides.
