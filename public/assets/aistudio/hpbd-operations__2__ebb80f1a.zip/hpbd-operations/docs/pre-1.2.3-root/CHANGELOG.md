# 1.2.2 — 24 October2026, Bangladesh

- Only the screenshot's workbench/search row stays at the top. Page title/profile header, desktop sidebar and create action strip use document flow.
- Desktop keeps search/daily/language/notification in the row and adds the original Menu button there. Menu opens the same navigation as a bounded popup even after the document sidebar scrolls away.
- Mobile row contains Menu, original search, bell and More. Daily/language/profile/logout/density/metadata are available in More; original handlers, values, permissions and nodes retained.
- Popup anchor follows toolbar bottom and visible WordPress admin bar. Scroll updates coalesced to animation frames; ResizeObserver updates height changes.
- Existing exclusive popup, Escape/backdrop/outside-click and desktop focus-return behavior preserved. Scoped screen-only CSS leaves invoice printing unchanged.

Runtime/assets1.2.2; SQL marker0.10.0. No order/payment/SMS/database change. Earlier detailed guides/results are archived under docs/pre-1.2.2-root/ and previous archives.
