#1.2.2 toolbar layout

| Area | Behavior |
|---|---|
| Top row | Only search/workbench remains sticky |
| Other chrome | Title/profile, document sidebar and create-action strip scroll in normal flow |
| Desktop navigation | Same Menu button in sticky row opens bounded navigation popup |
| Mobile navigation | One row: Menu, search, bell, More; daily/language/profile/logout are in More |
| Preservation | Same nodes/handlers/values, role-scoped search, exclusive popups and focus handling |
| Printing | Invoice/logo/contact/print time sources byte-identical to1.2.1 |

Local DOM/static-responsive testing is not physical-device geometry. Existing1.2.1 native-order/provider/authentication limits remain; see docs/pre-1.2.2-root/FEATURE-CHECKLIST.md.
