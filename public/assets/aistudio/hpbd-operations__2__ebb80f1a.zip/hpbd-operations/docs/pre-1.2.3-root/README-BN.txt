HEALTH POINT BD OPERATIONS1.2.2
Developer: Md Kayeas Ahmed | Phone:01929779381

আপনার ছবির search/workbench লাইনটিই শুধু ওপরের sticky toolbar। Title/profile/header, desktop sidebar এবং order action-এর অন্য স্থায়ী bar এখন document-এর সঙ্গে scroll হয়।

Desktop: search + daily processing + language + notification; ওই লাইন থেকে Menu popup খোলা যায়, sidebar scroll হয়ে গেলেও navigation পাওয়া যায়।
Mobile: Menu + search + bell + More এক সারিতে। More-এ daily processing, language, profile/logout ও অন্যান্য controls পাওয়া যায়। মূল control-ই সরানো হয়; নকল search/language/profile তৈরি হয় না।
Menu, notification এবং More একসঙ্গে খোলা থাকে না। Escape/outside/backdrop দিয়ে বন্ধ হয়; Menu বন্ধ হলে focus ফেরে। Popup-এর অবস্থান search toolbar থেকে হিসাব হয়, scroll হয়ে যাওয়া title থেকে নয়। WordPress admin bar থাকলে তার নিচে toolbar বসে।

1.2.1-এর invoice, logo/contact এবং Bangladesh print date/time অপরিবর্তিত। আগের order/autofill/COD/SMS/approval/manager workflow একই আছে। আগের নির্দেশনা: docs/pre-1.2.2-root/README-BN.txt।

Backup → Upload hpbd-operations-1.2.2.zip → Replace current with uploaded। Delete/uninstall নয়। পুরোনো portal tab বন্ধ করে asset cache পরিষ্কার করে আবার খুলুন। এই ZIP live সাইটে install করা হয়নি। বাস্তব ফোন/browser layout ও theme-specific sticky behavior target site-এ দেখা প্রয়োজন।
