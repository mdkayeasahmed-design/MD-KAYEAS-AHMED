#1.2.2 QA

HPBD OPERATIONS1.2.2 — FOCUSED VERIFICATION
24 October2026, Bangladesh

323 current local assertions passed:261 toolbar/grouped-navigation/responsive DOM/static CSS +62 existing real AJAX/order/profile/task-print DOM workflows.30 runtime PHP8.3 syntax checks and11 external JavaScript syntax checks passed. Complete final markers required; one incomplete Wasm attempt discarded and rerun. Earlier1.2.1's420 and1.2.0's2369 results are retained historical evidence, not a newly repeated full suite.

Toolbar tests render actual native WordPress markup for Admin, Moderator, Delivery, Production and Manager. Repeated320/640/1023/1024/1440/375 width transitions check original profile/language/search nodes, only one Menu/identity, accessible More and exclusive popups, retained language/density handlers, role-scoped real GET search, no duplicate bottom navigation, restoration at desktop, full desktop popup/backdrop/focus return, and popup anchoring to search bar instead of scrolling title. Static stylesheet parse/budget checks cover320/375/640/1023 widths, document-flow header/sidebar and admin-bar override. These are not physical layout measurements.

Existing native Woo AJAX + DOM regression runs HPOS and legacy: exact per-item customization, one create, same saved native order and index, moved interactive order drawer, language/profile/avatar, approved selected-task print count and stale-task rejection. JSDOM reports its expected unsupported navigation warning during native redirect; assertions and final totals complete.

Environment: WP6.8.3, Woo10.2.2, PHP8.3.33 Wasm, SQLite; HTTP/email blocked/intercepted. No production site change, real message or financial action.

All prior1.2.1 paths preserved. Native business logic, original logo and invoice/print identity, design, timestamp JS/CSS and print-center sources byte-identical. Only source changes: version metadata, additional screen stylesheet enqueue, mobile-header control relocation/anchor, desktop Menu close focus, new screen-only toolbar stylesheet. Schema remains0.10.0. Create action strip now scrolls with form; popups remain overlays only while open.

Limits: actual browser/device geometry, target theme ancestor overflow/transform behavior, keyboard viewport, physical printer, MySQL production load and external provider delivery not tested. CSS sticky remains within the document/host scrolling context. Prior native SMS/provider/authentication limitations remain in archived guides.

Evidence: docs/122-*-results.txt and inert docs/test-source/122-*. Reinstall via Replace current with uploaded, clear assets and reopen tabs. No uninstall/data reset.
