# Upgrade to1.2.2

1. Back up plugin/database; upload ZIP and Replace current with uploaded. Do not uninstall/delete.
2. Close old portal tabs, clear related asset cache, reopen the Operations page. Keep this private URL out of public page caching.
3. Scroll the page: only the search/workbench row remains above. Page title, profile and desktop document sidebar scroll away.
4. Desktop: use the row's Menu to open navigation when the sidebar has scrolled away. Daily processing/language stay in the row.
5. Mobile: Menu + search + bell + More stay in one compact row. Open More for daily processing, language, profile/logout and density. Only one popup stays open; Escape/outside/backdrop close controls.
6. Check320/375px mobile, landscape/tablet and desktop, keyboard/search behavior and WordPress admin bar if shown. Target theme ancestor overflow/transform rules can affect sticky positioning and need site-specific inspection.
7. Invoice/print time and existing native operations setup are unchanged; previous guide remains in docs/pre-1.2.2-root/UPGRADE-GUIDE.md.

No live site change or real messages were made while preparing the ZIP.
