# 1.2.1 QA

HPBD OPERATIONS1.2.1 — CURRENT FOCUSED TEST REPORT
24 October2026, Bangladesh

420 local assertions passed on this update:
- New invoice/shared print backend:34 HPOS +34 legacy =68.
- New print DOM/timestamp/selection/production:18.
- Existing workspace upgrade/print/export regression:51 HPOS +51 legacy =102.
- Existing workbench/task-print/permission regression:170.
- Existing actual AJAX + DOM interactions:62.
30 runtime PHP files pass PHP8.3 TOKEN_PARSE.11 external JS files pass node --check (including the preserved inactive mobile-topbar source).
Historical1.2.0's2,369 assertions are preserved evidence, not claimed as a fresh full rerun here. Current verification is focused on the changed print paths and existing affected workflows.

ENVIRONMENT
WordPress6.8.3, WooCommerce10.2.2, PHP8.3.33 Wasm, SQLite, HPOS and legacy. No live HTTP/email/customer messages. Incomplete/failed development attempts excluded; only complete expected totals copied into current evidence.

NEW COVERAGE
Actual canonical order number; native human-readable address; UTC-configured WP still prints Asia/Dhaka order/print times; exact supplied business address/phones and real logo path; products/exact metadata; discount/shipping/COD fee/total; escaped customer/note text; pending and processing COD do not fabricate received funds; actual non-COD Woo payment completion/transaction; manual record total without invented prices; all tabular layout headers plus invoice/slip/label and production/retained slip renderers; invoice portrait A4; manager guard.
Actual rendered invoice/task markup under JSDOM: unchecked approval blocked, selected-only invoice clone, dynamic timestamp after a61-second preview wait, separate unchanged order date, server-epoch/monotonic elapsed anchor, repeat print new timestamp, fallback without Intl timezone support, empty selection blocked, afterprint cleanup, production validation then print timestamp/contact header. Shared CSS parsed.

VISUAL QA
Supplied5011.pdf rendered and inspected as a layout reference. Actual generated plugin invoice, New Orders list and manual-record invoice rendered at A4 with the active CSS stack using WeasyPrint70; PNG pages visually inspected. Standard sample invoice fits one page with signatures and footer, no orphan footer page. Currency is explicit BDT text to avoid a missing Bengali currency-symbol glyph. Browser-native print remains the product mechanism; this PDF render is development verification, not an implementation of server-generated PDF export. Shared identity uses a presentation table for predictable paged printing. No claim of physical-device/browser geometry or printer testing.

PRESERVATION / LIMITS
Duplicate1.1.1(1) ZIP matches previous1.1.1 patch byte-for-byte. All1.2.0 paths retained; original logo and bridge contracts unchanged. SQL marker0.10.0, runtime/assets1.2.1. No native order/payment/status/SMS behavior changed by the invoice presentation.
COD processing or a status transition is not proof of cash collection. Unknown/provider-specific partial payments are not inferred; no POS receipt data from the sample PDF is written to live orders. Native non-COD payment state is shown, not independent bank reconciliation. Manual records have no invented line prices.
Live healthpointbd.com, MySQL/MariaDB production load, physical desktop/mobile/print geometry, minimum-version runtime, actual email/SMS/provider delivery remain untested. Bangla print depends on the device font. Existing integration, pending background-SMS and interrupted-request limitations remain in archived1.2.0 documentation. Generic known storefront isolation selectors are not a universal theme guarantee.

EVIDENCE
Current complete logs: docs/121-*-results.txt; inert sources docs/test-source/121-*.
All previous regression records remain historical. ZIP CRC/path/byte checks performed during packaging.
