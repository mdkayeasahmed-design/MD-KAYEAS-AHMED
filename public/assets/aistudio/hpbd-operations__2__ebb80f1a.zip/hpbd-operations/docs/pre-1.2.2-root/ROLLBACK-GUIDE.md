# Rollback from 1.2.1

Replace plugin files with the previous1.2.0 ZIP without uninstalling. No new schema, order mutation or print counter migration was introduced. Existing orders, fees and SMS jobs remain as saved. The older invoice/header design returns; business data is not reversed. Keep a backup and preserve orders received since any database backup. For rolling back further, review the queue/fee considerations in docs/pre-1.2.1-root/ROLLBACK-GUIDE.md.
