HEALTH POINT BD OPERATIONS 1.2.1
Developer: Md Kayeas Ahmed | Phone: 01929779381

আপনার দেওয়া 1.1.1-limited-patch(1).zip আগের patch-এর সঙ্গে byte-for-byte একই। ওই পরিবর্তনগুলি1.2.0-তে আছে; সেগুলিসহ নতুন print update এই1.2.1-এ রাখা হয়েছে।

- দেওয়া invoice নমুনা অনুযায়ী logo/contact, Invoice No., order date, customer, Sale by, Product/Qty/Price/Subtotal, Payment Details, Bill Details, signature ও Thanks section।
- Invoice, New Order/customization/NP/Embroidery/Engraving list, pending/urgent/packing/dispatch sheet, individual slip/label, production task print-এ একই logo ও contact header।
- প্রতিবার Print চাপলে নতুন Printed date/time, বাংলাদেশ সময় BST (UTC+06:00)। Order date বদলাবে না। Preview অনেকক্ষণ খোলা থাকলেও print time refresh হবে।
- Invoice amount বাস্তব WooCommerce subtotal/discount/shipping/fee/tax/total থেকে। Default COD1% merchandise-only ruleসহ1.2.0-এর কাজ রাখা হয়েছে। Currency code BDT ব্যবহার করা হয়েছে যাতে currency glyph missing হলেও অঙ্ক পড়া যায়।
- Pending/COD collection বা অজানা partial payment-এ টাকা পাওয়া হয়েছে ধরে Paid/Due বসানো হয় না। Non-COD native paid state ও transaction থাকলে তার তথ্য দেখায়। আলাদা payment-provider partial ledger এখানে নতুন করে যুক্ত করা হয়নি।
- মূল supplied logo artwork অপরিবর্তিত। ঠিকানা ও ফোন আপনার নির্দেশ অনুযায়ী:
Katabon Mor. Opposite The Police box,
3th floor, BCR Diagnostic Center
01831 18 00 17
01572 36 39 46

আগের autofill/Copy format, COD preview, apron variation fix, mobile layout, SMS queue, employee Login/Register/Forgot, manager approval ও অন্যান্য workflow বহাল। বিস্তারিত আগের guide: docs/pre-1.2.1-root/README-BN.txt।

ইনস্টল: Backup → Plugins → Upload ZIP → Replace current with uploaded। Delete/uninstall নয়। পুরোনো tab বন্ধ করে asset cache পরিষ্কার করুন।
Print center থেকে Invoice/List বেছে Preview → selection review → approval checkbox → Print selected / Save PDF। A4 portrait invoice। Browser-এর আলাদা URL/header-footer চাইলে print dialog থেকে বন্ধ করুন।

420 focused local assertions,30 PHP syntax files,11 JS syntax files পাস। A4 invoice/list/manual invoice render দেখে যাচাই করা হয়েছে। Live install, physical printer/mobile এবং real SMS/email পরীক্ষা করা হয়নি।
