# 1.2.1 print update

| Area | Implemented | Limit |
|---|---|---|
| Invoice | Reference-style header/customer/product/payment/bill/signatures, exact Woo amounts and metadata | Actual order number; no new POS numbering or imported sample receipt |
| Shared identity | Supplied original logo plus exact address and both phone numbers on daily/customization/production/slip/label/invoice prints | Logo asset unchanged; target printer/font needs checking |
| Timestamp | Bangladesh Printed time updated per job, separate order date | Browser JavaScript required for live refresh; no claim of delivery/printing completion |
| Payment | Native non-COD paid status/transaction; COD and unknown partial collection remain unconfirmed | No invented partial payment ledger or cash receipt |
| Selection | Existing manager review, selected-only cloning, production stale-proof, afterprint cleanup | Print Center permissions unchanged |
| Prior1.2.0 | Autofill/copy, COD1%, apron fix, mobile, SMS queue, login/approval and operations retained | Prior setup/limits remain; see docs/pre-1.2.1-root/FEATURE-CHECKLIST.md |
