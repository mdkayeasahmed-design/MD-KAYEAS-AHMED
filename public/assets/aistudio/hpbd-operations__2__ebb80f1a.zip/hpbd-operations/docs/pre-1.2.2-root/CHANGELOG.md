# 1.2.1 — 24 October 2026, Bangladesh

- Supplied duplicate1.1.1 patch compared: no new/removed/changed file bytes. Its COD/copy/isolation changes are already merged in1.2.0 and remain here.
- Shared authentic-logo/contact header on every plugin print renderer, including retained legacy slips and production tasks.
- Separate Bangladesh Printed timestamp refreshed immediately before each approved print and native beforeprint event; stable order creation date. Server epoch plus elapsed monotonic client time avoids a device wall-clock offset.
- Dedicated reference-style native WooCommerce invoice: actual order number, human-readable district/country address, product rows and exact metadata, merchandise price/subtotal, native discount, shipping, COD/other fee, tax, total, payment status/transaction, note, signatures and thanks. Invoice uses portrait A4.
- COD processing does not prove collected money. Unconfirmed/partial amounts remain unconfirmed instead of fabricated paid/due. Non-COD native paid state is displayed; provider partial-payment ledgers are not newly integrated. Manual records keep original totals without invented item prices.
- Scoped print typography, flexible header, safe wrapping, signature/footer keep-together. Actual logo file, all data/schema and bridge contracts unchanged. Existing manager approval, selected-only print, stale production proof and cleanup protections retained.

Runtime/assets1.2.1; SQL marker0.10.0. Prior1.2.0 release docs archived under docs/pre-1.2.1-root/; earlier archives remain. No live deployment or customer messages.
