# Upgrade to 1.2.1

1. Back up the existing database/plugin and validate on staging.
2. Upload hpbd-operations-1.2.1.zip in WordPress Plugins and choose Replace current with uploaded. Do not uninstall/delete. The same folder, shortcode and database remain.
3. Close old portal tabs and clear relevant asset cache. Keep the Operations URL excluded from public page caching.
4. Print center → choose Invoice or another list → Preview. Invoice uses the actual canonical order number; no separate invented POS invoice sequence. Review selection and approve, then Print selected / Save PDF. Invoice/slip/label jobs are portrait; broad tabular lists retain their orientation. Production print keeps its existing authorized review/validation.
5. Check the shared logo, supplied address and both business phones. Order date is separate from Printed time. Reprinting updates Printed time in Bangladesh timezone without changing the order. Browser-provided page URL/date headers are separate; turn those off in the print dialog if desired.
6. Invoice uses the saved WooCommerce amounts. COD collection and unknown partial payments are unconfirmed until reconciled; manual orders do not invent missing item prices. External POS/payment provider receipts are not imported from the sample PDF.
7. Target-device checks: A4 scaling/margins, complete long customization text, installed Bangla font, actual printer output and theme/plugin compatibility. HTML Save as PDF uses the browser; no new server PDF service.
8. Existing1.2.0 setup (location lists, COD settings and native SMS API/template/balance/cron) remains unchanged. See docs/pre-1.2.1-root/UPGRADE-GUIDE.md.

No live site was modified while preparing this ZIP.
