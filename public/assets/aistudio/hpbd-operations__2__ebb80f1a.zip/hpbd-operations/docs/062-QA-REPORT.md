# HPBD Operations 0.6.2 — current QA report and gates

Date: 23 October 2026, Asia/Dhaka. Baseline: retained hpbd-operations-0.6.1.zip, SHA256 `dbb19c4e606bfc1343c8df6a726978683310f38987c1e795f0208f284b524752`. Installable staging candidate; no live website/order/provider action performed.

## Defect and correction

Legacy NP/Embroidery/Engraving navigation queried only private Operations records, and the Production board queried tasks. Neither represented all website orders. This release adds all-order customization visibility, canonical unified queue filters, native metadata classification, linked-record details and a direct paginated Woo CRUD view independent of index/task existence. Original manual routes/editors remain. See CUSTOMIZATION-062.md for the operational distinction between indexed filters and the direct Woo view.

## Executed automated checks against current 0.6.2

| Suite | Result |
| --- | --- |
| Original/manual/bridge/Pathao stub regression behaviors | **81 passed**, including original 46. The unchanged unit assertions use an expanded WP harness with scheduling/appearance function stubs needed by new portal renders. |
| Real WP/Woo orders, tax/shipping, print/export, auth/routing, historical upgrade paths and integrity | **262 passed**. Existing fixture assertions include the added workspace tab render in each storage mode. |
| Actual supplied provider classes / Meta diagnostics | **138 passed**: 49 provider + 20 Meta per mode. |
| Earlier 0.6.0 feature acceptance / 0.5.5 preservation / original AJAX checks | **224 passed**: (15 + 93 + 4) per mode. |
| 0.6.1 production preparation and earlier preservation | **148 passed**: (69 + 5 actual AJAX checks) per mode. |
| New customization visibility, 0.6.1 → 0.6.2 preservation and native fields | **130 passed**: 65 per mode. Includes actual variable-product selection, native text without tasks, cancelled/plain/unmapped orders, exact Unicode/slashes, canonical aliases, linked text, private metadata exclusion, explicit rules, nonce rejection, anonymous cron classification, task deletion refresh, direct Woo pagination while indexes are empty, complete reconciliation, legacy routes and provider-safe print data. |
| Combined automated assertions | **983 passed** = 81 stub + **902 within actual WordPress/WooCommerce**, some external transports mocked. These are not browser, live-site or external account delivery tests. |
| PHP syntax | **21 runtime PHP sources passed** under PHP 8.3 token parser. |
| JavaScript syntax | **4 sources passed**: original workspace/pathao/refresh JS and extracted inline theme/navigation code. No frontend JS changed in this increment. |
| Source preservation | All **154 baseline file paths retained**. Original order CRUD, production save/status implementation, integration/security/provider adapters, logo and bridge contracts remain byte-identical; changed integration points are itemized in docs/FILE-PRESERVATION-062.json and PRESERVATION-PLAN-062.md. |
| Packaging | Same plugin directory/main identity, safe unique paths/no symlinks, CRC and packaged-byte comparison before distribution; original 0.6.1 backup unchanged. |

Environment: actual **WordPress 6.8.3 / WooCommerce 10.2.2**, PHP-WASM **8.3**, @php-wasm **3.1.54**, isolated SQLite databases using both HPOS and legacy Woo storage. Woo CRUD is real, not stubbed in integration suites. WordPress HTTP and mail transports are intercepted throughout; merchant/account calls are not performed. Historical names 041/042/043/060/061 in test output identify fixture origins; current runners mount 0.6.2. Source runners and results are in docs/, with executable tests stored as `.txt` in the plugin ZIP.

New assertions prove immediate live Woo order pages even with local indexes emptied, and canonical indexed order counts after complete reconciliation. The native selector-only case is marked for review and cannot create a task without a mapped instruction field. Viewing/reindexing leaves stock, native order status, tasks and emails unchanged. Task creation remains explicitly reviewed using the previous idempotent helper.

## Remaining requirements and release gates

- **Historical filters depend on completed reconciliation/WP-Cron.** First migration creates a separate derived table and queues bounded indexing. Direct Woo view is immediately available, independent of it. Unknown or failed classification is shown rather than silently presented as complete. Ordinary order/task changes update projections through existing events; concurrency can briefly show stale read indexes.
- **Actual field keys require site configuration.** Defaults match documented exact public metadata keys and selector values, with supported original provider mappings taking precedence. Unknown public data remains visible; manager must map the real field keys. Non-text arrays/private unknown metadata are not guessed or exposed. Selector category is not a customer's name. No automatic historical task generation.
- **Target MySQL/concurrency remains BLOCKED.** Real isolated WordPress/Woo tests run on SQLite; they do not establish managed-stock SQL reservation or concurrent production behavior on Hostinger MySQL. This release adds read indexes and no stock mutations. Target migration/index performance must be verified at real order volume.
- **Browser/mobile/accessibility/A4 Bangla and real multipart uploads remain BLOCKED.** PHP HTML rendering and JS syntax passed; a browser executable was unavailable. Real interaction, page density, fonts, browser PDF and upload/download require staging checks.
- **Real provider/account delivery remains BLOCKED.** Reviewed source versions remain unchanged: Pathao 2.1.1 local structural checks; Meta for WooCommerce 3.7.8; ThemeComplete 6.5; Alpha SMS 1.0.19; City Select 1.0.10 + supplied BD filter 0.1.0; city shipping 1.0.3; WPC size chart 2.3.5; Pre-Orders 2.3.1; BP status 2.1. Actual merchant bookings, remote Meta approval/sync, SMS/payment and paid AI calls were not made. Unknown versions need review.
- **Broader roadmap remains PARTIAL.** Full chat automation, broadcasts/reminders/feedback schedules, payment verification, design previews, complete refunds/discount UI and arbitrary two-way customer/product updates are not completed by this increment.
- **Deployment/restore not performed.** Use a current site database/wp-content/salts backup and staging upgrade first. Files-only rollback leaves data and new derived indexes intact; it cannot reverse staff/provider actions. No claim of target-site compatibility or formal security certification.

Current feature statuses: FEATURE-CHECKLIST.md. Workflow/configuration: CUSTOMIZATION-062.md. Upgrade/rollback: current guides. Previous detailed QA and inherited constraints archived in docs/061-QA-REPORT.md.
