Test sources are stored as .txt to prevent accidental execution via a web server.
These are developer tests for an isolated disposable installation, never production.

Original prior-work assertion file extended to 81 stubs; only new API/hook/asset mocks were added for the additive modules. Do not interpret fake HTTP responses as a provider test.
PHP.wasm packages: @php-wasm/node 3.1.54, @php-wasm/universal 3.1.54; PHP8.3.33; Node24.19.0.
Real test downloads: WordPress6.8.3, WooCommerce10.2.2; official WordPress Playground SQLite Database Integration bundled with @wp-playground/cli3.1.60. Real WP/Woo APIs were booted, not WordPress stubs. Database is SQLite in PHP's isolated memory filesystem; this does not certify MySQL concurrency.
The local NodeFS experiment was abandoned after filesystem/SQLite integrity errors during concurrent local runners. Final real-suite results use clean isolated memory files, serial execution and PRAGMA integrity_check after each case; no user database was involved.

Reproduction layout referenced by scripts:
  php-check/unit.php                       <- stub-tests.php.txt
  php-check/node_modules/                  <- npm install pinned PHP.wasm packages
  upgrade-v040/hpbd-operations/             <- updated plugin
  upgrade-v040/original/hpbd-operations/    <- original0.2 ZIP
  wp-staging/site/wordpress/               <- official WP source + Woo/SQLite drop-in
  wp-staging/*.php                         <- corresponding test sources

For real tests, configure wp-config with a local test URL, salts and no production credentials, WP_HTTP_BLOCK_EXTERNAL=true, DISABLE_WP_CRON=true, WP_ENVIRONMENT_TYPE=local. mu-plugin must intercept pre_wp_mail (return true) and pre_http_request (return WP_Error). The runner defines DB_PATH in a clean memory-backed filesystem. Install WP with wp_install, activate Woo and original HPBD for preservation checks, then mount the updated plugin. Separate fresh DB paths test HPOS and legacy storage; never switch a real site's authoritative order storage with unsynced orders.

Fixture control files used by runner:
install.php: WP_INSTALLING=true; load WP and wp-admin/includes/upgrade.php; wp_install a disposable site if needed; activate woocommerce/woocommerce.php and hpbd-operations/hpbd-operations.php using activate_plugin.
hpos-mode.php: update_option('woocommerce_custom_orders_table_enabled','yes'); update_option('woocommerce_custom_orders_table_data_sync_enabled','no') on the empty isolated HPOS test site only.
legacy-mode.php: update_option('woocommerce_custom_orders_table_enabled','no') on the separate empty legacy test site only.
Pathao source is separately supplied2.1.1, copied into the test site's pathao-courier folder. No credentials or external HTTP.

Final bundled logs and TEST-REPORT.txt name the checks that passed, expected stock SQL blocker and gates not exercised. These scripts use fixture-only accounts, products, orders, settings and role writes and must never be served/executed on a real shop.

0.4.1 runner: run-real-suite-041.mjs.txt targets upgrade-v041/hpbd-operations and preserves the working0.4.0 source under upgrade-v040/hpbd-operations. Additional test-041.php runs47 assertions in each HPOS/legacy database; final seed-040/verify-041-upgrade uses another clean DB and swaps0.4.0→0.4.1 without resetting that fixture. run-stubs uses the existing prior unit source with extra hook/asset/version mocks. Keep temporary test files outside any production webroot and suppress all mail/HTTP. Generated XLSX was also read independently using Python OpenPyXL; no workbook is shipped as customer data.
