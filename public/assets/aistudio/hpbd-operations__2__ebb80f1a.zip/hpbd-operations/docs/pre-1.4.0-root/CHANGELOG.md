Health Point BD Operations 1.3.2
Release date:25 October2026 (Bangladesh)
Base: user-supplied hpbd-operations.zip, runtime1.3.1.

Preserved: all uploaded file paths and the supplied centered print identity,25/30/35 density, exact contact/logo, product picker, product price display, staff role labels, customization classification and provider validations. No database migration, data reset, live-site deployment or real SMS performed.

Fixes:
- Unified plugin metadata, dashboard labels and asset version to1.3.2 (the supplied ZIP mixed1.3.1,1.2.8 and1.2.7).
- My order stats now routes to the actual activity page for staff and managers. Native Woo owner queries work with HPOS and legacy.25 objects per page, native status counts, page navigation. Removed loading every historical order object just to show100.
- Moderator indexed search reads only their created orders. Search remains read-only; existing edit/action permissions retained.
- Paste uses the established native server parser for email, multiline addresses, district aliases, city ambiguity and product search. Removed the local substring location matching that could map a division as a Woo district. Stale responses cannot overwrite a changed draft. Conflicts preserve all existing customer fields; explicit Use pasted customer instead replaces them and clears stale optional fields. Address approval still required.
- Same product/variant can be added as separate customization lines. Variation chooser is idempotent; double-tap on variant selection makes one request.

Runtime patch scope relative to uploaded1.3.1: hpbd-operations.php, includes/workspace.php, includes/search.php, assets/workspace.js. Other uploaded runtime files unchanged, including print CSS/design and provider adapter. Previous root docs preserved in docs/pre-1.3.2-root.

CURRENT VALIDATION
- PHP8.3 syntax30 files, JavaScript syntax11 files.
- Native print/activity/owner/routing suite120 assertions for HPOS +120 for legacy.
- Smart-entry/provider/COD/SMS-intercept backend51 assertions per mode; UI17 per mode.
- Real WordPress AJAX/JSDOM workflow62 assertions.
- Print DOM29 assertions; targeted variation-picker2 assertions.
Total469 behavioral assertions. All expected final markers verified. No real SMS/HTTP/mail sent; provider calls intercepted in isolated local staging. JSDOM does not validate physical browser layout, network transport or printer output. Uploaded print styling unchanged; previous visual reports remain historical. No claim that every possible plugin or hosting issue is resolved.

INSTALL
Back up database and current plugin first. Upload hpbd-operations-1.3.2.zip, choose Replace current with uploaded. Do not delete/uninstall. Clear asset caches, close old portal tabs and reopen. Existing settings/orders retained. Schema0.10.0 unchanged. To roll back, replace with the user's supplied1.3.1 ZIP or saved previous ZIP; data changes made during use are not reversed by plugin rollback.
