#1.2.5 — 24 October2026, Bangladesh

Screen-only compact print preview: smaller fixed-width selection/serial/ID/date/C columns, balanced name-phone width, remaining space for Product; reduced row/card/footer padding, clearer checkbox header,820px horizontal-scroll minimum. No data/permission/order/print API changes. All paper CSS retained byte-for-byte as prefix; new overrides apply only to screen media. Runtime/assets1.2.5; schema0.10.0. Prior guides archived under docs/pre-1.2.5-root/.
