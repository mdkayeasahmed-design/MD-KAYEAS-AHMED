#1.2.5 QA

HPBD OPERATIONS1.2.5 — FOCUSED UI VERIFICATION
24 October2026, Bangladesh

29 existing print-DOM interaction assertions passed,30 PHP8.3 runtime syntax files and11 external JS syntax checks passed. Earlier1.2.4's265 assertions are historical evidence, not a new full native-suite rerun for this styling-only patch.

Actual active CSS stack rendered with WeasyPrint70 under screen media at a wide desktop viewport, using seven native-derived presentation fixture rows and an empty/filled C sample. Preview PNG inspected for reduced horizontal gaps, balanced contact, full Product text, separated checkbox/Serial headers and compact rows/card/footer. Actual print-media sample with25 apron/contact orders still produces one physical A4 page; second PNG inspected. This is local renderer QA, not actual browser/device geometry.

Preservation check: all1.2.4 runtime PHP/JS/CSS sources byte-identical except main/version metadata, Workspace VERSION metadata and appended screen-only print-design CSS. Existing CSS is an unchanged prefix, with no new print-media override. Native print datasets,25-row grouping, exact invoice actions, cancellation/proof guards, COD/SMS/auth and source logo unchanged. No schema, data or production change.

DOM regression covers approval, selected-only cloning, timestamp refresh/fallback, stale cancellation response blocking dialog, duplicate-click validation, production print, continuous serials/page counts across25/25/5 and selecting one middle sheet. JSDOM/cached native fixture tests are not live HTTP/customer/provider tests.

Limits: target host/theme CSS, actual phone/browser geometry and physical printer/font/scaling remain untested. Existing long-text page-flow/provider limits remain in archived guides. No order text clipped or truncated for visual compactness.

Evidence: docs/125-*-results.txt and inert docs/test-source/125-*. ZIP CRC/path/byte checks at packaging.
