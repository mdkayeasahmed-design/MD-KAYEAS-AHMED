#1.2.5 compact preview

| Area | Behavior |
|---|---|
| Preview columns | Compact Serial/ID/Date/C, contact210px, product fills remaining width |
| Rows | Less padding; phone remains below customer name |
| Narrow screens | Horizontal scroll instead of collapsed columns |
| Paper | Existing25-order A4 grouping/layout retained |
| Invoice | Existing exact Order detail/Quick view Invoice / Print button retained |

No native business logic, authentication or payment/provider behavior changed. Actual browser/theme geometry still requires target-device checking.
