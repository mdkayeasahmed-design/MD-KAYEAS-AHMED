#Rollback from1.2.5

Replace files with1.2.4 without uninstalling, clear assets and reopen tabs. Earlier preview spacing returns; no database/order/payment migration needs reversing. Keep incoming orders/data intact.
