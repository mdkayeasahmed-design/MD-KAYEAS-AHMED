#Upgrade to1.2.5

Back up, upload ZIP and Replace current with uploaded; do not uninstall/delete. Close old tabs and clear relevant CSS/asset cache before reopening. Print center Preview now uses compact widths and row spacing. On small screens swipe the preview table horizontally. Existing Invoice / Print actions and25-order A4 settings remain; see docs/pre-1.2.5-root/UPGRADE-GUIDE.md for workflow. No live site changed during preparation.
