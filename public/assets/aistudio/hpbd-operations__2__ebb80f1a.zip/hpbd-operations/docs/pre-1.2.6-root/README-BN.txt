HEALTH POINT BD OPERATIONS1.2.5
Developer: Md Kayeas Ahmed | Phone:01929779381

Print preview আরও compact করা হয়েছে:
- Order ID, Serial, Date ও C-এর অতিরিক্ত percentage-width বাদ; ছোট নির্দিষ্ট মাপ।
- নাম/ফোন balanced contact column-এ; Product বাকি জায়গা ব্যবহার করে।
- Row/header padding ও footer-এর ফাঁকা জায়গা কম। Checkbox column-এ ছোট check header; Include/Serial লেখা লেগে থাকে না।
- ছোট screen-এ preview horizontal scroll থাকে, লেখা চেপে বা খাড়াভাবে ভাঙে না।

এটি screen-preview styling update। A4-এর25-order layout, নামের নিচে ফোন, Hold label, C nowrap, exact Invoice / Print button এবং native order/COD/SMS/access rules অপরিবর্তিত। Order details অথবা Quick view → Invoice / Print → approve → Print selected।

Backup → Upload hpbd-operations-1.2.5.zip → Replace current with uploaded। Delete/uninstall নয়। পুরোনো tabs বন্ধ করে CSS/asset cache পরিষ্কার করে খুলুন। Live site-এ ZIP install করা হয়নি।

Local preview rendering ও A4-এ25-row sample যাচাই;29 print interaction regression checks,30 PHP syntax,11 JS syntax পাস। Physical browser/printer পরীক্ষা হয়নি। আগের setup ও long-text pagination limits: docs/pre-1.2.5-root/README-BN.txt।
