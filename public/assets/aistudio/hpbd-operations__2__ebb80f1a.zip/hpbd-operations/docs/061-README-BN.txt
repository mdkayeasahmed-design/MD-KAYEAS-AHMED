HEALTH POINT BD OPERATIONS 0.6.1 — SAFE IN-PLACE STAGING UPGRADE

নতুন: Production-এ বিদ্যমান অর্ডার খুঁজে customization-এর preview দেখুন → প্রয়োজনীয় queue/text যাচাই ও নির্বাচন করুন → অনুমোদন দিয়ে task তৈরি করুন। লেখা/বানান/স্পেস বদলাবে না। আগে তৈরি task, native Woo seed বা অজানা pending ফলাফল আবার তৈরি করা হবে না। Task card থেকে মূল অর্ডার খুলতে পারবেন।

নতুন task Queued / Unassigned হবে; আগের editor থেকে কর্মী নির্ধারণ করুন। Task progress WooCommerce order status থেকে স্বাধীন। কোনো automatic পুরোনো অর্ডার backfill, SMS, courier booking, payment বা stock পরিবর্তন হবে না।

একই plugin folder/shortcode/URL ও পুরোনো data/settings রাখা হয়েছে। Plugins → Add New → Upload Plugin → এই ZIP → Replace current with uploaded। Delete/uninstall/reset করবেন না। আগে database ও wp-content backup নিয়ে staging-এ পরীক্ষা করুন। Main website-এর জন্য এখনও browser/MySQL/provider যাচাই বাকি।

PRODUCTION-REVIEW-061.md, FEATURE-CHECKLIST.md, QA-REPORT.md, UPGRADE-GUIDE.md ও ROLLBACK-GUIDE.md পড়ুন। সম্পূর্ণ আগের omnichannel পরিকল্পনা এই ছোট আপডেটে সম্পন্ন হয়েছে—এমন দাবি করা হচ্ছে না।

--- আগের 0.6.0 নির্দেশনা ---

HEALTH POINT BD OPERATIONS 0.6.0 — 0.5.5-এর ওপর নিরাপদ incremental update

প্রথমে test/staging site-এ ব্যবহার করুন। সম্পূর্ণ master roadmap-এর সব automation শেষ হয়েছে—এমন দাবি এই release করে না।

নতুন:
- আসল logo রেখে অতিরিক্ত HP mark বাদ; readable header/notice/export text; light/dark/mobile preferences রাখা।
- সব অর্ডারে Woo/Website ও Operations একত্রে; linked order একবার। Original Operations list & CSV আলাদা link-এ আছে।
- অনুমোদিত status mapping ও conflict notice; Production status স্বাধীন।
- Production board ও list, filters, order search, quick progress, exact পুরোনো task তথ্য ও history রাখা।
- Dhaka AM/PM, UTC index ও Bangladesh work-day filters, সহজ index health।
- AI ছাড়াও manual order form/local parser চলে। Optional direct OpenAI API key বা signed bridge; suggestion review/apply, কোনো auto order নয়। API খরচ ChatGPT Plus-এর বাইরে; key/bridge ও বাস্তব staging যাচাই প্রয়োজন।
- Daily print: hover/moving controls বাদ; Product Name & Quantity বেশি জায়গায়; ২৫ default / ৩০ density option। লম্বা তথ্য কাটা হয় না; বাড়তি পৃষ্ঠা হতে পারে।
- Meta Catalog manager diagnostics; Pathao 2.1.1 adapter অপরিবর্তিত; existing SMS/Woo hooks দ্বিতীয়বার ডাকা হয় না।

কীভাবে install/update করবেন: INSTALLATION.md। ZIP upload করে Replace current করুন; আগে plugin Delete করবেন না। পুরোনো dashboard URL, shortcode, user ও data থাকবে।
Feature status ও সীমা: FEATURE-CHECKLIST.md। পরীক্ষা: QA-REPORT.md / TEST-REPORT.txt। Rollback: ROLLBACK-GUIDE.md।

নিচের লেখা আগের version-এর ঐতিহাসিক documentation; বর্তমান status-এর জন্য ওপরের নথি অনুসরণ করুন।
---------------------------------------------------------------------
HEALTH POINT BD OPERATIONS 0.4.2 — PROVIDER ADAPTER STAGING BUILD
আগের working plugin-এর ওপর incremental update; সব integration-এর production verification সম্পূর্ণ নয়।

ইনস্টল
পরীক্ষার WordPress-এ hpbd-operations-0.4.2.zip Upload > Replace current with uploaded করুন। মূল plugin Delete করবেন না। আগে database ও wp-content-এর backup নিন। একই hpbd-operations directory, [hpbd_operations], roles/capabilities, admin menu ও dashboard URL থাকবে। অন্য provider plugin-গুলো ইনস্টল/সক্রিয় রাখতে হবে; এই ZIP-এ সেগুলো bundle করা নেই।

নতুন অর্ডার
Create Woo order > পণ্যের title/SKU/ID search > variable হলে website-এর attribute choices থেকে Size/Color/Sleeve/Code বাছুন > Add selected product। প্রতিটি product line-এর নিজস্ব option panel আসবে।
ThemeComplete 6.5-এর resolved local Builder এবং Global Forms থেকে field label, select/radio choices, independent checkbox, text/textarea ও upload নেওয়া হয়। Native conditional logic দিয়ে field দেখায়/লুকায়; required/format/length এবং fixed extra charge server-এ যাচাই হয়। প্রতিটি line-এর লেখা/নির্বাচন আলাদা থাকে। Native variation display Woo selectors দিয়ে পরিচালিত হয়; variation-dependent rules-ও পড়া হয়।
Supported options-এর final দাম Woo tax/shipping preview-তে অন্তর্ভুক্ত। Unsupported field/pricing/fee/repeater/weight/base-price override হলে স্পষ্ট error দিয়ে creation বন্ধ হয়। Unsupported charge বাদ দিয়ে সস্তা order তৈরি হয় না। এটি ThemeComplete-এর সব feature সমর্থনের দাবি নয়।

ছবি/Logo
Configured upload field থাকলেই reference upload আসে। Private JPEG/PNG/PDF সর্বোচ্চ 2 MB এবং provider-এর allowed extension ও server limit প্রযোজ্য। Public Media URL তৈরি হয় না। File HPBD private storage-এ থাকে; ThemeComplete-এর নিজস্ব public-upload/file-email lifecycle পুনর্নির্মাণ করা হয়নি। Browser multipart flow-এর বাস্তব staging verification বাকি।

ঠিকানা ও delivery charge
WC City Select + Area and thana plugin সক্রিয় থাকলে district অনুযায়ী তাদের configured city/thana আসে। সম্পর্ক server-এ যাচাই হয়। এই source division dataset দেয় না; division-এর optional mapping আগের settings-এ দেওয়া যায়। লেখা থেকে নিশ্চিত না হয়ে কোনো location জোর করে বসানো হয় না।
Shipping Rates by City 1.0.3-এর একই configured city table থেকে prepared query-তে rate পড়া হয়। Quantity multiplication হলে এই order-এর quantity ব্যবহার হয়, staff cart নয়। Duplicate/invalid city rate বন্ধ হয়। Woo zone-এর আগের supported shipping methods-ও থাকে।

Production queue
Workspace settings > ThemeComplete production queues-এ product ID ও Field ID অনুযায়ী NP/Embroidery/Engraving mapping দিন। Field ID product option panel-এ দেখা যায়। উদাহরণ: {"123":{"field-uid":"Engraving"}}। নাম দেখে queue অনুমান করা হয় না।
Dashboard-created এবং নতুন website checkout-এর mapped scalar customization থেকে task একবার তৈরি হয়। পুরোনো native ThemeComplete order metadata read করে search/print-এ দেখানো হয়; পুরোনো orders rewrite বা task backfill হয় না। বড়/complex array metadata provider editor-এ যাচাই করুন।

অন্য plugin-এর সংযোগ
WPC Size Chart 2.3.5: product-এ প্রযোজ্য chart sanitized অবস্থায় options panel-এ দেখা যায়।
Custom Order Status Manager 2.1: registered Woo label/status বজায় থাকে। Unknown status-এর paid/stock অর্থ অনুমান করে dashboard transition দেওয়া হয় না; পূর্ণ Woo editor ব্যবহার করুন।
Pre-Orders 2.3.1: product flag/release date এবং existing order date দেখা যায়। নতুন preorder/split/payment/scheduling lifecycle যাচাই না হওয়ায় dashboard creation বন্ধ; existing provider checkout ব্যবহার করুন।
Alpha SMS 1.0.19: existing configured Woo new-order/status hooks বজায় থাকে; HPBD থেকে দ্বিতীয় send করা হয় না। Account delivery/provider dedup পরীক্ষা বাকি।
Meta for WooCommerce 3.7.8: তার বর্তমান catalog/Pixel সংযোগ বজায় থাকে। এটি Messenger/comments/WhatsApp inbox automation নয়; আগের signed bridges-এর setup দরকার।
Pathao: আগের supplied 2.1.1 adapter ও original courier bridge থাকে। Real sandbox booking/tracking verification বাকি।

আগের সব documented সুবিধা
Manual new/edit/status, NP/Embroidery/Engraving lists, catalog/inbox/connections/help, original CSV, audit, HMAC/encrypted connectors, two-way Woo CRUD tools, private portal, print/CSV/XLSX, destination review, repeat draft ও diagnostics আগের মতো থাকে। আগের বিস্তারিত README docs/041-README-BN.txt-এ আছে।

Release gate
এই build প্রথমে test/staging-এ ব্যবহার করুন। আপনার live store/theme/settings/browser/mobile, real upload/printing/Bangla shaping, MySQL stock concurrency এবং actual SMS/Meta/Pathao/payment account verification বাকি। Server PDF, full product-line/refund UI, advanced analytics ও AI/channel automation এখনও পূর্ণ নয়। PROD ready বা সব integration complete বলা হচ্ছে না।
PROVIDER-INTEGRATIONS.md, FEATURE-CHECKLIST.md, TEST-REPORT.txt, UPGRADE-GUIDE.md ও ROLLBACK-GUIDE.md পড়ুন। কোনো live order, real notification, payment বা booking এখানে করা হয়নি।


AI Order Entry ও ঠিকানা শনাক্তকরণ — সীমাবদ্ধতা
এই পেস্ট-পার্সারটি নিয়মভিত্তিক; AI API-তে সংযুক্ত নয়। স্পষ্ট লেবেলযুক্ত নাম/ঠিকানা, বাংলাদেশি মোবাইল নম্বর ও ইমেইল শনাক্ত করতে পারে। Settings-এ বিভাগ → জেলা → থানা ম্যাপিং কনফিগার করা থাকলে লেখার মধ্যে একটিমাত্র ঠিকানা-মিল পেলে ফর্মে প্রস্তাব দিতে পারে। সব তথ্য যাচাই করতে হবে। পণ্য/ভ্যারিয়েন্ট/মূল্য স্বয়ংক্রিয়ভাবে নির্ধারণ করা হয় না। প্রকৃত AI-এর জন্য provider API credentials ও server-side integration প্রয়োজন। Live site-এ ইনস্টল করা হয়নি।


০.৪.৪: ম্যানুয়াল অর্ডারের নাম, পণ্য, ঠিকানা, রেফারেন্স, নোট ও সমস্যার বিবরণে সার্ভার-সাইড দৈর্ঘ্যসীমা যোগ হয়েছে। আপগ্রেডের আগে ডেটাবেস ও wp-content/plugins/hpbd-operations ফোল্ডারের ব্যাকআপ নিন।
