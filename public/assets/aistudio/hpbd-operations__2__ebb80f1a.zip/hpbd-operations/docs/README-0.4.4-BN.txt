HPBD Operations 0.4.4 — বাংলা ইনস্টল ও আপগ্রেড নির্দেশিকা

গুরুত্বপূর্ণ: এটি বিদ্যমান Health Point BD Operations প্লাগইনের incremental upgrade; নতুন আলাদা প্লাগইন নয়।

আপগ্রেডের আগে
1. WordPress database এবং wp-content/plugins/hpbd-operations ফোল্ডারের সম্পূর্ণ backup নিন।
2. সম্ভব হলে staging সাইটে আগে পরীক্ষা করুন।
3. WooCommerce, Pathao এবং অন্যান্য provider plugin-এর বর্তমান সেটিংস/সংস্করণ নথিভুক্ত করুন।

আপগ্রেড
1. WordPress Admin → Plugins থেকে পুরোনো HPBD Operations deactivate করুন। Delete করবেন না।
2. ZIP-টি extract করে নিশ্চিত করুন যে ভেতরের ফোল্ডারের নাম hpbd-operations এবং তার মধ্যে hpbd-operations.php আছে।
3. FTP/SFTP বা hosting file manager দিয়ে পুরোনো hpbd-operations ফোল্ডারের backup রেখে নতুন package-এর ফাইলগুলো একই ফোল্ডারে overwrite করুন। পুরোনো ফোল্ডার/ডেটা মুছবেন না।
4. Plugins পেজে প্লাগইন activate করুন। বিদ্যমান post metadata, options, operations records এবং provider credentials অক্ষত থাকার কথা; তবু staging-এ যাচাই করুন।
5. HPBD Operations → Help/Connections/Diagnostics খুলে version, storage এবং provider configuration যাচাই করুন।
6. অনুমোদিত কর্মী দিয়ে একটি বিদ্যমান অর্ডার দেখুন এবং test/staging-এ একটি অ-বাস্তব ডেমো রেকর্ড দিয়ে save, filter, print/export যাচাই করুন। বাস্তব courier booking বা message পাঠানোর আগে provider sandbox ব্যবহার করুন।

নিরাপত্তা ও সীমাবদ্ধতা
- 0.4.4 manual order text field-এর server-side দৈর্ঘ্যসীমা যোগ করে; এটি পূর্ণ issue tracker বা সম্পূর্ণ নতুন payment/AI/Meta integration নয়।
- Pathao booking/tracking, AI provider, WhatsApp/Messenger/SMS/email transport ও payment verification বাস্তব credentials/account ছাড়া live-tested নয়।
- live site-এ install/upgrade, browser testing, HPOS/legacy database matrix এবং external API test এই package build environment-এ চালানো হয়নি।

Rollback
1. প্লাগইন deactivate করুন।
2. backup করা hpbd-operations ফোল্ডার ফিরিয়ে দিন।
3. ডেটাবেস rollback কেবল তখনই করুন যখন backup নেওয়ার পরের অন্য সাইট পরিবর্তনও বিবেচনা করেছেন; অন্ধভাবে পুরোনো database restore করবেন না।
4. Provider-side booking/message/payment action হলে code rollback সেটি ফিরিয়ে নেয় না; provider dashboard-এ আলাদাভাবে যাচাই করুন।
