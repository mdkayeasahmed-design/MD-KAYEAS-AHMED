# Roll back 0.7.0

1. Pause staff changes, scheduled writes and external bridge traffic while assessing rollback. Take a fresh full backup first.
2. Replace only the `hpbd-operations` directory with your saved previous plugin directory/ZIP using a supported WordPress update or file restoration procedure. Do not uninstall or delete plugin records/options. Keep the same path and shortcode.
3. Restore the matching code version without resetting WordPress salts or connector secrets. Existing database schemas, options and order/task data remain available; no down-migration is required for this release.
4. New native Woo orders are real Woo records and must remain in the database. Additional per-item customization metadata uses the pre-existing `_hpbd_customization` schema, so the previous version can read it. New task product labels may not display on older code; the task and instructions remain.
5. If a database restoration is necessary, reconcile all orders, payments, messages and courier activity since the backup first. A whole-database restore can erase post-backup transactions. It is not required for an ordinary code rollback.
6. Verify dashboard URL, roles, old records, new Woo orders, exact custom text, print totals and provider setup after rollback. Only resume production after review.

The previous 0.6.2 ZIP SHA256 is listed in UPGRADE-GUIDE.md. Browser density preference is local to the device and can be cleared without changing store data. Temporary `hpbd_ops_http_index_lock` is additive and may be removed by an authorized maintainer only after confirming no worker is running; it contains no order data.
