HEALTH POINT BD OPERATIONS 0.4.0 — STAGING BUILD
এটি মূল 0.2.0-এর ওপর incremental upgrade। সম্পূর্ণ চূড়ান্ত automation release নয়।
FEATURE-CHECKLIST.md, TEST-REPORT.txt এবং UPGRADE-GUIDE.md আগে পড়ুন।

ইনস্টল / Update
1. পরীক্ষার সাইটের database ও wp-content-এর backup রাখুন। এই ZIP code update; আপনার site-এর database backup এতে নেই।
2. Plugins > Add New > Upload Plugin থেকে hpbd-operations-0.4.0.zip দিন।
3. একই plugin থাকলে Replace current with uploaded ব্যবহার করুন। পুরোনো plugin Delete করবেন না।
4. আগের HPBD Operations menu, একই frontend page এবং [hpbd_operations] ব্যবহার করুন।
5. পুরোনো অর্ডার ও settings মিলিয়ে নিন। New Operations order form এবং আগের workflow রাখা হয়েছে।

নতুন সুবিধা
- একই frontend URL-এ login করা অনুমোদিত কর্মীর জন্য fullscreen dashboard template। সাধারণ page-এর theme অপরিবর্তিত।
- Create Woo order: website product title/SKU/ID search, নির্দিষ্ট variation, একাধিক line, পরিমাণ, product mapping অনুযায়ী customization।
- নির্দিষ্ট variation-এর color/size তার নাম ও attribute অনুযায়ী আসে। Wildcard variation-এর জন্য adapter দরকার।
- ব্যক্তিগত reference image/PDF (প্রতি file সর্বোচ্চ 2 MB); সাধারণ Media URL নয়।
- customer form, pasted message থেকে editable phone/address suggestions, WooCommerce district selector এবং নিজের verified division/district/thana mapping।
- configured flat-rate/local-pickup ও শর্তহীন free-shipping method থেকে rate। Cart/coupon-নির্ভর বা অন্য shipping plugin-এর জন্য adapter দরকার।
- tax-সহ final preview; এরপর Pending WooCommerce order। একই create token আবার দিলে duplicate হয় না।
- Woo order details, notes/timeline, billing name/phone edit, সীমিত reviewed status transition; price/product/address/refund-এর পূর্ণ edit এখন authorized WooCommerce editor-এ।
- Global search: Operations + Woo canonical ID; customer, phone, email, products, SKU, customization, address, source/status, courier ID ও সাম্প্রতিক notes যেখানে indexed আছে।
- স্বতন্ত্র NP/Embroidery/Engraving production tasks; একটি order-এ একাধিক task, assignee, due date, issue/progress, reference, completion।
- Manager-approved date/status-filtered A4 browser print/order slips; browser Save as PDF। পুরোনো approved CSV export আছে।
- Customer phone দিয়ে order history; duplicate warning; সীমিত overview statistics ও low-stock check।
- background index reconciliation; settings-এ restart ও progress। এটি Woo order তৈরি বা status পরিবর্তন করে না।

Pathao
দেওয়া Pathao Courier 2.1.1 source-এর adapter অন্তর্ভুক্ত। আলাদা Pathao plugin সক্রিয় রাখুন। একই client ID/token/settings ব্যবহার হয়; এখানে আবার key দিতে হবে না। অন্য version হলে booking আটকে adapter review চায়। Existing consignment/status/delivery fee দেখায়। Merchant details link customer tracking link নয়।
কর্মী Website orders > Book Courier থেকে address, store/city/zone/area, weight ও collectable amount যাচাই করে Confirm & Book Courier চাপবেন। Live environment-এ এটি বাস্তব booking করতে পারে। নিজের sandbox পরীক্ষা ও approval ছাড়া live button ব্যবহার করবেন না।
Timeout বা অজানা response হলে retry বন্ধ থাকে। আগে merchant panel-এ ফল মিলিয়ে নিন। Original Pathao UI এবং HPBD UI থেকে একইসঙ্গে booking দেবেন না; দুই plugin-এর মধ্যে একটি shared native lock নেই।
Pathao না থাকলে আগের courier bridge অক্ষুণ্ণ আছে। এই ZIP আলাদা Pathao plugin bundle/install করে না।

Customization setup
Workspace settings > Product customization mappings-এ product ID অনুযায়ী field দিন। Parent product mapping variation-এও কাজ করে, variation-এর নিজস্ব mapping অগ্রাধিকার পায়। type: text / textarea / file। production: NP / Embroidery / Engraving। meta_key: মূল provider-এর public order-item metadata key (যাচাই করে দিন)।
Unknown third-party pricing, conditional logic, field generation বা design-preview provider স্বয়ংক্রিয়ভাবে supported নয়। Adapter contract দেখুন। Mapping না থাকলে customization field দেখাবে না; সব পণ্যে engraving ধরে নেয় না। Website-এর আগের customization metadata details-এ দেখা যায়; নিজে নিজে এই নতুন task schema-তে convert করা হয় না।

সতর্ক পরীক্ষার বিষয়
- Stock reservation-এর MySQL SQL আমাদের SQLite staging-এ চালানো যায়নি; ব্যর্থ হলে order Pending থাকে। Managed-stock confirmation/concurrency এখনো MySQL staging-এ gate।
- Browser local staging-এ পৌঁছাতে পারেনি; desktop/mobile visual, uploads ও browser print end-to-end যাচাই বাকি।
- Actual payment gateway, Meta/WhatsApp/SMS ও Pathao sandbox credentials দেওয়া হয়নি। Provider compatibility দাবি করা হচ্ছে না।
- Native AI replies, voice/image understanding, comment-to-DM, 30-minute timers, marketing/consent automation, payment verification, server-generated PDF/XLSX, advanced analytics এবং complete refund/returns workflow এখনও নেই।
- Print slip tax invoice বা provider-issued courier label নয়। Bangla shaping/font coverage ব্যবহারকারীর print device/browser-এ যাচাই করতে হবে।

দৈনন্দিন ব্যবহার
Users থেকে আগের HPBD Operations Staff/Manager roles ব্যবহার করুন। সব কর্মী Operations দেখতে পারেন; settings/exports manager-only। Original capability পরিবর্তন হয়নি। Gateway payment verification ছাড়াই prepaid order Processing করা যায় না। COD Processing করলে WooCommerce-এর stock/email side effects হয়। Production task status সম্পূর্ণ আলাদা।
Portal URL hosting/CDN cache থেকে exclude করুন। Authentication/permissions server-side। Fullscreen template শুধু authorized shortcode page-এ ব্যবহৃত হয়। Bridge secret encryption এবং signing contract অপরিবর্তিত।

Backup / rollback
ROLLBACK-GUIDE.md দেখুন। Code rollback করার পর নতুন Woo orders WooCommerce-এ এবং নতুন tasks/files/tables database-এ থেকে যায়; মূল 0.2 UI সেগুলো পরিচালনা করতে পারে না। এই plugin কোনো uninstall/reset routine যোগ করেনি।
