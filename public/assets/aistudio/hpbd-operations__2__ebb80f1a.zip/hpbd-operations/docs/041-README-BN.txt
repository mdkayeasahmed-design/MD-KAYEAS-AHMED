HEALTH POINT BD OPERATIONS 0.4.1 — STAGING UPDATE
মূল 0.2.0 এবং আগের 0.4.0-এর ওপর incremental update। সম্পূর্ণ production release এখনও নয়।

কোন ZIP ইনস্টল করবেন
hpbd-operations-0.4.1.zip পরীক্ষার WordPress-এ Upload > Replace current with uploaded করুন। পুরোনো plugin Delete করবেন না। আগে database ও files-এর backup নিন। একই shortcode [hpbd_operations], admin menu ও আগের dashboard URL থাকবে।

0.4.1-এ নতুন
- Woo order-এর last name/email, priority এবং independent fulfillment (Packing/Ready to pack/Packed/Dispatch) update। এটি Woo order status বা paid state নয়।
- Delivery destination edit-এর আগে actual supported Woo zone rate ও tax preview; নতুন ঠিকানা/মোট যাচাই করে Save। Product/line ID, customization, billing address ও existing shipping-item ID রাখা হয়।
- শুধু unpaid, unfulfilled, unbooked order-এ এই destination tool। Paid, stock-reduced, refunded, Packed/Dispatch, booked/unknown shipment, coupons/fees, VAT-exempt, currency mismatch বা multiple packages হলে পূর্ণ authorized Woo editor দরকার। মোট কমালে manager approval দরকার।
- Repeat order draft: customer ও বর্তমান website products নিয়ে form পূরণ; নতুন দাম/stock/fields/final preview আবার যাচাই করতে হবে। Draft নিজে order তৈরি করে না। Unknown provider metadata দেখলে warning; missing original field mapping হলে draft বন্ধ।
- Labelled Name/Phone/Email/Address/Thana paste suggestions। ভুল দৈর্ঘ্যের phone truncate করে না; একাধিক phone থাকলে নিজে বেছে লিখুন। সব suggestion editable এবং address confirmation দরকার।
- Daily Print Center: New Orders, NP, Embroidery, Engraving, Pending, Urgent, Packing, Dispatch, individual slips, order-summary invoice, internal address labels। Canonical order counting; মূল order number ও exact instructions থাকে।
- Manager-reviewed selected CSV এবং real XLSX export। Export-এর আগে order/task পরিবর্তিত হলে নতুন preview/review চায়। Formula-looking values XLSX-এ text, CSV-তে formula-safe। XLSX-এর জন্য PHP ZIP extension দরকার।
- Product mapping অনুযায়ী existing Woo item metadata print-এ পড়া হয়; provider reference কখনও HPBD private upload বলে দাবি করা হয় না।
- Diagnostics: schema, Woo storage mode, encryption/ZIP availability, cron/index state, mapped products, Pathao version/setup এবং unresolved write-এর bounded count। কোনো credential দেখায় না; unknown lock নিজে থেকে reset/retry করে না।

আগের সুবিধা থাকে
Original manual Operations order create/edit/status, source ও custom queues, filters, approved legacy CSV, audit, inbox, encrypted connectors/HMAC bridge, fullscreen private portal, Woo catalog/search/create/limited management, independent production tasks এবং source-reviewed Pathao 2.1.1 adapter।

Pathao
আগের আলাদা Pathao plugin রাখুন। দেওয়া 2.1.1 source-এর existing settings/token ব্যবহার করে; আবার key দিতে হবে না। Staff-reviewed booking; unknown result হলে আবার booking নয়। Original Pathao UI ও HPBD UI থেকে একই order একসঙ্গে book করবেন না। Live booking বাস্তব shipment/charge করতে পারে—sandbox যাচাই ও আপনার সিদ্ধান্ত ছাড়া ব্যবহার করবেন না।

এখনও মূল website-এ চালানোর যাচাই বাকি
- MySQL-এ concurrent stock reservation; আমাদের SQLite test backend সেই MySQL SQL চালাতে পারে না, তাই ব্যর্থ হলে order Pending-ই থাকে।
- Browser/mobile real UI, multipart upload/download, print pagination ও Bangla font shaping।
- Actual Pathao sandbox booking/tracking/webhook এবং আপনার payment/customization/shipping/theme plugins।
- সম্পূর্ণ product-line edit/refund UI, server-generated PDF, advanced analytics, AI/native Meta/WhatsApp/payment automation এখনও অসম্পূর্ণ।

কর্মী
আগের HPBD Operations Staff/Manager roles রাখুন। Exports/settings/diagnostics manager-only। Refund/discount/delete-এর নতুন endpoint নেই। Website ও dashboard-created Woo order একই Woo storage থেকে পড়ে; পুরোনো manual Operations data আলাদা থাকে, explicit link ছাড়া পরিবর্তন হয় না।

FEATURE-CHECKLIST.md, TEST-REPORT.txt, UPGRADE-GUIDE.md ও ROLLBACK-GUIDE.md দেখুন। Portal URL hosting/CDN cache থেকে exclude করুন। এই ZIP আপনার live database backup নয়।

Woo order tax preview/recalculation-এর জন্য WooCommerce7.6+ দরকার। হিসাব WooCommerce-এর billing/shipping/base/local-pickup tax configuration অনুযায়ী হয়।
