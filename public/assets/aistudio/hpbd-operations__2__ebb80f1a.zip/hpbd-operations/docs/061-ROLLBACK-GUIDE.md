# 0.6.1 → 0.6.0 rollback

Pause staff writes and inspect any interrupted task preparation before replacing files. Upload the unchanged `hpbd-operations-0.6.0.zip` using the same Replace flow; keep directory `hpbd-operations`. Do not uninstall, delete orders/tasks/options, clear unknown locks or rotate WordPress salts.

Existing and 0.6.1-created production tasks remain readable/editable in 0.6.0. New review UI and canonical task links disappear; additive source metadata/options can remain for re-upgrade. The higher stored version marker is intentionally retained. Successful Woo native seed markers keep the original checkout protection. File rollback does not delete or reverse tasks, stock/status/provider actions already taken by staff.

The unchanged local 0.6.0 backup has SHA256 `58345de07fad6d3f12c8c8b89c7b9f01dafdc55adc6b50a5e442a133fd3bc56e`. Site database/wp-content backup and actual restore validation must be performed on your environment. Do not overwrite newer operational work with a stale database snapshot.

--- Historical rollback notes ---

# 0.6.0 → original 0.5.5 rollback

1. Keep an untouched copy of the supplied `hpbd-operations-0.5.5.zip` before installation. Its SHA256 is `a1a3eab4591b3561ac30d3baa00c15e57853a50c33938c1b9fad055bb9664571`.
2. Pause staff writes and disable AI in new preferences if it was enabled. Record pending order/shipment actions and any newer orders. Do not delete unknown request locks.
3. Replace plugin files using the original ZIP through the same WordPress upload/replace flow (or a trusted file manager). Keep folder `hpbd-operations`; do not uninstall or delete its database records.
4. Original 0.5.5 ignores new preference options/metadata; original orders, tasks, shortcode, roles and provider settings remain usable. It will show the original UI and original separate Operations list. Stored higher version markers are deliberately not downgraded.
5. If restoring a full database backup is necessary, reconcile orders, payments, SMS and courier actions created after that backup first. Blind database rollback can lose newer work or duplicate provider actions. Restoring files does not reverse real status/email/SMS/stock/courier side effects.
6. For a full environment restore, restore matching wp-content and WordPress salts from the reviewed backup. Never rotate salts as a rollback step for this plugin's encrypted secrets.

No destructive reverse migration is included or needed. New metadata/options may remain for later re-upgrade. All actual 0.5.5 metadata/options were compared before/after an isolated upgrade in both Woo storage modes; live backup restoration was not performed.

---
Historical rollback notes follow.

# 0.4.2 → 0.4.1 rollback

Keep hpbd-operations-0.4.1.zip and a current database/wp-content backup. Pause writes, reconcile interrupted creations/destination edits/shipments, then upload 0.4.1 and choose Replace current with uploaded. Never Delete/uninstall or restore a stale whole database over new orders. Provider plugins/configuration remain installed and untouched.

0.4.2-created Woo orders, exact JSON/native item metadata, chosen wildcard attributes, private references, production tasks, index and request locks remain stored. 0.4.1 does not expose the new provider controls or automatically create website checkout production tasks. Use the full Woo editor to view provider metadata; do not try to recreate the same order. Queue mappings may remain for re-upgrade. Rolling back code cannot undo a shipment, message, payment or already saved destination.

The release backup in the working package delivery is the unchanged previous 0.4.1 artifact; obtain your site's own plugin/database backup before installation. Do not include production database credentials in a support ZIP.

# 0.4.1 → 0.4.0 rollback

Keep hpbd-operations-0.4.0.zip and a current database/files backup. Pause writes, reconcile in-flight destinations/shipments, upload 0.4.0 and choose Replace current with uploaded. Do not uninstall/delete or restore an old database over newer orders. Existing data is retained; the old UI will not expose new fulfillment/destination/diagnostic tools. WooCommerce retains saved delivery/customer changes and exact original order/item IDs. Additive metadata and destination request locks should be kept for re-upgrade.

For rollback further to the original 0.2.0, follow the original guide below.

# Rollback without deleting order data

1. Pause staff writes and inspect any in-flight order, reply or courier request. An unknown result requires provider/order reconciliation; code rollback cannot undo an external shipment, email or payment.
2. Preserve a current database/wp-content backup before rollback, including any orders created since upgrade. Do not restore an old full database over new customer orders.
3. In WordPress, upload the original `hpbd-operations-0.2.0.zip` and choose Replace current with uploaded. Do not click Delete or run an uninstall/reset tool. Alternatively replace only the plugin directory's code from the original ZIP while retaining the database.
4. The original init migration may set its own version option back to 0.2.0; original event table schema is unchanged. Saved portal page, roles, manual records, old metadata and bridge configuration remain accessible.
5. New tables, files, production tasks and new Woo orders remain in the database. The 0.2 UI does not display/manage the new modules; use WooCommerce for new Woo orders. Do not remove the new tables or locks if you plan to re-upgrade.
6. Disable the new scheduled `hpbd_ops_reconcile` event through your staging/host cron tooling if needed. While old code is active its callback is absent and it cannot change any order. Re-upgrading re-registers indexing.
7. Pathao is a separate plugin. Existing consignment metadata/shipments are unaffected by replacing HPBD code. Keep the Pathao plugin in place. Never rebook a shipment as a rollback step.
8. Re-test original dashboard login, manual order workflows and bridge authentication with test data. WP salts must be retained or original encrypted bridge secrets must be entered again.

Schema reversal is deliberately non-destructive: unused additive objects are retained. A manual schema removal needs a separate data-export and retention decision and is not included.
