#1.2.3 — 24 October2026, Bangladesh

Desktop sidebar is fixed from the top, search row occupies the content area to its right, redundant desktop hamburger is hidden. Mobile retains its original single-row Menu/Search/Bell/More behavior. Sidebar uses a bounded independent scrollbar and explicit border-box width.

Print-center tables add Mobile Number and Order Date. New Orders has seven columns, with single-line C codes and landscape A4. Native order instant converts to Bangladesh date/time; printed and invoice timestamps omit timezone suffix while retaining Asia/Dhaka conversion and repeat-print refresh. On-hold customer cells include the actual gateway title in contrasting color; export values retain a plain-text hold/method annotation.

Cancellation checked before expensive cancelled-item parsing, across live/index datasets, linked manual/native records, invoice/legacy slips and production rendering. Fresh manager/batch-bound validation runs before the browser print dialog, rejecting expired, changed or cancelled batches. Production proof also rejects cancelled orders; visible task footer counts only rendered tasks. Repeated clicks cannot launch duplicate concurrent validation. Existing CSV/XLSX approval/fresh-state logic remains.

Runtime/assets1.2.3; SQL marker0.10.0. No live deployment, order mutation, financial transfer or real messaging. Previous documentation archived under docs/pre-1.2.3-root/; schema/data preserved.
