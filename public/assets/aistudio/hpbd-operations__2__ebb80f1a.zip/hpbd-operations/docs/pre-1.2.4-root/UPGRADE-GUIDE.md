# Upgrade to1.2.3

1. Back up plugin/database. Upload ZIP and Replace current with uploaded; do not uninstall/delete.
2. Close existing tabs, clear relevant asset cache, open the private Operations page again. Public page cache must exclude this URL.
3. Desktop: sidebar stays at the top; search is to its right. No extra hamburger button. Mobile: use Menu and More as before. Check target theme/browser scrolling and zoom.
4. Print center: make a NEW preview. Seven-column daily lists use A4 landscape; invoices/slips/labels remain portrait. Customer Mobile Number and native Order Date appear in print-center tables. Exports now have these new columns too; update any external column-position assumptions.
5. Cancelled orders are excluded, including production/slip/invoice guards. A fresh signed-in manager check occurs immediately before the dialog. If an order changed/cancelled or the reviewed batch expired, preview and approve again. Do not bypass cancellation warnings with stale screenshots/PDFs.
6. On-hold payment method is printed beside the customer name in contrasting color; this is the gateway title, not a claim of received funds. No new partial-payment reconciliation.
7. Printed time remains Bangladesh time with no visible timezone suffix. Keep browser-provided URL/date headers separate; disable them in the dialog if desired. C codes do not wrap.
8. Existing native shipping/payment/customization/SMS/employee setup stays in place. Physical phone/printer, color settings, Bangla font and host-specific CSS still require target checks.

No live website was changed while preparing this ZIP.
