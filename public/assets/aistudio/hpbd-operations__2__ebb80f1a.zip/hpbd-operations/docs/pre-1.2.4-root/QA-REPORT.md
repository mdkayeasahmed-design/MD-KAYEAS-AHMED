#1.2.3 QA

HPBD OPERATIONS1.2.3 — CURRENT FOCUSED VERIFICATION
24 October2026, Bangladesh

470 local assertions passed: native print backend72 HPOS +72 legacy, print DOM22, responsive toolbar242, existing real AJAX/DOM62.30 PHP8.3 TOKEN_PARSE runtime files and11 external JS syntax checks passed. Historical totals are retained evidence, not a fresh full rerun.

Coverage: native/Operations cancellation before item parsing, every print layout excludes cancelled IDs, final reviewed batch accepts current selections then rejects cancellation after preview, invoice renderer and production proof reject cancelled order, production preview omits cancelled instructions. Print columns/values match for every layout; exact seven daily columns; phone leading zero; native UTC instant prints correct Bangladesh Order Date with no timezone suffix. Two on-hold gateways preserve actual bKash/bank titles next to names; exact C value EN / EMB / NP remains one cell. Existing native totals/discounts/COD, auth guard, escaping, manual records and portrait invoices retained.

DOM: cancellation response prevents browser dialog/print root, actionable error, one concurrent validation per double tap, valid final check permits print. Timestamp refresh, no timezone label, fallback formatting, selected-only cloning, production validation and cleanup. Toolbar tests cover five native roles, responsive320/640/1023/1024/1440/375 transitions, original nodes/handlers, mobile exclusive popups, search/density/language, sidebar fixed/hamburger hidden screen rules. Native AJAX tests cover order creation/customization, profile/avatar, native updates and reviewed/stale production print under both stores. Expected JSDOM navigation warnings do not represent failed assertions.

Visual: actual plugin invoice, seven-column New Orders with two hold methods and manual invoice rendered using active CSS in WeasyPrint70. Three A4 pages inspected; daily sheet landscape, invoices portrait. C codes stay on one line, phone/date readable, hold labels contrast, timezone suffix absent. This is local rendered print QA, not physical browser/device or printer testing.

Environment: WP6.8.3, Woo10.2.2, PHP8.3.33 Wasm/SQLite, HPOS +legacy. HTTP/mail intercepted; no live site, messages or financial actions. Schema0.10.0; original logo and native order/COD/SMS/customization business sources preserved. All1.2.2 paths retained.

Limits: target CSS/scroll ancestors, browser zoom/mobile keyboard, actual print pagination/font/color, MySQL production load, minimum-version runtime and real provider delivery remain unverified. Colour may become monochrome in printer settings, but the On hold/method text remains. Existing externally saved PDFs cannot be recalled; final print validation confirms state at the request instant and cannot make later cancellation/printing atomic. Unknown custom cancellation statuses beyond native cancelled/Operations Cancelled require explicit mapping; refunded is not silently treated as cancelled. On-hold method is not paid confirmation. No server PDF generation added.

Evidence: docs/123-*-results.txt and inert docs/test-source/123-*. Earlier root guides archived. ZIP CRC/path/byte checks performed at packaging.
