HEALTH POINT BD OPERATIONS1.2.3
Developer: Md Kayeas Ahmed | Phone:01929779381

আপনার নতুন screenshot অনুযায়ী:
- Desktop sidebar ওপর থেকে fixed; ডান পাশে search toolbar। Desktop-এর বাড়তি তিন-লাইনের Menu hidden। Mobile-এর Menu/Search/Bell/More এক সারিতে বহাল।
- Print list-এ7 column: Serial No., Order ID, Customer Name, Mobile Number, Order Date, C, Product Name & Quantity। সাত কলামের তালিকা A4 landscape; invoice portrait।
- C-তে EN / EMB / NP এক লাইনে, মাঝপথে EMB ভেঙে যাবে না।
- Hold অর্ডারে customer name-এর পাশে আসল payment method title (যেমন bKash / Direct bank transfer) আলাদা রঙে। CSV/XLSX-এ plain text একই তথ্য থাকে।
- Print-এর date/time বাংলাদেশ সময়েই, কিন্তু BST/UTC/timezone suffix নেই। Order date আলাদা।
- Cancelled Woo/Operations order print dataset থেকে বাদ। Invoice, legacy slip এবং production task print-এও cancellation guard। Print/export review-এর পর cancellation হলে final check-এ আটকে fresh preview চাইবে।

নাম/ফোন/পণ্য/customization/মোট native source থেকেই। কোনো live order/payment/status পাল্টানো হয়নি। Invoice logo/contact, COD rule, autofill, SMS queue, employee access এবং manager workflow রাখা আছে। আগের setup docs/pre-1.2.3-root/README-BN.txt-এ।

Backup → WordPress Plugins → Upload hpbd-operations-1.2.3.zip → Replace current with uploaded। Delete নয়। পুরোনো tabs বন্ধ করে asset cache পরিষ্কার করে খুলুন।
Print center-এ fresh Preview করুন, selection/approval দিন, তারপর Print selected। পুরোনো10-minute print batch বা changed/cancelled order হলে নতুন Preview দরকার। Browser-এর আলাদা URL/page headers চাইলে print dialog থেকে বন্ধ করুন।

470 local assertions,30 PHP syntax এবং11 JS syntax পাস। A4 sample render দেখা হয়েছে। Live install, বাস্তব ফোন/browser geometry বা physical printer যাচাই করা হয়নি। রঙ দেখতে color printing/Save PDF ব্যবহার করুন; monochrome-এও On hold ও method text থাকে।
