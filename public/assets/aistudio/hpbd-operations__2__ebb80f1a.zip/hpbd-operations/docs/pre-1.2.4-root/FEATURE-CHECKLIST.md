#1.2.3

| Area | Current behavior |
|---|---|
| Desktop | Fixed top sidebar, search row to right, duplicate Menu hidden |
| Mobile | Single-row Menu/Search/Bell/More retained |
| Daily print | Seven columns including mobile and order date; C codes do not wrap |
| Hold | Actual native payment title beside customer name; contrasting color, plain text in exports |
| Dates | Bangladesh time; visible timezone suffix removed |
| Cancellation | Excluded in print/export datasets, invoice/slip/production; final batch validation blocks stale cancelled orders |
| Existing operations | Native shipping/customization/COD/SMS/auth/roles retained |

A4 landscape for expanded tables; portrait invoice. Print-center columns change CSV/XLSX output order. Cancelled orders remain in native history; only print/export inclusion changes. Target-device visual/provider limits remain in prior guides.
