# Rollback from1.2.3

Replace plugin files with1.2.2 without uninstalling; clear assets and reopen tabs. No schema or order/payment data mutation was introduced. The previous document/sidebar layout and print columns return. Cancellation-before-print protection introduced here will no longer apply in the older version, so review selections manually. Do not restore an old database over newer incoming orders. Earlier fee/SMS considerations remain in archived guides.
