# Upgrade to 1.2.0

1. Back up database and existing plugin; validate on staging first.
2. Upload hpbd-operations-1.2.0.zip in WordPress Plugins and choose Replace current with uploaded. Keep the existing folder/shortcode. Do not uninstall/delete.
3. Close old portal tabs, clear relevant asset/page cache and exclude /hpbd-operations/ from page caching. Open the portal again.
4. Existing accounts, settings, roles and operational data stay in place. No schema/data reset. Employee application workflow is unchanged; see docs/pre-1.2-root/UPGRADE-GUIDE.md.
5. Manager Settings → Smart order / COD: default is products only, excluding tax/shipping. For a 1000 product, delivery90, COD fee10, total1100; delivery130 makes total1140. Non-COD, free shipping and other rates get no new fee. If you choose order basis it includes pre-fee delivery/tax.
6. Check the website's real shipping zone/rate, enabled payment gateway, exact district/upazila lists and optional customization fields. Paste customer information, review address, choose products/options, Preview, confirm, Create Pending order.
7. Existing Alpha SMS1.0.19: enable Pending customer template, native API key/balance and working WP/server cron. Manager sees SMS configuration; order result distinguishes queue/provider handler state. Other providers keep native hooks. Do not resend an uncertain notification before checking order notes/provider logs.
8. Check on actual desktop/mobile: fixed top/sidebar, Menu/bell/More, keyboard and bottom action clearance. Imported isolation targets known storefront bars only; unknown theme widgets may require selector adjustment.
9. After any timed-out create inspect order list before retrying. A slow response can still have saved an order. No blind automatic create retry is added.

No live deployment or production messages were made while preparing this ZIP.
