# 1.2.0 — 24 October 2026

Merged the user-supplied 1.1.1 patch into 1.1.0 without duplicate fee/copy handlers. Runtime/assets version 1.2.0; SQL schema remains 0.10.0.

- Customer-first paste workflow, debounced parsing, structured Copy format, multiline address/contact/note/payment parsing, exact installed locations, district aliases and a short labeled-product search.
- Default COD service fee is 1% of merchandise totals excluding tax/shipping, only on BDT COD with shipping exactly 90 or 130. Quote exposes fee rows plus the 1.1.1 cod_fee compatibility alias. Creation and editable destination recalculation retain one marked fee. Existing unrelated fees remain protected.
- Fewer initial requests; on-demand bell, no page-load indexing, single explicit index update, per-line option request reuse, create/quote timeout feedback and 25-row default pagination.
- Fixed desktop sidebar/top controls, embedded sidebar starts at top, customer paste before catalog search, compact header and safe-area bottom clearance. Imported storefront isolation applies only on the Operations shortcode page.
- Accept ThemeComplete 6.5 native variation choices when only its styled-control presentation is disabled. Required text, variation identity, provider pricing and unsupported-formula guards remain.
- Reviewed Alpha SMS 1.0.19 initial alerts are queued for HPBD orders only, use native provider settings/templates, and avoid synchronous SMS HTTP in create. Queue status, stale-status skipping, single dispatch and scoped TLS/timeout settings are explicit.
- Employee entry/approval, roles, existing integrations, printing, QC and manual remittance remain available. No live deployment, messages or funds movement occurred.

Previous root release documents: docs/pre-1.2-root/. Supplied PATCH-NOTES-1.1.1.md and RELEASE-1.1.1.md are historical patch notes; current behavior is documented here.
