HEALTH POINT BD OPERATIONS 1.2.0
Developer: Md Kayeas Ahmed | Phone: 01929779381

আপনার 1.1.1 limited patch-এর COD rule, Copy format ও storefront toolbar isolation মিলিয়ে এই আপডেট। আগের employee Login/Register/Forgot, manager approval, order, production, QC, complaint ও manual COD workflow রাখা হয়েছে।

নতুন সুবিধা:
- New order-এর শুরুতে customer information paste; multiline address, phone, email, district/upazila, payment ও note চেনার চেষ্টা এবং ছোট Copy format।
- Website-এর actual location list থেকে exact district/upazila নির্বাচন; বাংলা district alias ও কিছু প্রচলিত upazila alias। অস্পষ্ট মিল হলে কর্মীকে বাছতে হবে। Preview-এর আগে ঠিকানা review আবশ্যক।
- Product লেখা আলাদা করে ছোট search query হয়। সঠিক product/variation/customization কর্মী বাছবেন; নাম engraving স্বয়ংক্রিয়ভাবে অনুমান করে বসানো হয় না।
- COD এবং delivery 90/130 হলে পণ্যমূল্যের ওপর 1%; delivery/tax বাদ। পণ্য1000 + delivery90 + COD10 = total1100। Preview ও saved Woo fee একই। Settings-এ চাইলে delivery/tax-সহ basis বাছা যায়।
- অপ্রয়োজনীয় initial indexing/notification request কমানো, unchanged options reuse, default25 rows (50/100 পাওয়া যায়), external Google font বাদ। নির্দিষ্ট loading-time বা 1-minute guarantee নয়।
- Desktop sidebar ওপরে fixed, top controls compact/sticky; mobile single-row header ও More popup; নিচে safe-area blank space। Operations পেজে পরিচিত storefront floating bars লুকায়।
- ThemeComplete6.5 presentation-only variations_disabled flag-এর জন্য apron variation আটকাবে না; actual native size/sleeve এবং required customization validation বহাল।
- Reviewed Alpha SMS1.0.19-এর initial Pending notification background-এ যায়; existing API/template/balance ও working cron প্রয়োজন। Create response-এ SMS status পাওয়া যায়। Provider request processed মানেই handset delivery verified নয়।

ইনস্টল: Database/plugin backup → WordPress Plugins → Add New → Upload ZIP → Replace current with uploaded। Delete/uninstall করবেন না। পুরোনো portal tab বন্ধ করে asset cache পরিষ্কার করুন।
Manager → Team & setup → Settings: Smart order/COD settings ও website SMS setup যাচাই করুন।

এই ZIP live website-এ install করা হয়নি। TEST-REPORT.txt-এ local পরীক্ষার ফল ও সীমাবদ্ধতা আছে।
