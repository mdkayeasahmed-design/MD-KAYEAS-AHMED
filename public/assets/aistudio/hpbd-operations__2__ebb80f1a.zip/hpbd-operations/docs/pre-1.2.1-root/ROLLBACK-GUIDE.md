# Rollback from 1.2.0

Keep a pre-update database/plugin backup. Replace plugin files with the previous tested version without running uninstall. Existing orders and employee data remain; SQL marker stays0.10.0.

Orders created by1.2.0 contain a normal WooCommerce COD fee item where applicable; rolling back plugin files does not reverse an order charge or remove its order history. Review saved quotes/orders before changing amounts. Restore a database backup only with a deliberate plan for orders received since that backup.

Before rollback, review queued hpbd_ops_initial_sms jobs and provider notes. An old plugin cannot execute the new worker hook; unsent queued messages may require a controlled manual follow-up after confirming no prior SMS. Do not blindly resend uncertain results.
