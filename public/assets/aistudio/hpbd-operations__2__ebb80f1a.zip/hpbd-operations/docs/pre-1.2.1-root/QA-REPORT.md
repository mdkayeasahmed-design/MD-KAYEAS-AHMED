# 1.2.0 QA

HPBD OPERATIONS 1.2.0 — TEST REPORT
24 October 2026

2,369 distinct local assertions passed: prior regression2,238 + Smart backend102 + Smart UI29.
Smart split runs each contain51 backend and15 UI checks; the shared CSS-parse check is counted once (not twice). PHP8.3 TOKEN_PARSE passed29 runtime files. node --check passed all10 external JS files (9 active/enabled-on-demand; retained mobile-topbar remains inactive).

REGRESSION GROUPS
Stub79; acceptance224; production148; customization130; native providers138;
real WordPress/Woo264; workspace102; workbench170; access208; DOM62;
experience/handoff102; mobile53; QC/issues/COD/setup207; header207; identity144.

NEW SMART COVERAGE
Both HPOS and legacy run actual WooCommerce quote/create/destination flows. Merchandise-only and optional pre-fee order bases;90/130 and excluded shipping/prepaid cases; tax exclusion; fee persistence and repeat-call idempotence; native payment; label/Bengali/exact district/upazila/multiline parsing; ambiguous review; shortened real catalog search; cod_fee compatibility; portal-only body isolation and ordinary-page preservation; explicit index queue removal.
Actual ThemeComplete6.5 fixture disables styled variation presentation while preserving native size40/sleeveFull identity, required customization text and25-unit option price. Invalid attributes and missing required text still reject.
Alpha SMS1.0.19 native callback: zero HTTP during order creation, one order-ID-only scheduled job, reused provider template and correct amount, TLS enabled and timeout15, no duplicate dispatch, stale Pending alert skipped after a later status. HTTP is intercepted; no real SMS sent.
Real rendered portal + JSDOM + actual PHP AJAX: paste fills customer/destination before catalog, Copy format, no initial background indexing/notification request, unchanged option response reused for preview, fee breakdown/total, double tap one create, displayed SMS status, previous optional contact cleared for changed phone, bell lazy loading.

ENVIRONMENT / METHOD
WordPress6.8.3, WooCommerce10.2.2, PHP8.3.33 Wasm, SQLite integration; both HPOS and legacy storage. Native provider plugin fixtures mounted in isolated runtime. Email/HTTP intercepted by test setup. Tests run with valid and forged capability/nonce boundaries in existing access/identity suites. Abrupt/incomplete Wasm attempts were discarded; full expected counts and final markers determine completion. New fixture explicitly creates its shortcode page to test body classes; it does not assume activation auto-created a page in the isolated installer.
Navigation and notification expectations changed only for the intentional lazy bell/imported mobile safe-area rule. Body isolation uses body_class in the full-screen template too. Backend prices/options are validated afresh despite client response caching.

PRESERVATION
All delivered1.1.0 and supplied1.1.1 file paths retained. Logo, bridge contracts and print-center sources byte-identical. SQL schema marker0.10.0; runtime1.2.0. No uninstall/data reset. Historical release docs are archived; their old totals/scope are not extra current assertions.

LIMITS
These are local PHP/native-handler/AJAX/DOM/static-CSS tests, not a live healthpointbd.com deployment or physical browser/device/print inspection. Production MySQL/MariaDB, target-host load/concurrency, actual theme geometry/keyboard, minimum-version execution, email receipt, real provider delivery and actual SMS handset receipt were not tested. No production latency or one-minute-entry benchmark was measured.
Autofill uses actual lists and documented aliases; unknown/ambiguous names need review. Product/variant and engraving/name fields require staff choice. Copy format is a helper, not a guarantee every arbitrary pasted message can be parsed.
Alpha background adapter targets reviewed1.0.19 only; other versions/providers retain their native hooks and may still block on their network. Native settings, balance and working cron required. Processed handler does not prove provider delivery; no blind retry for uncertain messages/creates.
Existing optional provider, financial, payment/refund and automation limitations remain as stated in preserved contracts and docs/pre-1.2-root/TEST-REPORT.txt. Manual COD ledger does not move money.

EVIDENCE
Complete current logs: docs/120-*-results.txt. Inert test sources: docs/test-source/120-*.
ZIP CRC, path preservation and source hashes are verified during packaging.

