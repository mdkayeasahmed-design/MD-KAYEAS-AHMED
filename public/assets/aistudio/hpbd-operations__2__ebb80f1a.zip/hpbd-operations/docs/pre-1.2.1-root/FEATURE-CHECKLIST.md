# HPBD Operations 1.2.0

| Area | Current behavior | Required review/setup |
|---|---|---|
| Paste / Copy format | Customer-first paste, labeled contact/address/payment/note parsing, short product search | Staff confirms destination, product, variation, quantity and customization; no blind product auto-add |
| Location | Actual native/configured lists, district aliases, selected common city aliases | Ambiguous or unknown input requires manual choice; not universal geocoding |
| COD | 1% merchandise excluding shipping/tax on BDT COD with shipping90/130; preview and native fee persisted | Manager can disable or choose pre-fee order-total basis; external checkout rules are independent |
| Apron / EPO | Native size/sleeve retained when ThemeComplete6.5 disables styled controls | Required fields and supported-provider checks still apply; other versions need review |
| Customer SMS | Reviewed Alpha1.0.19 initial Pending template runs in background; status returned | Native API/template, balance and cron needed; actual phone receipt unverified |
| Performance | Lazy bell/data, no automatic entry indexing, reused option response, default25 rows, system fonts | No measured production latency or 1-minute guarantee; backend still validates fresh prices/options |
| Layout | Top sidebar/controls, single-row mobile Menu/More, bottom clearance; known floating bars hidden on portal only | Physical phones and target theme still require visual review |
| Employee access | Login/Register/Forgot, verified email then Manager approval, dedicated work roles | Working mail/reset and existing authentication setup needed |
| Manager workflow | Existing orders, production, stock, history, QC, complaints, manual COD, employee management retained | Manual COD records do not transfer money; integrations retain setup/permission limits |

Prior detailed access and integration scope is preserved in docs/pre-1.2-root/ and historical contracts. This release does not claim that every optional external integration is connected.
