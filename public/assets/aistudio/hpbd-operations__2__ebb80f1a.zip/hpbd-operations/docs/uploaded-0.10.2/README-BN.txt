HEALTH POINT BD OPERATIONS — 0.10.0

আগের plugin-এর উপরে update; একই directory/main file, shortcode, URL, logo,
orders, settings, roles ও integration contracts রাখা হয়েছে। Delete/Uninstall নয়।

ORDER ENTRY REPAIR
• Product option validation চললে preview তা শেষ করে সর্বশেষ values যাচাই করে।
• একটিমাত্র actual Woo shipping rate থাকলে তা বেছে আবার server quote নেয়; সেই
  final price/charge দেখে কর্মী approve করে Pending order তৈরি করবেন। একাধিক
  rate হলে নিজে বাছতে হবে। কোনো delivery charge বা unsupported provider আন্দাজ নয়।
• Required/invalid field লুকানো optional details-এ থাকলে details খুলে feedback দেয়।
• Unsupported provider/mapping/pre-order, missing payment/shipping configuration,
  invalid response বা expired session-এর কারণ দেখায়; security check bypass নয়।
• Quote চলার সময় draft বদলালে পুরোনো preview দিয়ে create হবে না। Create চলার
  সময় draft editing বন্ধ; duplicate protection ও একই native Woo ID বজায় থাকে।
• দেরিতে/defer হয়ে JS load হলেও workbench/menu/form tools initialize হয়।

MOBILE / THEME
Teal #087F83, Blue #2563EB, Navy #102A43, background #F5F8FC, white cards।
মোবাইলে order cards, grouped customer/payment form, বড় touch controls, menu drawer,
৩টি role-appropriate shortcut + full menu, scoped scrolling table ও bounded dialog।
Header-এ একবার photo/name, current page title/breadcrumb ও notification popup।
Live index থেকে status chart/recent orders, real production workload। পুরোনো sales /
stock view Overview-এর “Sales / stock / original metrics”-এ আছে। Index পুরোপুরি
শেষ না হলে counts সম্পূর্ণ নয়। Native Woo completed-কে delivered ধরে নেওয়া হয় না।
Settings → Interface preset-এ Classic করলে আগের saved light/dark/theme কাজ করবে।
আগের theme settings মুছে যায় না। নতুন CSS screen-only; A4 print template ও
C mapping EN / EMB / NP একই থাকে। HTML reference file পাওয়া যায়নি; দেওয়া palette
ও written design requirements অনুযায়ী existing portal-এর উপর কাজ হয়েছে।

DELIVERY → CUSTOMIZATION (ONE CLICK)
Delivery / Packaging list-এ confirmed processing order-এর mapped exact text দেখুন,
তারপর “Send to customization queue”। Order details খোলা ছাড়াই button পাওয়া যায়।
NP/Embroidery/Engraving-এর valid mapped fields থেকে Queued tasks হবে; একই task
দ্বিতীয়বার হবে না। আগের task-এর instructions/progress reset হয় না। Order-এর
financial status/payment/refund বদলায় না। Packing update-এর পর proof refresh হয়।
Packed/dispatched/closed/pending order, missing name, unknown mapping, invalid
reference বা stale customization থাকলে handoff আটকাবে ও কারণ বলবে। “Sent” নতুন
ও আগে-থাকা task আলাদা করে দেখায়; completed task নিজে থেকে restart করে না।

PERMISSIONS
Admin: সব existing Operations access। Manager/Staff: আগের permissions অক্ষুণ্ণ।
Moderator: নিজের unpaid Pending order create/customer/destination edit; Confirm
হলে access বন্ধ। Product-line/price/refund/confirm কাজ Admin/Woo editor-এ থাকে।
Delivery: processing order packing, reviewed courier workflow, customization
read/print + one-click handoff; financial status/refund বা general task edit নয়।
Customization Team: task management/print; financial order mutation নয়।
Staff access setup Admin-এর native user-promotion permission অনুযায়ী কাজ করে।

START
1. Files + database backup নিন।
2. Plugins → Add New → Upload ZIP → Replace current with uploaded।
3. Cache থেকে private portal বাদ দিন; পুরোনো tabs/previews reload করুন।
4. প্রতিটি role-এর test account দিয়ে physical/variable product, actual website
   fields, shipping/payment এবং delivery handoff staging-এ যাচাই করুন।
5. এরপর আপনার target server ও provider/device checks মিলে গেলে live rollout করুন।

লাইভ healthpointbd.com পরিবর্তন করা হয়নি। Actual host MySQL, Android/iOS browser
layout, physical A4/PDF output ও merchant Pathao/Meta/SMS/payment/AI credentials
এখানে verified নয়। সব unknown provider integration বা সম্পূর্ণ master-project
শেষ হওয়ার দাবি নয়। TEST-REPORT, FEATURE-CHECKLIST ও UPGRADE/ROLLBACK guide দেখুন।
