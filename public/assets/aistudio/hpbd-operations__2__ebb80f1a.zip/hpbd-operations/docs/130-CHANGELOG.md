# HPBD Operations 1.3.0

- Improved the New Orders `C` code inference so mapped and label-detected NP, Embroidery, and Engraving customizations are included when present.
- Added restricted-role access to read-only Global Search and My Order Activity.
- Added creator-specific order totals/status breakdown and production fulfillment state.
- Made restricted-role search results view-only (no privileged order-edit link).
- Added readable role/title labels to the profile summary.

## Verification boundary
PHP syntax and archive integrity were checked locally. Live WordPress/WooCommerce, HPOS, ThemeComplete, production handoff, and real staff-permission tests require the target site and are not claimed as passed.
