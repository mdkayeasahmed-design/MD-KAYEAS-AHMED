<?php
/** Additive workspace shell and manager settings. Original 0.2 storage is untouched. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Workspace {
 const VERSION='1.5.0';
 static function boot(){
  add_filter('template_include',[__CLASS__,'template'],99);
  add_action('init',[__CLASS__,'migrate'],20);
  add_action('admin_post_hpbd_workspace_settings',[__CLASS__,'save']);
  add_action('wp_ajax_hpbd_workspace',[__CLASS__,'ajax']);
  add_action('admin_post_hpbd_private_file',[__CLASS__,'download']);
  HPBD_OPS_Workbench::boot();HPBD_OPS_Search::boot();HPBD_OPS_Production::boot();HPBD_OPS_Print_Center::boot();
 }
 static function settings(){return array_merge(['fullscreen'=>true,'fields'=>[],'epo_queues'=>[],'locations'=>[],'print_header'=>'Health Point BD','print_footer'=>'By the doctors, for the nation','print_margin'=>12,'theme'=>[]],(array)get_option('hpbd_ops_workspace',[]));}
 static function guard($manager=false){if(!current_user_can($manager?'hpbd_ops_manage':HPBD_OPS_Pilot::CAP))throw new RuntimeException('Permission denied.');}
 static function migrate(){
  if(get_option('hpbd_ops_workspace_schema')==='1')return;
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();
  dbDelta("CREATE TABLE {$wpdb->prefix}hpbd_ops_search (
   entity varchar(64) NOT NULL,
   kind varchar(12) NOT NULL,
   object_id bigint(20) unsigned NOT NULL,
   label varchar(191) NOT NULL,
   customer varchar(191) NOT NULL,
   phone varchar(64) NOT NULL,
   source varchar(64) NOT NULL,
   status varchar(64) NOT NULL,
   created datetime NOT NULL,
   total decimal(20,4) NOT NULL DEFAULT 0,
   currency varchar(8) NOT NULL,
   content longtext NOT NULL,
   updated datetime NOT NULL,
   PRIMARY KEY  (entity),
   KEY kind_object (kind,object_id),
   KEY date_status (created,status),
   KEY phone (phone)
  ) $c;");
  dbDelta("CREATE TABLE {$wpdb->prefix}hpbd_ops_files (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   owner bigint(20) unsigned NOT NULL,
   name varchar(191) NOT NULL,
   mime varchar(64) NOT NULL,
   content longtext NOT NULL,
   created datetime NOT NULL,
   PRIMARY KEY  (id)
  ) $c;");
  $ok=true;foreach(['hpbd_ops_search','hpbd_ops_files'] as $t){$t=$wpdb->prefix.$t;$ok=$ok && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;}
  if($ok){update_option('hpbd_ops_workspace_schema','1',false);HPBD_OPS_Search::schedule();}
 }
 static function template($path){global $post;if(!is_admin() && is_singular() && $post && has_shortcode($post->post_content,'hpbd_operations') && self::settings()['fullscreen'])return dirname(__DIR__).'/templates/portal.php';return $path;}
 static function assets(){
  static $loaded=false;if($loaded)return;$loaded=true;
  // System font stack avoids a blocking external font request.
  wp_enqueue_style('hpbd-workspace',plugins_url('assets/workspace.css',HPBD_OPS_FILE),['hpbd-ops'],self::VERSION);
  wp_enqueue_script('hpbd-workspace',plugins_url('assets/workspace.js',HPBD_OPS_FILE),[],self::VERSION,true);
  $entry=in_array(sanitize_key(HPBD_OPS_Integrations::scalar($_GET,'hpbd_tab')),['create','new','wooedit'],true);
  wp_localize_script('hpbd-workspace','HPBDWorkspace',['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('hpbd_workspace'),'locations'=>$entry?self::settings()['locations']:[],'providerCities'=>$entry && function_exists('WC')?HPBD_OPS_Providers::cities():[]]);
  $theme=self::theme_settings();
  wp_add_inline_style('hpbd-workspace',self::theme_css($theme));
  wp_add_inline_script('hpbd-workspace',self::theme_js(), 'after');
  wp_enqueue_style('hpbd-refresh',plugins_url('assets/refresh.css',HPBD_OPS_FILE),['hpbd-workspace'],self::VERSION);
  $action=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$theme['accent'])?$theme['accent']:'#126346';
  $rgb=sscanf($action,'#%02x%02x%02x');$linear=[];foreach($rgb as $v){$v=$v/255;$linear[]=$v<=0.04045?$v/12.92:pow(($v+0.055)/1.055,2.4);}$luminance=0.2126*$linear[0]+0.7152*$linear[1]+0.0722*$linear[2];
  wp_add_inline_style('hpbd-refresh','.hpbd-ops.hpbd-ui-060{--hpbd-action:'.$action.';--hpbd-action-text:'.($luminance>0.179?'#000000':'#ffffff').';}');
  wp_enqueue_style('hpbd-compact',plugins_url('assets/compact.css',HPBD_OPS_FILE),['hpbd-refresh'],self::VERSION);
  wp_enqueue_script('hpbd-portal-tools',plugins_url('assets/portal-tools.js',HPBD_OPS_FILE),['hpbd-workspace'],self::VERSION,true);
  wp_enqueue_style('hpbd-workbench',plugins_url('assets/workbench.css',HPBD_OPS_FILE),['hpbd-compact'],self::VERSION);
  wp_enqueue_script('hpbd-workbench',plugins_url('assets/workbench.js',HPBD_OPS_FILE),['hpbd-portal-tools','hpbd-refresh'],self::VERSION,true);
  wp_enqueue_style('hpbd-experience',plugins_url('assets/experience.css',HPBD_OPS_FILE),['hpbd-workbench'],self::VERSION);wp_enqueue_script('hpbd-experience',plugins_url('assets/experience.js',HPBD_OPS_FILE),['hpbd-workbench'],self::VERSION,true);
  wp_enqueue_style('hpbd-completion',plugins_url('assets/completion.css',HPBD_OPS_FILE),['hpbd-experience'],self::VERSION);
  wp_enqueue_script('hpbd-completion',plugins_url('assets/completion.js',HPBD_OPS_FILE),['hpbd-workbench'],self::VERSION,true);
  wp_enqueue_style('hpbd-navigation',plugins_url('assets/navigation.css',HPBD_OPS_FILE),['hpbd-completion'],self::VERSION);
  wp_enqueue_style('hpbd-mobile-header',plugins_url('assets/mobile-header.css',HPBD_OPS_FILE),['hpbd-navigation'],self::VERSION);
  wp_enqueue_script('hpbd-mobile-header',plugins_url('assets/mobile-header.js',HPBD_OPS_FILE),['hpbd-experience','hpbd-portal-tools','hpbd-completion','hpbd-refresh'],self::VERSION,true);
  wp_enqueue_style('hpbd-smart-entry',plugins_url('assets/smart-entry.css',HPBD_OPS_FILE),['hpbd-mobile-header'],self::VERSION);
  wp_enqueue_script('hpbd-smart-entry',plugins_url('assets/smart-entry.js',HPBD_OPS_FILE),['hpbd-mobile-header'],self::VERSION,true);
  wp_enqueue_style('hpbd-print-design',plugins_url('assets/print-design.css',HPBD_OPS_FILE),['hpbd-smart-entry'],self::VERSION);
  wp_enqueue_style('hpbd-team',plugins_url('assets/team.css',HPBD_OPS_FILE),['hpbd-completion'],self::VERSION);
  wp_enqueue_style('hpbd-toolbar-only',plugins_url('assets/toolbar-only.css',HPBD_OPS_FILE),['hpbd-print-design'],self::VERSION);
  wp_enqueue_script('hpbd-print-design',plugins_url('assets/print-design.js',HPBD_OPS_FILE),['hpbd-workbench'],self::VERSION,true);
  wp_enqueue_script('hpbd-refresh',plugins_url('assets/refresh.js',HPBD_OPS_FILE),['hpbd-workspace'],self::VERSION,true);
 }
 static function theme_defaults(){return ['mode'=>'light','accent'=>'#126346','nav'=>'bottom-drawer','density'=>'comfortable','radius'=>12,'sidebar_width'=>236,'font_size'=>14,'bottom_bar'=>1,'drawer'=>1];}
 static function theme_settings(){ $s=self::settings();$t=is_array($s['theme']??null)?$s['theme']:[];return array_merge(self::theme_defaults(),$t); }
 static function theme_css($t){
  $accent=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$t['accent'])?$t['accent']:'#2563eb';
  $radius=max(4,min(24,(int)$t['radius']));$width=max(180,min(280,(int)$t['sidebar_width']));$font=max(12,min(18,(int)$t['font_size']));
  $mode=in_array($t['mode'],['dark','light','system'],true)?$t['mode']:'light';
  $nav=in_array($t['nav'],['bottom-drawer','drawer','bottom'],true)?$t['nav']:'bottom-drawer';
  $base='.hpbd-fullscreen .hpbd-ops{--hpbd-teal:'.$accent.';--hpbd-teal-dark:'.$accent.';--hpbd-radius:'.$radius.'px;--hpbd-font:'.$font.'px;font-size:var(--hpbd-font);box-sizing:border-box}.hpbd-fullscreen .hpbd-ops *{box-sizing:border-box}.hpbd-fullscreen .hpbd-ops>nav{width:'.$width.'px}.hpbd-fullscreen .hpbd-ops{padding-left:'.($width+36).'px}.hpbd-ops .hpbd-panel,.hpbd-ops .hpbd-connector,.hpbd-ops .hpbd-message,.hpbd-ops .hpbd-cards article{border-radius:var(--hpbd-radius)}.hpbd-ops button,.hpbd-ops input,.hpbd-ops select,.hpbd-ops textarea,.hpbd-ops .hpbd-page{border-radius:max(4px,calc(var(--hpbd-radius) - 4px))}.hpbd-ops .hpbd-panel{padding:22px}.hpbd-ops .hpbd-cards article{box-shadow:0 8px 24px rgba(0,0,0,.12)}';
  $dark='.hpbd-fullscreen{background:#07111f!important;color:#e6edf6!important}.hpbd-fullscreen .hpbd-ops{background:#0b1424!important;color:#e6edf6!important;--hpbd-bg:#0b1424;--hpbd-card:#111d30;--hpbd-ink:#e6edf6;--hpbd-muted:#a5b4c7;--hpbd-border:#27364c;background:var(--hpbd-bg);color:var(--hpbd-ink)}.hpbd-fullscreen .hpbd-ops>nav{background:#07111f;border-right:1px solid #24334a}.hpbd-fullscreen .hpbd-ops>nav a{color:#d8e2ef}.hpbd-fullscreen .hpbd-ops>nav a.active{background:'.$accent.';color:#fff}.hpbd-ops .hpbd-panel,.hpbd-ops .hpbd-connector,.hpbd-ops .hpbd-message,.hpbd-ops .hpbd-cards article{background:#111d30!important;color:#e6edf6;border-color:#27364c!important}.hpbd-ops h1,.hpbd-ops h2,.hpbd-ops h3,.hpbd-ops h4,.hpbd-ops label,.hpbd-ops th{color:#e6edf6}.hpbd-ops p,.hpbd-ops small{color:#b6c3d4}.hpbd-ops input:not([type=checkbox]):not([type=radio]),.hpbd-ops select,.hpbd-ops textarea{background:#0b1424;color:#e6edf6;border:1px solid #34445b;max-width:100%}.hpbd-ops table,.hpbd-ops td,.hpbd-ops th{border-color:#27364c}.hpbd-ops .hpbd-cards article h2{color:#5eead4}';
  $light='.hpbd-fullscreen{background:#f1f5f9!important;color:#172b45!important}.hpbd-fullscreen .hpbd-ops{background:#f4f7fb!important;color:#172b45!important;--hpbd-bg:#f4f7fb;--hpbd-card:#fff;--hpbd-ink:#172b45;--hpbd-muted:#64748b;--hpbd-border:#dce5ef}.hpbd-fullscreen .hpbd-ops>nav{background:#12345a;border-right:1px solid #dce5ef}.hpbd-fullscreen .hpbd-ops>nav a{color:#d8e2ef}.hpbd-fullscreen .hpbd-ops>nav a.active{background:'.$accent.';color:#fff}.hpbd-ops .hpbd-panel,.hpbd-ops .hpbd-connector,.hpbd-ops .hpbd-message,.hpbd-ops .hpbd-cards article{background:#fff!important;color:#172b45;border-color:#dce5ef!important}.hpbd-ops h1,.hpbd-ops h2,.hpbd-ops h3,.hpbd-ops h4,.hpbd-ops label,.hpbd-ops th{color:#172b45}.hpbd-ops p,.hpbd-ops small{color:#52657a}.hpbd-ops input:not([type=checkbox]):not([type=radio]),.hpbd-ops select,.hpbd-ops textarea{background:#fff;color:#172b45;border:1px solid #cbd5e1}';
  if($mode==='dark')$base.=$dark;elseif($mode==='light')$base.=$light;else $base.='@media(prefers-color-scheme:dark){'.$dark.'}@media(prefers-color-scheme:light){'.$light.'}';
  $base.='
@media(max-width:900px){
 .hpbd-fullscreen .hpbd-ops{width:100%;max-width:100%;min-width:0;padding:12px 14px calc(100px + env(safe-area-inset-bottom))!important;margin:0!important;overflow-x:hidden}
 .hpbd-fullscreen .hpbd-ops>header{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start;padding-bottom:14px}
 .hpbd-fullscreen .hpbd-ops>header>div{max-width:100%;min-width:0}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer{display:none!important;position:fixed!important;left:12px!important;right:12px!important;top:64px!important;bottom:auto!important;width:auto!important;max-width:none!important;max-height:calc(100dvh - 150px);overflow:auto!important;z-index:100101!important;flex-direction:column!important;flex-wrap:nowrap!important;margin:0!important;padding:12px!important;gap:5px!important;box-shadow:0 20px 60px rgba(0,0,0,.45);border:1px solid #34445b;border-radius:16px}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer.hpbd-drawer-open{display:flex!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer:before{display:block!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer a{display:block;width:100%;white-space:normal;box-sizing:border-box;padding:12px 14px;flex:0 0 auto}
 .hpbd-hamburger{display:inline-flex!important;align-items:center;justify-content:center;position:static;z-index:20;border:1px solid #334155;background:#111d30;color:#fff;border-radius:10px;padding:8px 12px;min-height:40px;font-size:14px;font-weight:700;box-shadow:none;flex:0 0 auto;margin:0}
 .hpbd-mobile-bottom{position:fixed;left:0;right:0;bottom:0;z-index:100100;display:flex;justify-content:space-around;align-items:stretch;gap:3px;padding:6px 5px calc(6px + env(safe-area-inset-bottom));background:#07111f;border-top:1px solid #27364c;box-shadow:0 -8px 28px rgba(0,0,0,.22);max-width:100vw;overflow-x:auto}
 .hpbd-mobile-bottom a{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;flex:1 1 0;min-width:0;max-width:25%;text-align:center;text-decoration:none!important;color:#a5b4c7!important;font-size:11px;line-height:1.2;padding:8px 2px;border-radius:10px;overflow-wrap:anywhere}
 .hpbd-mobile-bottom a.active{background:'.$accent.';color:#fff!important}
 .hpbd-mobile-bottom .hpbd-nav-icon{font-size:19px;line-height:1}
 .hpbd-fullscreen #hpbd-workspace{padding-bottom:0!important}
 .hpbd-fullscreen .hpbd-ops>nav:not(.hpbd-mobile-drawer){display:none!important}
 .hpbd-ops .hpbd-cards{grid-template-columns:repeat(2,minmax(0,1fr))}
 .hpbd-ops .hpbd-form{grid-template-columns:minmax(0,1fr)!important}
 .hpbd-ops .hpbd-form>label,.hpbd-ops label{min-width:0;max-width:100%}
 .hpbd-ops input,.hpbd-ops select,.hpbd-ops textarea{max-width:100%;min-width:0}
 .hpbd-ops .hpbd-panel{padding:16px;margin:14px 0}
 .hpbd-ops table{display:block;width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
 .hpbd-ops table th,.hpbd-ops table td{white-space:normal;overflow-wrap:anywhere}
 .hpbd-ops img{max-width:100%;height:auto}
} 
@media(max-width:520px){.hpbd-ops .hpbd-cards{grid-template-columns:1fr}.hpbd-mobile-bottom a{font-size:10px;padding-left:1px;padding-right:1px}.hpbd-fullscreen .hpbd-ops>header h1{font-size:22px!important}.hpbd-ops .hpbd-panel{padding:13px}}
@media(min-width:1024px){.hpbd-hamburger,.hpbd-mobile-bottom,.hpbd-drawer-backdrop{display:none!important}.hpbd-fullscreen .hpbd-ops{padding-left:'.($width+28).'px!important;padding-top:22px!important;padding-bottom:40px!important}}
@media(prefers-reduced-motion:reduce){.hpbd-ops *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}.hpbd-drawer-backdrop{display:none!important}.hpbd-mobile-more{display:flex;flex:1 1 0;max-width:25%;min-width:0;flex-direction:column;align-items:center;justify-content:center;gap:4px;border:0;background:transparent;color:#a5b4c7;font-size:11px;padding:8px 2px}.hpbd-mobile-more .hpbd-nav-icon{font-size:19px}.hpbd-drawer-backdrop.is-open{display:block!important;position:fixed;inset:0;z-index:100099;background:rgba(0,0,0,.45);border:0}';
  if($nav==='drawer')$base.='@media(max-width:1023px){.hpbd-mobile-bottom{display:none!important}.hpbd-fullscreen .hpbd-ops{padding-bottom:24px!important}}';
  if($nav==='bottom')$base.='@media(max-width:1023px){.hpbd-hamburger{display:none!important}.hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer{display:none!important}}';
  if(empty($t['bottom_bar']))$base.='.hpbd-mobile-bottom{display:none!important}';
  if(empty($t['drawer']))$base.='.hpbd-hamburger{display:none!important}.hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer{display:none!important}';
  // Android browsers using "Desktop site" may report a wide CSS viewport despite a narrow physical screen.
  // Coarse-pointer rules keep the workspace usable on phones without changing desktop mouse layouts.
  $base.='
@media (pointer:coarse) and (max-width:1200px){
 .hpbd-fullscreen #hpbd-workspace{width:100%;max-width:100%;overflow-x:clip;padding-bottom:calc(92px + env(safe-area-inset-bottom))}
 .hpbd-fullscreen .hpbd-ops{width:100%!important;max-width:100%!important;min-width:0!important;margin:0!important;padding:12px 14px calc(100px + env(safe-area-inset-bottom))!important;overflow-x:clip!important}
 .hpbd-fullscreen .hpbd-ops>nav:not(.hpbd-mobile-drawer){display:none!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer{display:none!important;position:fixed!important;left:12px!important;right:12px!important;top:64px!important;bottom:auto!important;width:auto!important;max-width:none!important;max-height:calc(100dvh - 150px)!important;overflow:auto!important;z-index:100101!important;flex-direction:column!important;flex-wrap:nowrap!important;margin:0!important;padding:12px!important;gap:5px!important;border-radius:16px!important;background:#12345a!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer.hpbd-drawer-open{display:flex!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer a{display:block!important;width:100%!important;white-space:normal!important;flex:0 0 auto!important;padding:12px 14px!important;background:#fff!important;color:#173654!important;font-size:14px!important;line-height:1.4!important;border-radius:10px!important}
 .hpbd-fullscreen .hpbd-ops>nav.hpbd-mobile-drawer a.active{background:'.$accent.'!important;color:#fff!important}
 .hpbd-hamburger{display:inline-flex!important;align-items:center;justify-content:center;position:static!important;top:auto!important;right:auto!important;z-index:20!important;min-height:40px!important;padding:8px 12px!important;background:#111d30!important;color:#fff!important;border-radius:10px!important;flex:0 0 auto!important;margin:0!important}
 .hpbd-mobile-bottom{position:fixed!important;left:0!important;right:0!important;bottom:0!important;z-index:100100!important;display:flex!important;padding:6px 5px calc(6px + env(safe-area-inset-bottom))!important;background:#07111f!important;max-width:100vw!important;overflow-x:auto!important}
 .hpbd-mobile-bottom a,.hpbd-mobile-more{max-width:25%!important;min-width:0!important;overflow-wrap:anywhere!important}
 .hpbd-ops .hpbd-panel{padding:16px!important}
 .hpbd-ops .hpbd-form{grid-template-columns:minmax(0,1fr)!important}
 .hpbd-ops table{display:block;width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
 .hpbd-ops img{max-width:100%;height:auto}
}';
  return $base;
 }
 static function theme_js(){return <<<'JS'
(function(){'use strict';
function toast(msg,type){
  type=type||'success';
  var el=document.createElement('div');
  el.className='hpbd-toast hpbd-toast-'+(type==='error'?'error':'success');
  el.setAttribute('role','status');
  el.innerHTML='<span class="hpbd-toast-dot" aria-hidden="true"></span><span></span>';
  el.querySelector('span:last-child').textContent=msg;
  document.body.appendChild(el);
  setTimeout(function(){el.style.opacity='0';el.style.transition='opacity .25s';setTimeout(function(){el.remove();},280);},3200);
}
window.HPBDToast=toast;

function enhanceNav(nav){
  if(nav.dataset.hpbdNavEnhanced==='1')return;
  nav.dataset.hpbdNavEnhanced='1';
  // Desktop brand lockup (logo + HEALTH POINT BD OPERATIONS)
  if(!nav.querySelector('.hpbd-brand-lockup')){
    var logo=document.querySelector('.hpbd-ops .hpbd-logo');
    var portal=document.querySelector('.hpbd-ops');var src=(portal&&portal.getAttribute('data-hpbd-brand-logo'))||(logo?logo.getAttribute('src'):'');
    var lock=document.createElement('div');
    lock.className='hpbd-brand-lockup';
    lock.innerHTML=(src?'<img src="'+src+'" alt="">':'')+
      '<div><strong>HEALTH POINT BD</strong><span>OPERATIONS</span></div>';
    nav.insertBefore(lock, nav.firstChild);
  }
  if(nav.getAttribute('data-hpbd-grouped')==='1')return;
  var links=Array.prototype.slice.call(nav.querySelectorAll('a'));
  if(!links.length)return;
  var workspaceKeys=['overview','daily','create','search','production','print','new','orders','np','embroidery','engraving','pathao','woocommerce'];
  var systemKeys=['customers','diagnostics','settings','connections','help','catalog','inbox','meta'];
  function isKey(a,keys){
    var h=a.href||'';
    return keys.some(function(k){return h.indexOf('hpbd_tab='+k)>-1;});
  }
  var firstSys=links.find(function(a){return isKey(a,systemKeys);});
  if(firstSys){
    var lab=document.createElement('div');
    lab.className='hpbd-nav-section';
    lab.textContent='System';
    nav.insertBefore(lab,firstSys);
  }
  var firstWs=links.find(function(a){return isKey(a,workspaceKeys);});
  if(firstWs){
    var lab2=document.createElement('div');
    lab2.className='hpbd-nav-section';
    lab2.textContent='Workspace';
    nav.insertBefore(lab2,firstWs);
  }

}

function enhanceTables(root){
  root.querySelectorAll('.hpbd-table td').forEach(function(td){
    if(td.children.length)return;
    var value=(td.textContent||'').trim(),state=value.toLowerCase(),kind='';
    if(['pending','on-hold'].indexOf(state)>-1)kind='pending';
    else if(['paid','completed'].indexOf(state)>-1)kind='paid';
    else if(['processing','dispatch','shipped'].indexOf(state)>-1)kind='shipped';
    if(!kind)return;
    var badge=document.createElement('span');badge.className='hpbd-status hpbd-status-'+kind;
    badge.textContent=value;td.replaceChildren(badge);
  });
}

function init(){
  var root=document.querySelector('.hpbd-fullscreen .hpbd-ops')||document.querySelector('.hpbd-ops');
  if(!root||root.dataset.hpbdMobileReady==='1')return;
  root.dataset.hpbdMobileReady='1';
  var nav=root.querySelector(':scope > nav')||root.querySelector('nav');
  if(!nav)return;
  var single=root.getAttribute('data-hpbd-header-layout')==='single';
  nav.classList.add('hpbd-mobile-drawer');
  /* Ensure every nav link stays reachable on all devices */
  nav.setAttribute('data-hpbd-full-menu','1');
  enhanceNav(nav);
  enhanceTables(root);

  var btn=document.createElement('button');
  btn.type='button';btn.className='hpbd-hamburger';
  btn.setAttribute('aria-expanded','false');
  btn.setAttribute('aria-controls','hpbd-operations-navigation');
  btn.setAttribute('aria-label','Open navigation menu');
  btn.textContent=single?'☰':'☰ Menu';
  nav.id=nav.id||'hpbd-operations-navigation';
  // Dock Menu into header: brand · user · Menu (standard app-bar order)
  var hdr=root.querySelector('.hpbd-dashboard-header')||document.querySelector('.hpbd-dashboard-header');
  if(hdr){
    var user=hdr.querySelector('.hpbd-dashboard-user');
    if(user){ hdr.insertBefore(btn, user.nextSibling); }
    else { hdr.appendChild(btn); }
  } else { document.body.appendChild(btn); }

  var bar=document.createElement('nav');
  bar.className='hpbd-mobile-bottom';
  bar.setAttribute('aria-label','Quick navigation');
  var links=Array.prototype.slice.call(nav.querySelectorAll('a'));
  /* Quick strip: primary tools; full list always in Menu drawer */
  var iconMap={daily:'▦',team:'◫',delivery:'▰',pending:'◷',customization:'✎',overview:'◫',create:'＋',search:'⌕',production:'▥',print:'⎙',orders:'☰',new:'＋',pathao:'📦',settings:'⚙',customers:'👤',inbox:'✉',woocommerce:'🛒'};
  var preferred=['daily','orders','create','delivery','pending','customization','team','production','print','search','overview'];
  var pick=[];
  preferred.forEach(function(k){
    var a=links.find(function(x){
      return (x.href||'').indexOf('hpbd_tab='+k)>-1 ||
        ((k==='overview')&&(x.href||'').indexOf('hpbd_tab')===-1&&/overview|dashboard/i.test(x.textContent));
    });
    if(a&&pick.indexOf(a)<0)pick.push(a);
  });
  if(pick.length<3)pick=links.slice(0,6);
  pick.slice(0,3).forEach(function(a){
    var clone=a.cloneNode(true);
    var key=(preferred.find(function(k){return (a.href||'').indexOf('hpbd_tab='+k)>-1;})||'');
    var ic=iconMap[key]||'•';
    var label=(a.textContent||'').trim();
    if(label.length>14)label=label.slice(0,12)+'…';
    clone.innerHTML='<span class="hpbd-nav-icon" aria-hidden="true">'+ic+'</span><span>'+label+'</span>';
    clone.classList.toggle('active',a.classList.contains('active'));
    bar.appendChild(clone);
  });
  /* Always expose full menu on every device via Menu */
  var more=document.createElement('button');
  more.type='button';more.className='hpbd-mobile-more';
  more.setAttribute('aria-label','Open full menu');
  more.innerHTML='<span class="hpbd-nav-icon" aria-hidden="true">☰</span><span>All menu</span>';
  more.addEventListener('click',function(){toggle();});
  bar.appendChild(more);
  if(!single)document.body.appendChild(bar);

  var backdrop=document.createElement('button');
  backdrop.type='button';backdrop.className='hpbd-drawer-backdrop';
  backdrop.setAttribute('aria-label','Close navigation menu');
  backdrop.tabIndex=-1;
  document.body.appendChild(backdrop);

  function close(){
    var wasOpen=nav.classList.contains('hpbd-drawer-open');
    nav.classList.remove('hpbd-drawer-open');
    backdrop.classList.remove('is-open');
    btn.setAttribute('aria-expanded','false');
    btn.textContent=single?'☰':'☰ Menu';
    btn.setAttribute('aria-label','Open navigation menu');
    if(wasOpen && (window.innerWidth<1024||root.classList.contains('hpbd-toolbar-only')))btn.focus();
  }
  function toggle(){
    var open=!nav.classList.contains('hpbd-drawer-open');
    nav.classList.toggle('hpbd-drawer-open',open);
    backdrop.classList.toggle('is-open',open);
    btn.setAttribute('aria-expanded',open?'true':'false');
    btn.textContent=single?(open?'✕':'☰'):(open?'✕ Close':'☰ Menu');
    btn.setAttribute('aria-label',open?'Close navigation menu':'Open navigation menu');
    if(open){
      var si=nav.querySelector('a');
      if(si) setTimeout(function(){if(nav.classList.contains('hpbd-drawer-open'))si.focus();},50);
    }
  }
  root.addEventListener('hpbd:close-menu',close);
  btn.addEventListener('click',toggle);
  backdrop.addEventListener('click',close);
  nav.addEventListener('click',function(e){if(e.target.closest('a'))close();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')close();});
  window.addEventListener('resize',function(){if(window.innerWidth>=1024)close();},{passive:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
JS;}
 static function tabs(){return ['messages'=>'Staff messages','points'=>'Points / Rankboard','work'=>'Daily order tasks','inventory'=>'Inventory','myorders'=>'My order stats','overview'=>'Overview','daily'=>'Daily order processing','create'=>'Create Woo order','search'=>'Global search','production'=>'Production','customization'=>'Customization · সব অর্ডার','print'=>'Print center','customers'=>'Customers','diagnostics'=>'Diagnostics','settings'=>'Workspace settings','meta'=>'Meta Catalog'];}
 static function render($tab,$base){self::assets();if($tab==='messages'){HPBD_OPS_Team::messages();return;}if($tab==='points'){HPBD_OPS_Points::render();return;}if($tab==='work'){HPBD_OPS_Flow::workboard();return;}if($tab==='inventory'){HPBD_OPS_Inventory::render();return;}
  if($tab==='create'){HPBD_OPS_Orders::form();return;}
  if($tab==='wooedit'){HPBD_OPS_Orders::detail($base);return;}
  if($tab==='customization'){HPBD_OPS_Customization::render($base);return;}
  if($tab==='production'){if(HPBD_OPS_Integrations::scalar($_GET,'task_legacy')==='1')HPBD_OPS_Production::render();else HPBD_OPS_Production_View::render();return;}
  if($tab==='print'){HPBD_OPS_Print_Center::render($base);return;}
  if($tab==='diagnostics'){HPBD_OPS_Diagnostics::render();return;}
  if($tab==='settings'){self::render_settings();HPBD_OPS_Release::render_settings();HPBD_OPS_Smart_Entry::settings_ui();return;}
  if($tab==='meta'){HPBD_OPS_Meta::render($base);return;}
  HPBD_OPS_Search::render($tab,$base);
 }
 static function ajax(){
  try{self::guard();check_ajax_referer('hpbd_workspace','nonce');$op=sanitize_key(HPBD_OPS_Pilot::field('op'));HPBD_OPS_Access::operation($op);
   if($op==='upload'){$r=self::upload();}elseif($op==='profile_photo'){$r=HPBD_OPS_Workbench::upload_photo();}
   else {$raw=isset($_POST['data']) && is_string($_POST['data'])?wp_unslash($_POST['data']):'{}';if(strlen($raw)>65536)throw new RuntimeException('Request too large.');$d=json_decode($raw,true);if(!is_array($d))throw new RuntimeException('Invalid request.');
    switch($op){case 'edit_seed':$r=HPBD_OPS_Item_Editor::seed($d);break;case 'edit_quote':$r=HPBD_OPS_Item_Editor::quote($d);break;case 'edit_apply':$r=HPBD_OPS_Item_Editor::apply($d);break;case 'print_check':$r=HPBD_OPS_Print_Center::check($d);break;case 'workflow_save':$r=HPBD_OPS_Completion::save($d);break;case 'delivery_queue':$r=HPBD_OPS_Experience::handoff($d);break;case 'delivery_update':$r=HPBD_OPS_Access::delivery_update($d);break;case 'task_print_check':$r=HPBD_OPS_Workbench::check_task_print($d);break;case 'profile_save':$r=HPBD_OPS_Workbench::save_profile($d);break;case 'language':$r=HPBD_OPS_Workbench::save_language($d);break;case 'notifications':$r=HPBD_OPS_Workbench::notifications();break;case 'notifications_read':$r=HPBD_OPS_Workbench::read_notifications($d);break;case 'task_claim':$r=HPBD_OPS_Workbench::claim($d);break;case 'index_step':$r=HPBD_OPS_Portal_Tools::step($d);break;case 'epo_fields':$r=HPBD_OPS_ThemeComplete::inspect($d);$r['context']=HPBD_OPS_Providers::product(wc_get_product(absint($d['id']??0)));break;case 'variant':$r=HPBD_OPS_Orders::variant($d);break;case 'parse':$r=HPBD_OPS_Order_Tools::parse($d);break;case 'repeat':$r=HPBD_OPS_Order_Tools::repeat($d);break;case 'destination_quote':$r=HPBD_OPS_Order_Tools::quote($d);break;case 'destination_apply':$r=HPBD_OPS_Order_Tools::apply($d);break;case 'products':$r=HPBD_OPS_Orders::products($d);break;case 'quote':$r=HPBD_OPS_Orders::quote($d);break;case 'create':$r=HPBD_OPS_Orders::create($d);break;case 'update':$r=HPBD_OPS_Orders::update($d);break;case 'task':$r=HPBD_OPS_Production_View::save($d);break;case 'task_quick':$r=HPBD_OPS_Production_View::quick($d);break;case 'task_preview':$r=HPBD_OPS_Production_Plan::preview($d);break;case 'task_prepare':$r=HPBD_OPS_Production_Plan::apply($d);break;case 'task_orders':$r=HPBD_OPS_Production_View::orders($d);break;case 'unified_update':$r=HPBD_OPS_Unified::update($d);break;case 'ai_suggest':$r=HPBD_OPS_Assistant::suggest($d);break;default:throw new RuntimeException('Unknown action.');}
   }wp_send_json_success($r);
  }catch(Throwable $e){wp_send_json_error(['message'=>$e->getMessage()],400);}
 }
 static function upload(){
  if(empty($_FILES['file']) || !is_array($_FILES['file']))throw new RuntimeException('Choose a reference image or PDF.');$f=$_FILES['file'];
  if($f['error']!==UPLOAD_ERR_OK || $f['size']>2*1024*1024 || !is_uploaded_file($f['tmp_name']))throw new RuntimeException('Upload failed; maximum 2 MB.');
  $check=wp_check_filetype_and_ext($f['tmp_name'],$f['name'],['jpg|jpeg'=>'image/jpeg','png'=>'image/png','pdf'=>'application/pdf']);
  if(empty($check['ext']) || !in_array($check['type'],['image/jpeg','image/png','application/pdf'],true))throw new RuntimeException('Only JPEG, PNG and PDF references supported.');
  $bytes=file_get_contents($f['tmp_name']);if($check['type']==='application/pdf' && substr($bytes,0,5)!=='%PDF-')throw new RuntimeException('Invalid PDF.');
  global $wpdb;$today=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}hpbd_ops_files WHERE owner=%d AND created>%s",get_current_user_id(),gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS)));
  if($today>=100)throw new RuntimeException('Daily reference upload limit reached.');
  // No public uploads URL. Authenticated download always returns an attachment.
  $ok=$wpdb->insert($wpdb->prefix.'hpbd_ops_files',['owner'=>get_current_user_id(),'name'=>sanitize_file_name($f['name']),'mime'=>$check['type'],'content'=>base64_encode($bytes),'created'=>current_time('mysql',true)]);
  if(!$ok)throw new RuntimeException('Could not store reference.');return ['id'=>$wpdb->insert_id,'name'=>sanitize_file_name($f['name'])];
 }
 static function file_exists($id){try{HPBD_OPS_Access::file($id);}catch(Throwable $e){return false;}global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}hpbd_ops_files WHERE id=%d",$id));}
 static function file_link($id){return wp_nonce_url(add_query_arg(['action'=>'hpbd_private_file','id'=>(int)$id],admin_url('admin-post.php')),'hpbd_file_'.$id);}
 static function download(){if(!current_user_can(HPBD_OPS_Pilot::CAP))wp_die('Access denied','',['response'=>403]);$id=absint($_GET['id']??0);check_admin_referer('hpbd_file_'.$id);global $wpdb;$f=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}hpbd_ops_files WHERE id=%d",$id),ARRAY_A);if(!$f)wp_die('Not found');try{HPBD_OPS_Access::file($id);}catch(Throwable $e){wp_die('Access denied','',['response'=>403]);}nocache_headers();header('X-Content-Type-Options: nosniff');header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.sanitize_file_name($f['name']).'"');echo base64_decode($f['content'],true);exit;}
 static function validate_settings($d){
  $queues=json_decode($d['epo_queues']??'{}',true);if(!is_array($queues) || count($queues)>500)throw new RuntimeException('Invalid ThemeComplete production mappings.');foreach($queues as $id=>$map){if(!ctype_digit((string)$id) || !is_array($map) || count($map)>100)throw new RuntimeException('Invalid product queue mapping.');foreach($map as $uid=>$queue)if(!is_string($uid) || strlen($uid)>100 || !in_array($queue,['NP','Embroidery','Engraving'],true))throw new RuntimeException('Choose an existing production queue.');}$fields=json_decode($d['fields']??'{}',true);$locations=json_decode($d['locations']??'{}',true);
  if(!is_array($fields) || !is_array($locations))throw new RuntimeException('Mappings must be JSON objects.');
  if(count($fields)>500)throw new RuntimeException('Maximum 500 product mappings.');
  foreach($fields as $id=>$rows){if(!ctype_digit((string)$id) || !is_array($rows) || count($rows)>20)throw new RuntimeException('Use product ID keys, with at most 20 fields each.');$seen=[];
   foreach($rows as $f){if(!is_array($f) || !preg_match('/^[a-z][a-z0-9_]{0,39}$/',$f['key']??'') || empty($f['label']) || strlen($f['label'])>100 || !in_array($f['type']??'', ['text','textarea','file'],true))throw new RuntimeException('Invalid field definition.');if(isset($seen[$f['key']]))throw new RuntimeException('Duplicate field key.');$seen[$f['key']]=true;if(!empty($f['production']) && !in_array($f['production'],['NP','Embroidery','Engraving'],true))throw new RuntimeException('Invalid production queue.');if(!empty($f['meta_key']) && (!is_string($f['meta_key']) || strlen($f['meta_key'])>100 || substr($f['meta_key'],0,1)==='_'))throw new RuntimeException('Provider metadata mapping must be a public item metadata key.');}
  }
  foreach($locations as $division=>$districts){if(!is_string($division) || !is_array($districts))throw new RuntimeException('Invalid division mapping.');foreach($districts as $district=>$thanas){if(!is_string($district) || !is_array($thanas))throw new RuntimeException('Invalid district mapping.');foreach($thanas as $v)if(!is_string($v) || strlen($v)>150)throw new RuntimeException('Invalid thana name.');}}
  return ['fullscreen'=>!empty($d['fullscreen']),'fields'=>$fields,'epo_queues'=>$queues,'locations'=>$locations,'print_header'=>sanitize_text_field($d['print_header']??''),'print_footer'=>sanitize_text_field($d['print_footer']??''),'print_margin'=>max(5,min(30,(int)($d['print_margin']??12)))];
 }
 static function save(){if(!current_user_can('hpbd_ops_manage'))wp_die('Manager required','',['response'=>403]);check_admin_referer('hpbd_workspace_settings');try{$d=[];foreach(['fields','epo_queues','locations','fullscreen','print_header','print_footer','print_margin'] as $k)$d[$k]=isset($_POST[$k]) && is_string($_POST[$k])?wp_unslash($_POST[$k]):'';if(strlen($d['fields'])+strlen($d['locations'])+strlen($d['epo_queues'])>262144)throw new RuntimeException('Mappings too large.');$s=array_merge((array)get_option('hpbd_ops_workspace',[]),self::validate_settings($d));$preset=HPBD_OPS_Pilot::field('ui_preset');if($preset!==''){if(!in_array($preset,['saas','classic'],true))throw new RuntimeException('Choose a supported interface preset.');$s['ui_preset']=$preset;}$old_theme=self::theme_settings();$mode=isset($_POST['theme_mode'])?sanitize_key(wp_unslash($_POST['theme_mode'])):$old_theme['mode'];if(!in_array($mode,['dark','light','system'],true))$mode='dark';$accent=isset($_POST['theme_accent'])?sanitize_text_field(wp_unslash($_POST['theme_accent'])):$old_theme['accent'];if(!preg_match('/^#[0-9a-fA-F]{6}$/',$accent))$accent='#0d9488';$nav=isset($_POST['theme_nav'])?sanitize_key(wp_unslash($_POST['theme_nav'])):$old_theme['nav'];if(!in_array($nav,['bottom-drawer','drawer','bottom'],true))$nav='bottom-drawer';$s['theme']=['mode'=>$mode,'accent'=>$accent,'nav'=>$nav,'density'=>'comfortable','radius'=>max(4,min(24,absint($_POST['theme_radius']??$old_theme['radius']))),'sidebar_width'=>max(180,min(280,absint($_POST['theme_sidebar_width']??$old_theme['sidebar_width']))),'font_size'=>max(12,min(18,absint($_POST['theme_font_size']??$old_theme['font_size']))),'bottom_bar'=>!empty($_POST['theme_bottom_bar'])?1:0,'drawer'=>!empty($_POST['theme_drawer'])?1:0];update_option('hpbd_ops_workspace',$s,false);if(!empty($_POST['reindex']))HPBD_OPS_Search::restart();wp_safe_redirect(add_query_arg(['page'=>'hpbd-operations','hpbd_tab'=>'settings','saved'=>1],admin_url('admin.php')));exit;}catch(Throwable $e){wp_die(esc_html($e->getMessage()));}}
 static function render_settings(){
  if(!current_user_can('hpbd_ops_manage')){echo '<p>Manager permission required.</p>';return;}$s=self::settings();
  echo '<h2>Workspace settings</h2><p>Existing bridge secrets and Pathao credentials remain in their original settings.</p><form method="post" class="hpbd-form" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hpbd_workspace_settings">';wp_nonce_field('hpbd_workspace_settings');HPBD_OPS_Experience::settings();
  $t=self::theme_settings();echo '<section class="hpbd-panel hpbd-theme-customizer"><h2>Appearance / Theme Customizer</h2><p>Midnight Dark · Responsive desktop and mobile · Teal accent</p><div class="hpbd-form"><label>Theme mode<select name="theme_mode"><option value="dark" '.selected($t['mode'],'dark',false).'>Midnight Dark</option><option value="light" '.selected($t['mode'],'light',false).'>Light</option><option value="system" '.selected($t['mode'],'system',false).'>Follow device</option></select></label><label>Accent color<input type="color" name="theme_accent" value="'.esc_attr($t['accent']).'"></label><label hidden>Mobile navigation<select name="theme_nav"><option value="bottom-drawer" '.selected($t['nav'],'bottom-drawer',false).'>Bottom bar + menu drawer</option><option value="drawer" '.selected($t['nav'],'drawer',false).'>Menu drawer</option><option value="bottom" '.selected($t['nav'],'bottom',false).'>Bottom bar</option></select></label><label>Corner radius (4–24 px)<input type="number" min="4" max="24" name="theme_radius" value="'.esc_attr($t['radius']).'"></label><label>Sidebar width (180–280 px)<input type="number" min="180" max="280" name="theme_sidebar_width" value="'.esc_attr($t['sidebar_width']).'"></label><label>Base font size (12–18 px)<input type="number" min="12" max="18" name="theme_font_size" value="'.esc_attr($t['font_size']).'"></label><label hidden><input type="checkbox" name="theme_bottom_bar" value="1" '.checked($t['bottom_bar'],1,false).'> Enable mobile bottom navigation</label><label hidden><input type="checkbox" name="theme_drawer" value="1" '.checked($t['drawer'],1,false).'> Enable mobile menu drawer</label></div><p>Mobile: one top Menu drawer and a single-row header. Language, logout, density and version are in the ⋯ popup. Existing navigation preferences remain stored for compatibility. Theme changes apply after reload.</p></section>';
  echo '<label><input type="checkbox" name="fullscreen" value="1" '.checked($s['fullscreen'],true,false).'> Fullscreen private frontend portal</label>';
  foreach(['fields'=>'Additional manual customization mappings (product ID → field definitions)','epo_queues'=>'ThemeComplete production queues (product ID → provider field UID → NP / Embroidery / Engraving)','locations'=>'BD address choices (division → district → thana names)'] as $k=>$label)echo '<label class="hpbd-wide">'.esc_html($label).'<textarea rows="8" name="'.esc_attr($k).'">'.esc_textarea(wp_json_encode($s[$k],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</textarea></label>';
  echo '<p class="hpbd-wide">Example product mapping: <code>{"123":[{"key":"engraving","label":"Engraving","type":"textarea","required":true,"production":"Engraving","meta_key":"Engraving"}]}</code>. ThemeComplete 6.5 product fields load automatically through the adapter, separately from these optional manual fields. Unsupported provider rules block order creation with a reason. Production mapping example: {&quot;123&quot;:{&quot;provider-field-uid&quot;:&quot;Engraving&quot;}}. Field UIDs appear in the product options panel. No queue is guessed from a customer name or product title.</p><p class="hpbd-wide">Address example: <code>{"Dhaka":{"Dhaka":["Dhanmondi","Mirpur"]}}</code>. Supply your verified service-area dataset. Empty mapping uses editable address fields; no location is guessed.</p>';
  foreach(['print_header'=>'Print header','print_footer'=>'Print footer','print_margin'=>'Print margin (5–30 mm)'] as $k=>$label)echo '<label>'.esc_html($label).'<input name="'.esc_attr($k).'" value="'.esc_attr($s[$k]).'"></label>';
  echo '<label><input type="checkbox" name="reindex" value="1"> Restart background search reconciliation</label><button>Save settings</button></form><h3>Diagnostics</h3><p>Schema: '.esc_html(get_option('hpbd_ops_workspace_schema','not installed')).' · WooCommerce: '.esc_html(defined('WC_VERSION')?WC_VERSION:'unavailable').' · Pathao: '.(HPBD_OPS_Pathao::available()?esc_html(HPBD_OPS_Pathao::environment()):'not detected; original courier bridge retained').'</p><pre>'.esc_html(wp_json_encode(get_option('hpbd_ops_index_progress',[]),JSON_PRETTY_PRINT)).'</pre><p>Search reconciliation only updates a local index. It never changes order statuses or sends notifications. WP-Cron must run for backfill. Staff/manager permissions remain managed by WordPress Users. Refunds use the authorized WooCommerce admin interface.</p>';
 }
}
