<?php
defined('ABSPATH') || exit;
final class HPBD_OPS_Search {
 static $pending=[];static $pending_woo=[];
 static function boot(){
  add_action('shutdown',[__CLASS__,'flush']);
  add_action('woocommerce_after_order_object_save',[__CLASS__,'after_woo'],30);
  add_action('woocommerce_order_note_added',[__CLASS__,'note'],30,2);
  add_action('woocommerce_delete_order',[__CLASS__,'remove_woo']);add_action('woocommerce_trash_order',[__CLASS__,'remove_woo']);
  add_action('added_post_meta',[__CLASS__,'meta'],30,4);add_action('updated_post_meta',[__CLASS__,'meta'],30,4);add_action('deleted_post',[__CLASS__,'remove_ops']);
  add_action('hpbd_ops_reconcile',[__CLASS__,'reconcile']);
 }
 static function after_woo($o){if(is_a($o,'WC_Order') && $o->get_id())self::$pending_woo[$o->get_id()]=true;}
 static function note($note,$o){if(is_a($o,'WC_Order') && $o->get_id())self::$pending_woo[$o->get_id()]=true;}
 static function table(){global $wpdb;return $wpdb->prefix.'hpbd_ops_search';}
 static function schedule(){if(!wp_next_scheduled('hpbd_ops_reconcile'))wp_schedule_single_event(time()+30,'hpbd_ops_reconcile');}
 static function restart(){update_option('hpbd_ops_index_progress',['kind'=>'ops','page'=>1,'state'=>'queued'],false);self::schedule();}
 static function remove_woo($id){global $wpdb;$wpdb->delete(self::table(),['entity'=>'wc:'.(int)$id]);HPBD_OPS_Customization::remove('wc:'.(int)$id);}
 static function remove_ops($id){global $wpdb;$wpdb->delete(self::table(),['entity'=>'ops:'.(int)$id]);HPBD_OPS_Customization::remove('ops:'.(int)$id);}
 static function meta($meta_id,$id,$key,$value){if(strpos($key,'hpbd_')===0 && get_post_type($id)===HPBD_OPS_Pilot::TYPE)self::$pending[(int)$id]=true;if(in_array($key,['ptc_consignment_id','ptc_status','ptc_delivery_fee'],true))self::$pending_woo[(int)$id]=true;}
 static function flush(){foreach(array_keys(self::$pending) as $id)self::ops($id);self::$pending=[];foreach(array_keys(self::$pending_woo) as $id)self::woo($id);self::$pending_woo=[];}
 static function write($row){global $wpdb;$row['updated']=current_time('mysql',true);if($wpdb->replace(self::table(),$row)===false)throw new RuntimeException('Search index write failed.');HPBD_OPS_Customization::index($row);}
 static function ops($id){
  if(get_option('hpbd_ops_workspace_schema')!=='1')return;$p=get_post($id);if(!$p || $p->post_type!==HPBD_OPS_Pilot::TYPE)return;
  $m=function($k)use($id){return get_post_meta($id,'hpbd_'.$k,true);};$linked=(int)$m('wc_order_id');if($linked && function_exists('wc_get_order') && wc_get_order($linked)){self::remove_ops($id);self::woo($linked);return;}
  $fields=[];foreach(['customer','phone','reference','products','custom_text','address','note','issue','source','state'] as $k)$fields[]=(string)$m($k);
  try{self::write(['entity'=>'ops:'.$id,'kind'=>'ops','object_id'=>$id,'label'=>$m('reference')?:'HP-TEST-'.$id,'customer'=>$m('customer'),'phone'=>$m('phone'),'source'=>$m('source'),'status'=>$m('state'),'created'=>$p->post_date_gmt?:$p->post_date,'total'=>(float)$m('amount'),'currency'=>'BDT','content'=>implode("\n",$fields)]);}catch(Throwable $e){update_option('hpbd_ops_index_error','Operations index failed for #'.$id,false);update_option('hpbd_ops_cycle_errors',1+(int)get_option('hpbd_ops_cycle_errors',0),false);}
 }
 static function woo($id){
  if(get_option('hpbd_ops_workspace_schema')!=='1' || !function_exists('wc_get_order'))return;$o=wc_get_order($id);if(!$o || $o->get_type()!=='shop_order' || $o->get_status()==='trash'){self::remove_woo($id);return;}
  $text=[$o->get_order_number(),$o->get_billing_email(),implode(' ',$o->get_address('billing')),implode(' ',$o->get_address('shipping')),$o->get_customer_note(),(string)HPBD_OPS_Pathao::meta($o,'ptc_consignment_id')];
  foreach($o->get_items() as $item){$text[]=$item->get_name();$p=$item->get_product();if($p)$text[]=$p->get_sku();foreach((array)HPBD_OPS_Orders::customization($item) as $field)if(is_array($field))$text[]=(string)($field['value']??'');foreach($item->get_formatted_meta_data() as $meta)$text[]=wp_strip_all_tags($meta->display_key.' '.$meta->display_value);}
  foreach(wc_get_order_notes(['order_id'=>$id,'limit'=>20]) as $note)$text[]=wp_strip_all_tags($note->content);
  try{self::write(['entity'=>'wc:'.$id,'kind'=>'wc','object_id'=>$id,'label'=>'#'.$o->get_order_number(),'customer'=>$o->get_formatted_billing_full_name(),'phone'=>$o->get_billing_phone(),'source'=>$o->get_meta('_hpbd_source')?:'Website','status'=>$o->get_status(),'created'=>$o->get_date_created()?gmdate('Y-m-d H:i:s',$o->get_date_created()->getTimestamp()):current_time('mysql',true),'total'=>$o->get_total(),'currency'=>$o->get_currency(),'content'=>implode("\n",$text)]);unset(self::$pending_woo[$id]);}catch(Throwable $e){update_option('hpbd_ops_index_error','Woo index failed for #'.$id,false);update_option('hpbd_ops_cycle_errors',1+(int)get_option('hpbd_ops_cycle_errors',0),false);}
 }
 static function reconcile(){
  $lock='hpbd_ops_reconcile_lock';if(!add_option($lock,time(),'',false)){if((int)get_option($lock)<time()-600)delete_option($lock);self::schedule();return;}
  $p=get_option('hpbd_ops_index_progress',['kind'=>'ops','page'=>1]);$page=max(1,(int)($p['page']??1));$kind=$p['kind']??'ops';
  try{
   if($kind==='ops' && $page===1){update_option('hpbd_ops_cycle_errors',0,false);update_option('hpbd_ops_customization_cycle_errors',0,false);}
   if($kind==='ops'){$q=new WP_Query(['post_type'=>HPBD_OPS_Pilot::TYPE,'post_status'=>'private','posts_per_page'=>40,'paged'=>$page,'orderby'=>'ID','order'=>'ASC','fields'=>'ids']);foreach($q->posts as $id)self::ops($id);$more=$page<$q->max_num_pages;if(!$more){$kind='wc';$page=0;}}
   else{if(function_exists('wc_get_orders')){$q=wc_get_orders(['type'=>'shop_order','status'=>array_keys(wc_get_order_statuses()),'limit'=>40,'page'=>$page,'paginate'=>true,'orderby'=>'ID','order'=>'ASC']);foreach($q->orders as $o)self::woo($o->get_id());$more=$page<$q->max_num_pages;}else{$more=false;}if(!$more){$kind='ops';$page=0;}}
   $complete=$kind==='ops' && $page===0;if($complete && !(int)get_option('hpbd_ops_customization_cycle_errors',0))delete_option('hpbd_ops_customization_error');if($complete && !(int)get_option('hpbd_ops_cycle_errors',0))delete_option('hpbd_ops_index_error');update_option('hpbd_ops_index_progress',['kind'=>$kind,'page'=>$page+1,'state'=>$complete?'cycle complete':'indexing','updated'=>gmdate('c')],false);wp_schedule_single_event(time()+($complete?HOUR_IN_SECONDS:30),'hpbd_ops_reconcile');
  }catch(Throwable $e){update_option('hpbd_ops_index_error','Reconciliation failed; will retry the same page.',false);self::schedule();}finally{delete_option($lock);}
 }
 static function query($args=[],$limit=30){
  global $wpdb;$w=['1=1'];$params=[];if(HPBD_OPS_Access::profile()==='moderator'){$hpos=class_exists('Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();$meta=$wpdb->prefix.($hpos?'wc_orders_meta':'postmeta');$id=$hpos?'order_id':'post_id';$w[]="kind='wc' AND object_id IN (SELECT $id FROM $meta WHERE meta_key='_hpbd_created_by' AND meta_value=%s)";$params[]=(string)get_current_user_id();}$q=trim((string)($args['q']??''));
  if($q!==''){$w[]='(label LIKE %s OR customer LIKE %s OR phone LIKE %s OR content LIKE %s OR object_id=%d)';$like='%'.$wpdb->esc_like(substr($q,0,150)).'%';array_push($params,$like,$like,$like,$like,ctype_digit($q)?(int)$q:0);}
  foreach(['kind','status','source','phone'] as $key)if(!empty($args[$key])){$w[]="$key=%s";$params[]=sanitize_text_field($args[$key]);}
  foreach(['from'=>'>=','to'=>'<='] as $k=>$op)if(!empty($args[$k]) && preg_match('/^\d{4}-\d{2}-\d{2}$/',$args[$k])){$w[]="created $op %s";$params[]=HPBD_OPS_Release::day_boundary($args[$k],$k==='to');}
  $where=implode(' AND ',$w);$table=self::table();$sql="SELECT * FROM $table WHERE $where";$count="SELECT COUNT(*) FROM $table WHERE $where";if($params){$sql=$wpdb->prepare($sql,...$params);$count=$wpdb->prepare($count,...$params);}
  $total=(int)$wpdb->get_var($count);$page=max(1,(int)($args['p']??1));$limit=max(1,min(1001,$limit));$rows=$wpdb->get_results($sql.$wpdb->prepare(' ORDER BY created DESC,entity DESC LIMIT %d OFFSET %d',$limit,($page-1)*$limit),ARRAY_A);return ['rows'=>$rows?:[],'total'=>$total,'pages'=>(int)ceil($total/$limit),'page'=>$page];
 }
 static function params(){ $a=[];foreach(['q','kind','status','source','phone','from','to','p'] as $k)$a[$k]=sanitize_text_field(wp_unslash(HPBD_OPS_Integrations::scalar($_GET,'s_'.$k)));return $a; }
 static function url($r,$base){return add_query_arg($r['kind']==='wc'?['hpbd_tab'=>'wooedit','wc_order_id'=>$r['object_id']]:['hpbd_tab'=>'edit','record_id'=>$r['object_id']],$base);}
 static function render($tab,$base){
  if($tab==='overview'){self::overview($base);return;}if($tab==='myorders'){self::my_orders();return;}$a=self::params();
  echo '<h2>'.($tab==='customers'?'Customer history':'Global order search').'</h2><p>Canonical order IDs; linked Operations records are counted once. Index updates on edits and background reconciliation. Customization, SKU, address, courier ID and recent notes are searchable where indexed.</p><form class="hpbd-filters" method="get"><input type="hidden" name="hpbd_tab" value="'.esc_attr($tab).'">';if(is_admin())echo '<input type="hidden" name="page" value="hpbd-operations">';
  HPBD_OPS_Workbench::filter('status',$a['status']);HPBD_OPS_Workbench::filter('source',$a['source']);HPBD_OPS_Workbench::filter('kind',$a['kind']);foreach(['q'=>'Search all fields','phone'=>'Exact customer phone','from'=>'From','to'=>'To'] as $k=>$label)echo '<label>'.esc_html($label).'<input '.(in_array($k,['from','to'],true)?'type="date"':'').' name="s_'.esc_attr($k).'" value="'.esc_attr($a[$k]).'"></label>';echo '<button>Search</button></form>';
  try{$r=self::query($a);}catch(Throwable $e){echo '<p role="alert">'.esc_html($e->getMessage()).'</p>';return;}echo '<div class="hpbd-panel"><div class="hpbd-panel-head"><h3>'.esc_html($r['total']).' matching orders</h3></div><div class="hpbd-table"><table><thead><tr><th>Order</th><th>Customer</th><th>Source</th><th>Status</th><th>Total</th><th>Created</th></tr></thead><tbody>';
  foreach($r['rows'] as $row){$order_label=HPBD_OPS_Access::restricted()?esc_html($row['label']):'<a href="'.esc_url(self::url($row,$base)).'">'.esc_html($row['label']).'</a>';echo '<tr><td>'.$order_label.' <small>'.esc_html($row['kind']).'</small></td><td>'.esc_html($row['customer']).'<br>'.esc_html($row['phone']).'</td><td>'.esc_html($row['source']).'</td><td>'.esc_html($row['status']).'</td><td>'.esc_html($row['currency'].' '.number_format((float)$row['total'],2)).'</td><td>'.esc_html(HPBD_OPS_Release::time($row['created'])).'</td></tr>'; }
  echo '</tbody></table></div></div>';for($p=max(1,$r['page']-2);$p<=min($r['pages'],$r['page']+2);$p++)echo '<a class="hpbd-page" href="'.esc_url(add_query_arg(['s_p'=>$p])).'">'.esc_html($p).'</a>';
 }
 static function activity($page=1){
  HPBD_OPS_Workspace::guard();$args=['type'=>'shop_order','status'=>array_keys(wc_get_order_statuses()),'limit'=>25,'page'=>max(1,(int)$page),'paginate'=>true,'orderby'=>'date','order'=>'DESC'];
  $hpos=class_exists('Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
  if($hpos)$args['meta_query']=[['key'=>'_hpbd_created_by','value'=>get_current_user_id(),'compare'=>'=']];else $args['hpbd_owner']=get_current_user_id();
  $result=wc_get_orders($args);$counts=[];
  foreach(array_keys(wc_get_order_statuses()) as $status){$count_args=$args;$count_args['status']=[$status];$count_args['limit']=1;$count_args['page']=1;$count_args['return']='ids';$counts[$status]=(int)wc_get_orders($count_args)->total;}
  return ['orders'=>$result->orders,'total'=>(int)$result->total,'pages'=>(int)$result->max_num_pages,'page'=>$args['page'],'counts'=>$counts];
 }
 static function my_orders(){
  if(!function_exists('wc_get_orders')){echo '<p>WooCommerce required.</p>';return;}
  $r=self::activity(absint($_GET['activity_page']??1));echo '<h2>My order activity</h2><p>Your created orders and their current status.</p><div class="hpbd-cards"><article><small>Total created by you</small><h2>'.esc_html($r['total']).'</h2></article>';
  foreach($r['counts'] as $status=>$n)if($n)echo '<article><small>'.esc_html(wc_get_order_status_name($status)).'</small><h2>'.esc_html($n).'</h2></article>';
  echo '</div><div class="hpbd-table"><table><thead><tr><th>Order</th><th>Customer</th><th>Status</th><th>Production</th><th>Created</th></tr></thead><tbody>';
  foreach($r['orders'] as $o)echo '<tr><td>#'.esc_html($o->get_order_number()).'</td><td>'.esc_html($o->get_formatted_billing_full_name()).'<br>'.esc_html($o->get_billing_phone()).'</td><td>'.esc_html(wc_get_order_status_name($o->get_status())).($o->get_meta('_hpbd_ops_state')?' / '.esc_html($o->get_meta('_hpbd_ops_state')):'').'</td><td>'.esc_html($o->get_meta('_hpbd_fulfillment')?:'Not started').'</td><td>'.esc_html(HPBD_OPS_Release::time($o->get_date_created(),'UTC','d/m/Y g:i a')).'</td></tr>';
  echo '</tbody></table></div>';for($page=max(1,$r['page']-2);$page<=min($r['pages'],$r['page']+2);$page++)echo '<a class="hpbd-page" href="'.esc_url(add_query_arg('activity_page',$page)).'">'.esc_html($page).'</a>';
 }
 static function overview($base){
  echo '<p><a class="hpbd-page" href="'.esc_url(add_query_arg('hpbd_tab','daily',$base)).'">Daily order processing</a> <a class="hpbd-page" href="'.esc_url(add_query_arg(['hpbd_tab'=>'production','task_mine'=>'1'],$base)).'">My tasks</a></p>';global $wpdb;$t=self::table();
  $counts=$wpdb->get_results("SELECT kind,status,COUNT(*) AS n FROM $t GROUP BY kind,status",ARRAY_A);
  $today_n=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE created >= %s", HPBD_OPS_Release::day_boundary(HPBD_OPS_Release::time(null,'UTC','Y-m-d'))));
  $pending_n=0;$ship_n=0;
  foreach((array)$counts as $c){
   $st=strtolower((string)($c['status']??''));
   if(strpos($st,'pending')!==false || strpos($st,'processing')!==false || strpos($st,'on-hold')!==false)$pending_n+=(int)$c['n'];
   if(strpos($st,'ship')!==false || strpos($st,'completed')!==false || strpos($st,'dispatch')!==false)$ship_n+=(int)$c['n'];
  }
  $spark=static function($seed){return '';};
  echo '<div class="hpbd-topbar"><h2>Overview</h2><div class="hpbd-topbar-actions"><a class="hpbd-btn hpbd-btn-ghost" href="'.esc_url(add_query_arg('hpbd_tab','search',$base)).'">Search</a><a class="hpbd-btn hpbd-btn-primary" href="'.esc_url(add_query_arg('hpbd_tab','create',$base)).'">＋ New Order</a></div></div>';
  echo '<p class="hpbd-muted">Local search-index counts; monetary reports query WooCommerce directly.</p>';
  echo '<div class="hpbd-stats">';
  echo '<article class="hpbd-stat"><div class="hpbd-stat-label">Today’s indexed</div><div class="hpbd-stat-value">'.esc_html((string)$today_n).'</div><div class="hpbd-stat-meta"><span class="hpbd-delta">Created today</span>'.$spark(1).'</div></article>';
  echo '<article class="hpbd-stat"><div class="hpbd-stat-label">Pending / processing</div><div class="hpbd-stat-value">'.esc_html((string)$pending_n).'</div><div class="hpbd-stat-meta"><span class="hpbd-delta">From index</span>'.$spark(2).'</div></article>';
  echo '<article class="hpbd-stat"><div class="hpbd-stat-label">Shipped / completed</div><div class="hpbd-stat-value">'.esc_html((string)$ship_n).'</div><div class="hpbd-stat-meta"><span class="hpbd-delta">From index</span>'.$spark(3).'</div></article>';
  if(function_exists('wc_get_orders')){
   $from=(new DateTimeImmutable('today',new DateTimeZone('Asia/Dhaka')))->getTimestamp();
   $orders=wc_get_orders(['type'=>'shop_order','date_created'=>'>='.$from,'status'=>['processing','completed'],'limit'=>201]);
   $totals=[];foreach(array_slice($orders,0,200) as $o){$c=$o->get_currency();$totals[$c]=($totals[$c]??0)+(float)$o->get_total()-(float)$o->get_total_refunded();}
   $rev='—';
   if(count($orders)<=200 && $totals){ $parts=[]; foreach($totals as $c=>$v)$parts[]=$c.' '.number_format($v,0); $rev=implode(' · ',$parts); }
   elseif(count($orders)>200)$rev='200+';
   echo '<article class="hpbd-stat"><div class="hpbd-stat-label">Revenue (today)</div><div class="hpbd-stat-value">'.esc_html($rev).'</div><div class="hpbd-stat-meta"><span class="hpbd-delta">After refunds</span>'.$spark(4).'</div></article>';
  } else {
   echo '<article class="hpbd-stat"><div class="hpbd-stat-label">Revenue (today)</div><div class="hpbd-stat-value">—</div><div class="hpbd-stat-meta"><span class="hpbd-delta">WooCommerce required</span>'.$spark(5).'</div></article>';
  }
  echo '</div>';
  echo '<div class="hpbd-panel"><div class="hpbd-panel-head"><h3>Index by kind · status</h3></div><div class="hpbd-cards">';
  if(!$counts)echo '<div class="hpbd-empty"><div class="hpbd-empty-icon">📦</div><h3>এখনো ইনডেক্সড অর্ডার নেই</h3><p>Search reconciliation চালু থাকলে কাউন্ট এখানে আসবে।</p></div>';
  else foreach($counts as $c)echo '<article><small>'.esc_html($c['kind'].' · '.$c['status']).'</small><h2>'.esc_html($c['n']).'</h2></article>';
  echo '</div></div>';
  if(function_exists('wc_get_orders')){
   if(isset($orders) && count($orders)>200)echo '<p class="hpbd-error">Over 200 qualifying orders: detailed totals intentionally hidden; use WooCommerce Analytics.</p>';
   echo '<div class="hpbd-panel"><div class="hpbd-panel-head"><h3>Low stock (first 20)</h3></div><div class="hpbd-cards">';
   $products=wc_get_products(['status'=>'publish','stock_status'=>'instock','limit'=>100,'orderby'=>'ID','order'=>'DESC']);$n=0;
   foreach($products as $p)if($p->managing_stock() && (int)$p->get_stock_quantity()<=(int)wc_get_low_stock_amount($p)){echo '<article>'.esc_html($p->get_name().' · '.$p->get_stock_quantity()).'</article>';if(++$n>=20)break;}
   if($n===0)echo '<p class="hpbd-muted" style="padding:14px">No low-stock items in the latest 100 products.</p>';
   echo '</div><p class="hpbd-muted">Low-stock check covers the 100 most recent products; use WooCommerce stock reports for the full catalog.</p></div>';
  }
  HPBD_OPS_Release::index_ui();
 }
}
