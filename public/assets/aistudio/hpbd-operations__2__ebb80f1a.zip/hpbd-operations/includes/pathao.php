<?php
/** Adapter for the user-supplied Pathao Courier 2.1.1 plugin. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Pathao {
 static function boot(){
  add_action('admin_post_hpbd_pathao_book',[__CLASS__,'book']);
  add_action('wp_ajax_hpbd_pathao_locations',[__CLASS__,'locations']);
  add_action('admin_post_hpbd_pathao_link',[__CLASS__,'link']);
  add_action('wp_ajax_create_order_to_ptc',[__CLASS__,'native_guard'],1);
  add_action('wp_ajax_create_bulk_order_to_ptc',[__CLASS__,'native_guard'],1);
 }
 static function native_guard(){if(HPBD_OPS_Access::restricted())wp_send_json_error(['message'=>'Use the authorized delivery workspace booking form.'],403);if(self::available() && !current_user_can('manage_woocommerce') && !current_user_can('edit_shop_orders') && !current_user_can(HPBD_OPS_Pilot::CAP))wp_send_json_error(['message'=>'Courier booking permission required'],403);}
 static function available(){return defined('PTC_PLUGIN_FILE') && function_exists('pt_hms_get_token') && function_exists('wc_get_order');}
 static function environment(){ $s=get_option('pt_hms_settings',[]);return is_array($s) && ($s['environment']??'live')==='staging'?'sandbox':'live'; }
 static function version(){if(!self::available() || !function_exists('get_file_data') || !defined('WP_PLUGIN_DIR'))return ''; $v=get_file_data(WP_PLUGIN_DIR.'/'.PTC_PLUGIN_FILE,['version'=>'Version']);return $v['version']??'';}
 static function supported(){return self::version()==='2.1.1';}
 static function configured(){ $s=get_option('pt_hms_settings',[]);return self::available() && self::supported() && is_array($s) && !empty($s['client_id']) && !empty($s['client_secret']); }
 static function guard(){if(HPBD_OPS_Access::restricted() && HPBD_OPS_Access::profile()!=='delivery')wp_die('Courier access denied','',['response'=>403]);if(!current_user_can(HPBD_OPS_Pilot::CAP))wp_die('Access denied','',['response'=>403]);}
 static function request($path,$payload=null){
  if(!self::configured())return new WP_Error('pathao_setup','Configure the existing Pathao Courier plugin first.');
  $token=pt_hms_get_token();if(!is_string($token) || !$token)return new WP_Error('pathao_token','Pathao login unavailable. Reconnect in Pathao settings.');
  $base=self::environment()==='sandbox'?'https://courier-api-sandbox.pathao.com':'https://api-hermes.pathao.com';
  $args=['timeout'=>25,'redirection'=>0,'limit_response_size'=>1048576,'headers'=>['Authorization'=>'Bearer '.$token,'Accept'=>'application/json','Content-Type'=>'application/json','source'=>'woocommerce']];
  if($payload!==null){$args['body']=wp_json_encode($payload);$r=wp_safe_remote_post($base.$path,$args);}else{$r=wp_safe_remote_get($base.$path,$args);}
  if(is_wp_error($r))return new WP_Error('pathao_unknown','No definitive response. Check Pathao before retrying.');
  $status=(int)wp_remote_retrieve_response_code($r);$body=json_decode(wp_remote_retrieve_body($r),true);
  if($status<200 || $status>=300 || !is_array($body))return new WP_Error('pathao_response','Pathao did not return a confirmed result. HTTP '.$status,['status'=>$status]);
  return $body;
 }
 static function list_data($kind,$parent=0){
  $paths=['stores'=>'/aladdin/api/v1/stores','cities'=>'/aladdin/api/v1/countries/1/city-list','zones'=>'/aladdin/api/v1/cities/'.absint($parent).'/zone-list','areas'=>'/aladdin/api/v1/zones/'.absint($parent).'/area-list'];
  if(!isset($paths[$kind]) || (in_array($kind,['zones','areas'],true) && !$parent))return new WP_Error('bad_location','Invalid location request');
  $r=self::request($paths[$kind]);if(is_wp_error($r))return $r;
  $list=$r['data']['data']??null;if(!is_array($list))return new WP_Error('bad_location_response','Pathao location response could not be read.');
  return $list;
 }
 static function locations(){
  self::guard();check_ajax_referer('hpbd_pathao_locations','nonce');
  $kind=sanitize_key(HPBD_OPS_Integrations::scalar($_GET,'kind'));$parent=absint(HPBD_OPS_Integrations::scalar($_GET,'parent'));
  $data=self::list_data($kind,$parent);if(is_wp_error($data))wp_send_json_error(['message'=>$data->get_error_message()],502);
  wp_send_json_success($data);
 }
 static function meta($order,$key){
  // Supplied Pathao plugin writes postmeta even when WooCommerce uses HPOS.
  $legacy=get_post_meta($order->get_id(),$key,true);return $legacy!==''?$legacy:$order->get_meta($key,true);
 }
 static function booking_state($order){
  $cid=(string)self::meta($order,'ptc_consignment_id');
  if($cid && $cid!=='-')return 'booked';
  if($cid==='-' || get_option('hpbd_pathao_lock_'.$order->get_id()))return 'pending_or_unknown';
  return 'not_booked';
 }
 static function summary($order,$base){
  if(!self::available())return '<small>Pathao plugin সক্রিয় নেই</small>';
  $state=self::booking_state($order);$cid=(string)self::meta($order,'ptc_consignment_id');$status=(string)self::meta($order,'ptc_status');$fee=self::meta($order,'ptc_delivery_fee');$fee_label=is_numeric($fee)?'<br>Delivery charge: '.esc_html((string)$fee).' BDT':'';
  if($state==='booked'){$lock=get_option('hpbd_pathao_lock_'.$order->get_id(),[]);$environment=is_array($lock)?($lock['environment']??self::environment()):self::environment();return '<strong>'.esc_html($cid).'</strong><br>'.esc_html($status?:'Booked').$fee_label.($environment==='sandbox'?'<br>Sandbox booking':'<br><a target="_blank" rel="noopener" href="'.esc_url('https://merchant.pathao.com/courier/orders/'.rawurlencode($cid)).'">Pathao merchant details</a>');}
  if($state==='pending_or_unknown')return '<span class="hpbd-error">Booking pending / result unknown. Pathao-তে যাচাই করুন; আবার Book নয়।</span>';
  if(!self::supported())return '<small>Detected Pathao version '.esc_html(self::version()?:'unknown').'; booking adapter requires reviewed 2.1.1 source.</small>';if(!self::configured())return '<small>Pathao settings সম্পূর্ণ করুন</small>';
  if(!in_array($order->get_status(),['processing','on-hold'],true))return '<small>Booking requires a reviewed processing/on-hold order.</small>';
  return '<a class="hpbd-book" href="'.esc_url(add_query_arg(['hpbd_tab'=>'pathao','wc_order_id'=>$order->get_id()],$base)).'">Book Courier</a>';
 }
 static function defaults($o){
  $shipping=trim($o->get_shipping_address_1())!=='';$prefix=$shipping?'shipping':'billing';
  $get=function($key)use($o,$prefix){$fn='get_'.$prefix.'_'.$key;return $o->$fn();};
  $name=trim($get('first_name').' '.$get('last_name'));if(!$name)$name=trim($o->get_billing_first_name().' '.$o->get_billing_last_name());
  $phone=$shipping && method_exists($o,'get_shipping_phone')?$o->get_shipping_phone():'';if(!$phone)$phone=$o->get_billing_phone();
  $phone=preg_replace('/[\s-]+/','',$phone);if(substr($phone,0,3)==='+88')$phone=substr($phone,3);
  $address=implode(', ',array_filter([$get('address_1'),$get('address_2'),$get('city'),$get('state'),$get('postcode')],function($v){return trim((string)$v)!=='';}));
  $weight=0;$unknown=false;$qty=0;$items=[];
  foreach($o->get_items() as $item){$q=(int)$item->get_quantity();$qty+=$q;$items[]=$item->get_name().' × '.$q;$product=$item->get_product();if(!$product || !$product->get_weight()){$unknown=true;continue;}$weight+=(float)wc_get_weight($product->get_weight(),'kg')*$q;}
  $collect=$o->get_payment_method()==='cod'?$o->get_total():($o->is_paid()?'0':'');
  return ['recipient_name'=>$name,'recipient_phone'=>$phone,'recipient_address'=>$address,'item_quantity'=>$qty,'item_description'=>implode("\n",$items),'item_weight'=>$unknown?'':$weight,'amount_to_collect'=>$collect];
 }
 static function validate($data,$order){
  if(!$order || $order->get_type()!=='shop_order')return new WP_Error('order','WooCommerce order not found');
  if($order->get_currency()!=='BDT')return new WP_Error('currency','Only BDT orders supported');
  if(!in_array($order->get_status(),['processing','on-hold'],true))return new WP_Error('state','Review the order and use processing/on-hold before booking.');
  foreach(['store_id','recipient_city','recipient_zone','item_quantity'] as $key)if(!ctype_digit((string)($data[$key]??'')) || (int)$data[$key]<1)return new WP_Error('field','Invalid '.$key);
  if(!preg_match('/^01[3-9][0-9]{8}$/',(string)($data['recipient_phone']??'')))return new WP_Error('phone','Enter an 11-digit BD phone');
  if(trim($data['recipient_name']??'')==='' || strlen(trim($data['recipient_address']??''))<10)return new WP_Error('address','Recipient and full address required');
  if(!is_numeric($data['item_weight']??'') || (float)$data['item_weight']<=0 || !is_finite((float)$data['item_weight']))return new WP_Error('weight','Enter total packaged weight in kg');
  if(!preg_match('/^\d{1,8}$/',(string)($data['amount_to_collect']??'')))return new WP_Error('collect','Collectable amount must be whole BDT; do not silently round.');
  if(!in_array((string)($data['delivery_type']??''),['48','12','24'],true) || !in_array((string)($data['item_type']??''),['1','2','3'],true))return new WP_Error('type','Invalid delivery/item type');
  $data['merchant_order_id']=(string)$order->get_id();
  foreach(['store_id','recipient_city','recipient_zone','recipient_area','item_quantity','amount_to_collect','delivery_type','item_type'] as $key)$data[$key]=(int)($data[$key]??0);
  $data['item_weight']=(float)$data['item_weight'];return $data;
 }
 static function has_id($list,$field,$id){foreach($list as $r)if(is_array($r) && (int)($r[$field]??0)===(int)$id)return true;return false;}
 static function book(){
  self::guard();check_admin_referer('hpbd_pathao_book');
  if(!self::configured())wp_die('Pathao plugin setup required');
  if(HPBD_OPS_Pilot::field('reviewed')!=='1')wp_die('Review recipient, payment, weight and courier charge consent before booking.');
  $id=absint(HPBD_OPS_Pilot::field('wc_order_id'));$order=wc_get_order($id);if(HPBD_OPS_Access::profile()==='delivery' && (!$order || $order->get_status()!=='processing'))wp_die('Only confirmed processing orders may be booked.','',['response'=>403]);
  $data=[];foreach(['recipient_name','recipient_phone','recipient_address','store_id','recipient_city','recipient_zone','recipient_area','delivery_type','item_type','item_quantity','item_weight','item_description','special_instruction','amount_to_collect'] as $key)$data[$key]=HPBD_OPS_Pilot::field($key);
  $data=self::validate($data,$order);if(is_wp_error($data))wp_die(esc_html($data->get_error_message()));
  if(self::booking_state($order)!=='not_booked')wp_die('Order already booked or awaiting reconciliation. Do not resubmit.');
  // Validate store and location hierarchy against the connected merchant, before any booking call.
  foreach([['stores',0,'store_id',$data['store_id']],['cities',0,'city_id',$data['recipient_city']],['zones',$data['recipient_city'],'zone_id',$data['recipient_zone']]] as $check){$list=self::list_data($check[0],$check[1]);if(is_wp_error($list) || !self::has_id($list,$check[2],$check[3]))wp_die('Store/location could not be verified. Refresh and retry before booking.');}
  if($data['recipient_area']){$areas=self::list_data('areas',$data['recipient_zone']);if(is_wp_error($areas) || !self::has_id($areas,'area_id',$data['recipient_area']))wp_die('Area does not match zone.');}
  $lock='hpbd_pathao_lock_'.$id;
  if(!add_option($lock,['state'=>'submitting','time'=>time(),'user'=>get_current_user_id(),'environment'=>self::environment()],'',false))wp_die('Booking already submitted. Check Pathao.');
  // Re-check after taking the lock, including bookings made from the original plugin.
  if(self::meta($order,'ptc_consignment_id')){delete_option($lock);wp_die('An existing booking was found.');}
  update_post_meta($id,'ptc_consignment_id','-');$order->update_meta_data('ptc_consignment_id','-');$order->save_meta_data();
  update_option($lock,['state'=>'unknown','time'=>time(),'user'=>get_current_user_id(),'environment'=>self::environment()],false);
  $order->add_order_note('HPBD Operations: Pathao booking submitted by user #'.get_current_user_id().' ('.self::environment().').');
  $result=self::request('/aladdin/api/v1/orders',$data);
  $cid=is_array($result)?($result['data']['consignment_id']??''):'';
  if(!is_scalar($cid) || !preg_match('/^[A-Za-z0-9_-]{1,100}$/',(string)$cid)){
   $order->add_order_note('HPBD Operations: booking result unconfirmed. Check Pathao merchant panel before any retry.');
   wp_die('Booking result is unknown/unconfirmed. Automatic retries are blocked. Check the Pathao merchant panel; do not book the same order again.');
  }
  $meta=['ptc_consignment_id'=>(string)$cid,'ptc_status'=>'pending'];
  if(isset($result['data']['delivery_fee']) && is_numeric($result['data']['delivery_fee']))$meta['ptc_delivery_fee']=$result['data']['delivery_fee'];
  foreach($meta as $key=>$value){update_post_meta($id,$key,$value);$order->update_meta_data($key,$value);}$order->save_meta_data();
  update_option($lock,['state'=>'booked','consignment_id'=>(string)$cid,'time'=>time(),'environment'=>self::environment()],false);
  $order->add_order_note('HPBD Operations: Pathao consignment '.(string)$cid.' confirmed.');
  do_action('pathao_after_send_order',$result,$data,$order);
  wp_safe_redirect(add_query_arg(['page'=>'hpbd-operations','hpbd_tab'=>'woocommerce'],admin_url('admin.php')));exit;
 }
 static function link(){
  if(!current_user_can('hpbd_ops_manage'))wp_die('Manager required','',['response'=>403]);check_admin_referer('hpbd_pathao_link');
  $record=absint(HPBD_OPS_Pilot::field('record_id'));$id=absint(HPBD_OPS_Pilot::field('wc_order_id'));
  if(get_post_type($record)!==HPBD_OPS_Pilot::TYPE || !function_exists('wc_get_order'))wp_die('Invalid Operations record');
  $order=wc_get_order($id);if(!$order || $order->get_type()!=='shop_order')wp_die('WooCommerce order not found');
  if(HPBD_OPS_Pilot::field('reviewed')!=='1')wp_die('Confirm both records represent the same order.');
  update_post_meta($record,'hpbd_wc_order_id',$id);HPBD_OPS_Integrations::audit($record,'Linked to WooCommerce order #'.$id);
  wp_safe_redirect(add_query_arg(['page'=>'hpbd-operations','hpbd_tab'=>'orders'],admin_url('admin.php')));exit;
 }
 static function record_ui($record,$base){
  if(!function_exists('wc_get_order'))return;
  $id=(int)get_post_meta($record,'hpbd_wc_order_id',true);$order=$id?wc_get_order($id):false;
  if($order){echo '<details><summary>WooCommerce #'.esc_html($order->get_order_number()).' · Pathao</summary>'.self::summary($order,$base).'</details>';}
  elseif(current_user_can('hpbd_ops_manage')){echo '<details><summary>Link existing WooCommerce order</summary><p>Reference number দিয়ে নিজে নিজে link হয় না। একই order কি না যাচাই করুন।</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hpbd_pathao_link"><input type="hidden" name="record_id" value="'.esc_attr($record).'">';wp_nonce_field('hpbd_pathao_link');echo '<label>WooCommerce internal order ID<input required type="number" min="1" name="wc_order_id"></label><label><input required type="checkbox" value="1" name="reviewed"> একই কাস্টমার, পণ্য ও অর্ডার যাচাই করেছি</label><button>Link order</button></form></details>';}
 }
 static function render(){
  if(self::available() && !self::supported()){echo '<p>Pathao version '.esc_html(self::version()?:'unknown').' requires an adapter review. This release supports the supplied 2.1.1 source; original courier bridge remains available.</p>';return;}
  if(!self::configured()){echo '<p>Pathao Courier plugin সক্রিয় করে তার settings-এ সংযোগ সম্পূর্ণ করুন। এখানে নতুন API key লাগবে না।</p>';return;}
  $id=absint(HPBD_OPS_Integrations::scalar($_GET,'wc_order_id'));$order=wc_get_order($id);
  if(!$order || $order->get_type()!=='shop_order'){echo '<p>Website orders থেকে Book Courier নির্বাচন করুন।</p>';return;}
  if(self::booking_state($order)!=='not_booked'){echo self::summary($order,admin_url('admin.php?page=hpbd-operations'));return;}
  if(HPBD_OPS_Access::profile()==='delivery' && $order->get_status()!=='processing'){echo '<p role="alert">Only confirmed processing orders may be booked.</p>';return;}$d=self::defaults($order);
  echo '<h2>Book Courier · WooCommerce #'.esc_html($order->get_order_number()).'</h2><p class="hpbd-notice">Environment: <strong>'.esc_html(strtoupper(self::environment())).'</strong>. '.(self::environment()==='live'?'Submit করলে আসল Pathao booking ও courier charges হতে পারে।':'Sandbox test booking.').'</p><p>ঠিকানা, ওজন ও Collectable amount যাচাই করুন। Advance/refund থাকলে প্রাপ্য টাকা নিজে মিলিয়ে দিন।</p>';
  echo '<form id="hpbd-pathao-form" class="hpbd-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-ajax="'.esc_url(admin_url('admin-ajax.php')).'" data-nonce="'.esc_attr(wp_create_nonce('hpbd_pathao_locations')).'"><input type="hidden" name="action" value="hpbd_pathao_book"><input type="hidden" name="wc_order_id" value="'.esc_attr($id).'">';wp_nonce_field('hpbd_pathao_book');
  foreach(['recipient_name'=>'Recipient name','recipient_phone'=>'Phone (11 digits)','recipient_address'=>'পূর্ণ ঠিকানা','item_quantity'=>'মোট item quantity','item_weight'=>'মোট packaged weight (kg)','amount_to_collect'=>'Collectable amount (পূর্ণ টাকা)','item_description'=>'Items / description'] as $key=>$label){echo '<label>'.esc_html($label);if(in_array($key,['recipient_address','item_description'],true))echo '<textarea required name="'.esc_attr($key).'">'.esc_textarea($d[$key]).'</textarea>';else echo '<input required name="'.esc_attr($key).'" value="'.esc_attr($d[$key]).'">';echo '</label>';}
  foreach(['store_id'=>'Store','recipient_city'=>'City','recipient_zone'=>'Zone','recipient_area'=>'Area (optional)'] as $key=>$label)echo '<label>'.esc_html($label).'<select name="'.esc_attr($key).'" '.($key!=='recipient_area'?'required':'').'><option value="">Select</option></select></label>';
  echo '<label>Delivery<select name="delivery_type"><option value="48">Normal</option><option value="12">On Demand</option><option value="24">Express</option></select></label><label>Item type<select name="item_type"><option value="2">Parcel</option><option value="1">Document</option><option value="3">Fragile</option></select></label><label>Special instruction<textarea name="special_instruction"></textarea></label><p id="hpbd-pathao-error" role="alert"></p><label><input required type="checkbox" name="reviewed" value="1"> অর্ডার, customization, পেমেন্ট/বকেয়া, ঠিকানা ও courier charge যাচাই করে booking অনুমোদন করছি</label><button type="submit">Confirm & Book Courier</button></form>';
  wp_enqueue_script('hpbd-pathao',plugins_url('assets/pathao.js',HPBD_OPS_FILE), [], HPBD_OPS_VERSION, true);
 }
}
