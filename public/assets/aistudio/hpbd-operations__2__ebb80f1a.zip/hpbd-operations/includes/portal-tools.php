<?php
/** Additive 0.7 portal tools. No provider actions or schema replacement. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Portal_Tools {
 static function due(){ $p=(array)get_option('hpbd_ops_index_progress',[]);$next=wp_next_scheduled('hpbd_ops_reconcile');return ($p['state']??'')!=='cycle complete' || !$next || $next<time()-600;}
 static function step($d=[]){
  HPBD_OPS_Workspace::guard();$p=(array)get_option('hpbd_ops_index_progress',[]);
  $force=($d['force']??false)===true;if(($p['state']??'')==='cycle complete' && !self::due() && !$force)return ['complete'=>true,'progress'=>$p,'error'=>((string)get_option('hpbd_ops_index_error','')?:(string)get_option('hpbd_ops_customization_error',''))];
  $key='hpbd_ops_http_index_lock';if(!add_option($key,time(),'',false)){if((int)get_option($key)<time()-600)delete_option($key);throw new RuntimeException('Index is busy. Resume shortly.');}
  try{$p=(array)get_option('hpbd_ops_index_progress',[]);if(($p['state']??'')==='cycle complete')HPBD_OPS_Search::restart();HPBD_OPS_Search::reconcile();$p=(array)get_option('hpbd_ops_index_progress',[]);return ['complete'=>($p['state']??'')==='cycle complete','progress'=>$p,'error'=>((string)get_option('hpbd_ops_index_error','')?:(string)get_option('hpbd_ops_customization_error',''))];}finally{delete_option($key);}
 }
 static function widget(){
  HPBD_OPS_Workspace::guard();$p=(array)get_option('hpbd_ops_index_progress',[]);echo '<div class="hpbd-index-worker" data-active="'.(self::due()?'1':'0').'"><span role="status">'.esc_html(($p['state']??'')==='cycle complete'?'Index cycle complete':'Index sync pending').'</span> <button type="button">Sync / Resume</button><small>Local index only; orders and notifications remain unchanged.</small></div>';
 }
 static function collect($a=[]){
  HPBD_OPS_Workspace::guard();foreach(['from','to','q','phone','source','status','kind'] as $key)if(isset($a[$key]) && (!is_string($a[$key]) || strlen($a[$key])>512))throw new RuntimeException('Invalid or oversized search filter.');$from=empty($a['from'])?'':HPBD_OPS_Release::day_boundary($a['from']);$to=empty($a['to'])?'':HPBD_OPS_Release::day_boundary($a['to'],true);if($from && $to && $from>$to)throw new RuntimeException('From date must not be later than To date.');
  $w=['type'=>'shop_order','limit'=>501,'return'=>'ids','status'=>function_exists('wc_get_order_statuses')?array_keys(wc_get_order_statuses()):[],'orderby'=>'ID','order'=>'DESC'];
  if($from || $to){$f=$from?strtotime($from.' UTC'):0;$t=$to?strtotime($to.' UTC'):time()+DAY_IN_SECONDS;$w['date_created']=$f.'...'.$t;}
  $ids=function_exists('wc_get_orders')?wc_get_orders($w):[];
  $q=['post_type'=>HPBD_OPS_Pilot::TYPE,'post_status'=>'private','posts_per_page'=>501,'fields'=>'ids','orderby'=>'ID','order'=>'DESC'];if($from || $to){$dq=['column'=>'post_date_gmt','inclusive'=>true];if($from)$dq['after']=$from;if($to)$dq['before']=$to;$q['date_query']=[$dq];}
  $ops=new WP_Query($q);if(count($ids)>500 || $ops->found_posts>500)throw new RuntimeException('Over 500 candidate orders in direct view. Narrow From/To dates; no incomplete batch was produced.');
  $entities=[];foreach($ids as $id)$entities[]='wc:'.(int)$id;foreach($ops->posts as $id)$entities[]='ops:'.(int)$id;$rows=[];
  foreach($entities as $entity){$d=HPBD_OPS_Print_Center::snapshot($entity);if(isset($rows[$d['entity']]))continue;$woo=strpos($d['entity'],'wc:')===0;$o=$woo?wc_get_order($d['id']):null;$p=$woo?null:get_post($d['id']);$stamp=$woo?($o->get_date_created()?$o->get_date_created()->getTimestamp():0):strtotime($p->post_date_gmt.' UTC');$utc=gmdate('Y-m-d H:i:s',$stamp);
   if(($from && $utc<$from) || ($to && $utc>$to))continue;if(!empty($a['kind']) && $a['kind']!==($woo?'wc':'ops'))continue;
   if(!empty($a['source']) && $a['source']!==$d['source'])continue;$ops_state=$woo?(string)$o->get_meta('_hpbd_ops_state'):$d['status'];if(!empty($a['status']) && !in_array($a['status'],[$d['status'],$ops_state],true))continue;
   $search=wp_json_encode($d,JSON_UNESCAPED_UNICODE);if($woo){$search.=' '.$o->get_customer_note();foreach($o->get_items() as $item){$product=$item->get_product();if($product)$search.=' '.$product->get_sku();}}
   foreach(['q'=>'','phone'=>$d['phone']] as $key=>$text){$needle=(string)($a[$key]??'');if($needle!=='' && (function_exists('mb_stripos')?mb_stripos($key==='q'?$search:$text,$needle):stripos($key==='q'?$search:$text,$needle))===false)continue 2;}
   $d['_sort']=$stamp;$rows[$d['entity']]=$d;
  }
  if(count($rows)>500)throw new RuntimeException('Over 500 distinct orders. Narrow dates.');$rows=array_values($rows);usort($rows,function($a,$b){return ($b['_sort']<=>$a['_sort'])?:strcmp($b['entity'],$a['entity']);});foreach($rows as &$row)unset($row['_sort']);unset($row);return $rows;
 }
 static function query($a,$limit=50){$all=self::collect($a);$page=max(1,(int)($a['p']??1));$rows=[];foreach(array_slice($all,($page-1)*$limit,$limit) as $d){[$kind,$id]=explode(':',$d['entity']);$rows[]=['kind'=>$kind,'object_id'=>(int)$id,'label'=>$d['label'],'entity'=>$d['entity']];}return ['rows'=>$rows,'total'=>count($all),'page'=>$page,'pages'=>(int)ceil(count($all)/$limit)];}
 static function connections(){
  HPBD_OPS_Workspace::guard();echo '<section class="hpbd-panel"><h2>Connection center</h2><p>WooCommerce uses this website directly. Existing plugin settings and bridge secrets are retained.</p><div class="hpbd-connect-grid">';
  $base=admin_url('admin.php?page=hpbd-operations');foreach(['WooCommerce'=>'wc-settings','Pathao'=>(defined('PTC_PLUGIN_SETTINGS_PAGE_TYPE')?PTC_PLUGIN_SETTINGS_PAGE_TYPE:'hpbd-operations&hpbd_tab=diagnostics'),'Meta for WooCommerce'=>'wc-facebook','Messenger / Facebook Comments'=>'hpbd-operations&hpbd_tab=connections#hpbd-bridge-settings','WhatsApp'=>'hpbd-operations&hpbd_tab=connections#hpbd-bridge-settings','AI suggestions'=>'hpbd-operations&hpbd_tab=settings'] as $name=>$target){echo '<article><h3>'.esc_html($name).'</h3><p>'.esc_html($name==='WooCommerce'?(function_exists('wc_get_orders')?'Local WooCommerce available':'WooCommerce unavailable'):($name==='Pathao'?(HPBD_OPS_Pathao::available()?'Existing adapter detected; merchant setup/delivery unverified':'Existing courier bridge available; native adapter not detected'):'Requires configured provider; opening setup does not connect an account')).'</p>';if(current_user_can('hpbd_ops_manage'))echo '<a href="'.esc_url(admin_url('admin.php?page='.$target)).'">Open setup</a>';echo '</article>';}
  echo '</div><p>Messenger/WhatsApp login requires a compatible provider and approved application. A native Meta login service is not bundled. Meta for WooCommerce catalog connection alone does not connect the inbox.</p></section><div id="hpbd-bridge-settings"></div>';
 }
 static function inbox($base){echo '<section class="hpbd-panel"><h2>Inbox connections</h2><p>Messages appear here after the existing signed bridge is configured. Delivery receipts reflect provider evidence; AI auto-replies are not enabled by this upgrade.</p><a href="'.esc_url(add_query_arg('hpbd_tab','connections',$base)).'">Messenger / WhatsApp setup</a> · <a href="'.esc_url(add_query_arg('hpbd_tab','settings',$base)).'">Staff-reviewed AI suggestions</a></section>';}
}
