<?php
/** Operations integration layer. External providers require an explicitly configured bridge. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Integrations {
 const CHANNELS=['messenger'=>'Facebook Messenger','facebook_comments'=>'Facebook comments','whatsapp'=>'WhatsApp','website_chat'=>'Website chat','payment'=>'Payment verification','courier'=>'Pathao courier','notifications'=>'Notifications'];
 static function boot(){
  add_action('rest_api_init',[__CLASS__,'routes']);
  add_action('admin_post_hpbd_ops_settings',[__CLASS__,'save_settings']);
  add_action('admin_post_hpbd_ops_reply',[__CLASS__,'reply']);
  add_action('admin_post_hpbd_ops_export',[__CLASS__,'export']);
 }
 static function table(){global $wpdb;return $wpdb->prefix.'hpbd_ops_events';}
 static function install(){
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
  $table=self::table();$collate=$wpdb->get_charset_collate();
  dbDelta("CREATE TABLE $table (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   event_key varchar(64) NOT NULL,
   channel varchar(32) NOT NULL,
   kind varchar(32) NOT NULL,
   thread_id varchar(191) NOT NULL DEFAULT '',
   sender varchar(191) NOT NULL DEFAULT '',
   body longtext NOT NULL,
   state varchar(32) NOT NULL DEFAULT 'received',
   created_at datetime NOT NULL,
   PRIMARY KEY  (id),
   UNIQUE KEY event_key (event_key),
   KEY channel_created (channel,created_at)
  ) $collate;");
  return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$wpdb->esc_like($table)))===$table;
 }
 static function audit($id,$detail){add_post_meta($id,'hpbd_audit',wp_slash(wp_json_encode(['time'=>current_time('mysql'),'utc'=>gmdate('c'),'timezone'=>function_exists('wp_timezone_string')?wp_timezone_string():'UTC','user'=>get_current_user_id(),'name'=>HPBD_OPS_Flow::name(get_current_user_id()),'detail'=>$detail])));}
 static function scalar($arr,$key,$default=''){return isset($arr[$key]) && is_scalar($arr[$key])?(string)$arr[$key]:$default;}
 static function filter_params(){
  $out=[];foreach(['hpbd_q','hpbd_state','hpbd_source','hpbd_priority','hpbd_from','hpbd_to'] as $k)$out[$k]=sanitize_text_field(wp_unslash(self::scalar($_GET,$k)));
  return $out;
 }
 static function filters($args){
  $p=self::filter_params();$meta=$args['meta_query']??[];
  foreach(['hpbd_state'=>'hpbd_state','hpbd_source'=>'hpbd_source','hpbd_priority'=>'hpbd_priority'] as $key=>$field)if($p[$key]!=='')$meta[]=['key'=>$field,'value'=>$p[$key]];
  if($p['hpbd_q']!==''){$or=['relation'=>'OR'];foreach(['customer','phone','reference','products','custom_text','address','note','issue'] as $key)$or[]=['key'=>'hpbd_'.$key,'value'=>$p['hpbd_q'],'compare'=>'LIKE'];$meta[]=$or;}
  if($meta)$args['meta_query']=array_merge(['relation'=>'AND'],$meta);
  $date=['inclusive'=>true,'column'=>'post_date_gmt'];foreach(['hpbd_from'=>'after','hpbd_to'=>'before'] as $key=>$bound){if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$p[$key])){try{$date[$bound]=HPBD_OPS_Release::day_boundary($p[$key],$bound==='before');}catch(Throwable $e){$args['post__in']=[0];}}}if(isset($date['after']) || isset($date['before']))$args['date_query']=[$date];
  return $args;
 }
 static function filter_form($base,$tab){
  $p=self::filter_params();echo '<form method="get" class="hpbd-filters">';if($tab==='orders' && self::scalar($_GET,'legacy')==='1')echo '<input type="hidden" name="legacy" value="1">';
  if(is_admin())echo '<input type="hidden" name="page" value="hpbd-operations">';
  echo '<input type="hidden" name="hpbd_tab" value="'.esc_attr($tab).'">';
  echo '<label>Search<input name="hpbd_q" value="'.esc_attr($p['hpbd_q']).'" placeholder="নাম / ফোন / Reference / পণ্য"></label>';
  foreach(['hpbd_state'=>array_merge([''],HPBD_OPS_Pilot::states()),'hpbd_source'=>array_merge([''],HPBD_OPS_Pilot::sources()),'hpbd_priority'=>['','Normal','Urgent']] as $key=>$values){echo '<label>'.esc_html(str_replace('hpbd_','',$key)).'<select name="'.esc_attr($key).'">';foreach($values as $v)echo '<option value="'.esc_attr($v).'" '.selected($p[$key],$v,false).'>'.esc_html($v?:'All').'</option>';echo '</select></label>';}
  echo '<label>From<input type="date" name="hpbd_from" value="'.esc_attr($p['hpbd_from']).'"></label><label>To<input type="date" name="hpbd_to" value="'.esc_attr($p['hpbd_to']).'"></label><button>Filter</button></form>';
  if(current_user_can('hpbd_ops_manage')){
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="hpbd-export"><input type="hidden" name="action" value="hpbd_ops_export"><input type="hidden" name="list" value="'.esc_attr($tab).'">';wp_nonce_field('hpbd_ops_export');
   foreach($p as $key=>$v)echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($v).'">';
   echo '<label><input required type="checkbox" name="approve" value="1"> এই filtered তালিকা যাচাই করে CSV export অনুমোদন করছি (সর্বোচ্চ 1000 records)</label><button>Export CSV</button></form>';
  }
 }
 static function export(){
  if(!current_user_can('hpbd_ops_manage'))wp_die('Manager permission required', '', ['response'=>403]);check_admin_referer('hpbd_ops_export');
  if(HPBD_OPS_Pilot::field('approve')!=='1')wp_die('Approval required');
  $list=HPBD_OPS_Pilot::field('list');if(!in_array($list,['orders','np','embroidery','engraving'],true))wp_die('Invalid list');
  foreach(array_keys(self::filter_params()) as $k)$_GET[$k]=HPBD_OPS_Pilot::field($k);
  $args=['post_type'=>HPBD_OPS_Pilot::TYPE,'post_status'=>'private','posts_per_page'=>1001,'orderby'=>'ID','order'=>'ASC'];
  if($list!=='orders')$args['meta_query']=[['key'=>'hpbd_custom','value'=>'"'.($list==='np'?'NP':ucfirst($list)).'"','compare'=>'LIKE']];
  $q=new WP_Query(self::filters($args));if($q->found_posts>1000)wp_die('More than 1000 orders. Narrow the date range and retry; no partial export was made.');
  nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="hpbd-'.sanitize_key($list).'-'.gmdate('Y-m-d').'.csv"');
  $f=fopen('php://output','w');fwrite($f,"\xEF\xBB\xBF");
  fputcsv($f,$list==='orders'?['Serial No.','Order ID','Customer Name','C','Product Name & Quantity']:['Serial No.','Order ID','Customer Name','Product','Customization']);
  $n=0;foreach($q->posts as $p){$m=function($k)use($p){return get_post_meta($p->ID,'hpbd_'.$k,true);};$row=[++$n,$m('reference')?:'HP-TEST-'.$p->ID,$m('customer')];$row=$list==='orders'?array_merge($row,['',$m('products')]):array_merge($row,[$m('products'),$m('custom_text')]);fputcsv($f,array_map([__CLASS__,'csv_safe'],$row));}fclose($f);exit;
 }
 static function csv_safe($value){$s=(string)$value;return preg_match('/^[\s]*[=+@\-]/u',$s)?"'".$s:$s;}
 static function config(){ $v=get_option('hpbd_ops_connectors',[]);return is_array($v)?$v:[]; }
 static function crypt($value,$decrypt=false){
  if(!function_exists('openssl_encrypt'))return false;
  $key=hash('sha256',wp_salt('auth').'hpbd-ops-bridge',true);
  if($decrypt){$data=base64_decode($value,true);if($data===false || strlen($data)<29)return false;return openssl_decrypt(substr($data,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($data,0,12),substr($data,12,16));}
  $iv=random_bytes(12);$tag='';$cipher=openssl_encrypt($value,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return $cipher===false?false:base64_encode($iv.$tag.$cipher);
 }
 static function save_settings(){
  if(!current_user_can('hpbd_ops_manage'))wp_die('Manager permission required','',['response'=>403]);check_admin_referer('hpbd_ops_settings');
  $channel=HPBD_OPS_Pilot::field('channel');if(!isset(self::CHANNELS[$channel]))wp_die('Invalid channel');
  $config=self::config();$old=$config[$channel]??[];$enabled=HPBD_OPS_Pilot::field('enabled')==='1';$url=esc_url_raw(HPBD_OPS_Pilot::field('endpoint'));
  if($url && (!wp_http_validate_url($url) || strtolower(wp_parse_url($url,PHP_URL_SCHEME))!=='https' || wp_parse_url($url,PHP_URL_USER) || wp_parse_url($url,PHP_URL_PASS)))wp_die('Use a public HTTPS bridge URL without credentials.');
  $secret=HPBD_OPS_Pilot::field('secret');$encrypted=$old['secret']??'';
  if($secret!==''){if(strlen($secret)<32 || strlen($secret)>256)wp_die('Bridge secret must be 32–256 characters');$encrypted=self::crypt($secret);if(!$encrypted)wp_die('OpenSSL encryption unavailable; connection not saved.');}
  if($enabled && (!$encrypted || !self::crypt($encrypted,true)))wp_die('A valid shared secret is required');
  $config[$channel]=['enabled'=>$enabled,'endpoint'=>$url,'secret'=>$encrypted];update_option('hpbd_ops_connectors',$config,false);
  wp_safe_redirect(add_query_arg(['page'=>'hpbd-operations','hpbd_tab'=>'connections','saved'=>1],admin_url('admin.php')));exit;
 }
 static function routes(){register_rest_route('hpbd-ops/v1','/bridge/(?P<channel>[a-z_]+)',['methods'=>'POST','permission_callback'=>[__CLASS__,'permission'],'callback'=>[__CLASS__,'receive']]);}
 static function permission($r){
  $channel=$r->get_param('channel');$c=self::config()[$channel]??[];
  if(empty($c['enabled']))return new WP_Error('disabled','Connector disabled',['status'=>403]);
  if(strlen($r->get_body())>65536)return new WP_Error('too_large','Maximum 64KB',['status'=>413]);
  $time=$r->get_header('x-hpbd-timestamp');$sig=$r->get_header('x-hpbd-signature');$secret=self::crypt($c['secret']??'',true);
  if(!ctype_digit((string)$time) || abs(time()-(int)$time)>300 || !$secret)return new WP_Error('unauthorized','Invalid authentication',['status'=>401]);
  $expected=hash_hmac('sha256',$time.'.'.$r->get_body(),$secret);
  return is_string($sig) && hash_equals($expected,$sig)?true:new WP_Error('unauthorized','Invalid authentication',['status'=>401]);
 }
 static function validate_event($data,$channel){
  if(!is_array($data))return new WP_Error('invalid','JSON object required',['status'=>400]);
  $id=self::scalar($data,'event_id');$kind=self::scalar($data,'kind');$thread=self::scalar($data,'thread_id');$body=self::scalar($data,'text');$sender=self::scalar($data,'sender');
  $expected=in_array($channel,['payment','courier','notifications'],true)?'receipt':'message';
  if(!$id || strlen($id)>191 || $kind!==$expected || !$body || strlen($body)>16000 || strlen($sender)>191 || strlen($thread)>191 || ($kind==='message' && !$thread))return new WP_Error('invalid','Invalid event fields',['status'=>400]);
  return ['event_key'=>hash('sha256',$channel.'|'.$id),'channel'=>$channel,'kind'=>$kind,'thread_id'=>sanitize_text_field($thread),'sender'=>sanitize_text_field($sender),'body'=>sanitize_textarea_field($body),'state'=>$kind==='receipt'?'review_required':'received','created_at'=>current_time('mysql',true)];
 }
 static function receive($r){
  global $wpdb;$data=self::validate_event($r->get_json_params(),$r->get_param('channel'));if(is_wp_error($data))return $data;
  $table=self::table();$previous=$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE event_key=%s",$data['event_key']));if($previous)return new WP_REST_Response(['received'=>true,'duplicate'=>true],200);
  $result=$wpdb->insert($table,$data);
  if(!$result){$previous=$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE event_key=%s",$data['event_key']));if($previous)return new WP_REST_Response(['received'=>true,'duplicate'=>true],200);return new WP_Error('storage','Could not save; retry with the same event_id',['status'=>503]);}
  return new WP_REST_Response(['received'=>true,'id'=>$wpdb->insert_id,'state'=>$data['state']],201);
 }
 static function reply(){
  global $wpdb;if(!current_user_can(HPBD_OPS_Pilot::CAP))wp_die('Access denied','',['response'=>403]);check_admin_referer('hpbd_ops_reply');
  $id=absint(HPBD_OPS_Pilot::field('event_id'));$body=HPBD_OPS_Pilot::field('reply');$token=HPBD_OPS_Pilot::field('request_id');
  if(!$body || strlen($body)>4000 || !preg_match('/^[a-f0-9-]{36}$/',$token))wp_die('Invalid reply');
  $table=self::table();$event=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id),ARRAY_A);
  if(!$event || $event['kind']!=='message')wp_die('Invalid incoming message');
  if($event['channel']==='facebook_comments')wp_die('Comment reply/DM needs the provider adapter; automatic private replies are not enabled.');
  $c=self::config()[$event['channel']]??[];$secret=self::crypt($c['secret']??'',true);
  if(empty($c['enabled']) || empty($c['endpoint']) || !$secret)wp_die('Reply bridge not configured');
  // Provider bridge must enforce its actual policy window; reception time here is not evidence of eligibility.
  $key=hash('sha256','outgoing|'.$token);if($wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE event_key=%s",$key)))wp_die('This request has already been submitted. Check Inbox history; do not resend until the provider confirms its result.');
  $payload=wp_json_encode(['event_id'=>$token,'kind'=>'reply_request','channel'=>$event['channel'],'thread_id'=>$event['thread_id'],'text'=>$body,'reply_to_event'=>$event['event_key']]);
  $ok=$wpdb->insert($table,['event_key'=>$key,'channel'=>$event['channel'],'kind'=>'reply','thread_id'=>$event['thread_id'],'sender'=>'User #'.get_current_user_id(),'body'=>$body,'state'=>'submitting','created_at'=>current_time('mysql',true)]);if(!$ok)wp_die('Could not reserve request; check history before retry.');
  $out_id=$wpdb->insert_id;$stamp=(string)time();
  $res=wp_safe_remote_post($c['endpoint'],['timeout'=>20,'redirection'=>0,'limit_response_size'=>16384,'headers'=>['Content-Type'=>'application/json','X-HPBD-Timestamp'=>$stamp,'X-HPBD-Signature'=>hash_hmac('sha256',$stamp.'.'.$payload,$secret),'Idempotency-Key'=>$token],'body'=>$payload]);
  $state='unknown';
  if(!is_wp_error($res)){$code=wp_remote_retrieve_response_code($res);$response=json_decode(wp_remote_retrieve_body($res),true);if($code>=200 && $code<300 && is_array($response) && ($response['accepted']??false)===true && ($response['event_id']??'')===$token)$state='bridge_accepted';elseif($code>=400 && $code<500)$state='rejected';}
  $wpdb->update($table,['state'=>$state],['id'=>$out_id]);
  wp_safe_redirect(add_query_arg(['page'=>'hpbd-operations','hpbd_tab'=>'inbox'],admin_url('admin.php')));exit;
 }
 static function render($tab,$base){
  if($tab==='connections'){self::connections();return;}if($tab==='inbox'){self::inbox($base);return;}
  if(!function_exists('wc_get_orders') || !function_exists('wc_get_products')){echo '<p>WooCommerce সক্রিয় নেই। Operations-এর আলাদা অর্ডার ব্যবহার করতে পারবেন।</p>';return;}
  $page=max(1,absint(self::scalar($_GET,'hpbd_p','1')));
  echo '<p class="hpbd-notice">এই WordPress-এর WooCommerce তথ্য। এই তালিকা থেকে order details খুলে অনুমোদিত পরিবর্তন করা যায়। এটি healthpointbd.com-এর তথ্য হবে শুধু সেই সাইটে ইনস্টল করলে।</p>';
  if($tab==='woocommerce'){
   echo '<h2>Website orders</h2>';
   $result=wc_get_orders(['limit'=>25,'page'=>$page,'paginate'=>true,'orderby'=>'date','order'=>'DESC','type'=>'shop_order']);
   echo '<div class="hpbd-table"><table><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment / Status</th><th>Pathao</th></tr></thead><tbody>';
   foreach($result->orders as $o){echo '<tr><td>#'.esc_html($o->get_order_number()).'<br><a href="'.esc_url(add_query_arg(['hpbd_tab'=>'wooedit','wc_order_id'=>$o->get_id()],$base)).'">Open order</a></td><td>'.esc_html(trim($o->get_billing_first_name().' '.$o->get_billing_last_name())).'<br>'.esc_html($o->get_billing_phone()).'</td><td>';foreach($o->get_items() as $item){echo '<div>'.esc_html($item->get_name().' × '.$item->get_quantity()).'</div>';foreach($item->get_formatted_meta_data() as $meta)echo '<small>'.esc_html(wp_strip_all_tags($meta->display_key)).': '.esc_html(wp_strip_all_tags($meta->display_value)).'</small><br>';}
    echo '</td><td>'.wp_kses_post(wc_price($o->get_total(),['currency'=>$o->get_currency()])).'</td><td>'.esc_html(wc_get_order_status_name($o->get_status())).'<br>'.esc_html($o->get_payment_method_title()).'<br>'.($o->is_paid()?'WooCommerce: paid':'WooCommerce: not paid').'</td><td>'.HPBD_OPS_Pathao::summary($o,$base).'</td></tr>';}
   if(!$result->orders)echo '<tr><td colspan="5">কোনো website order পাওয়া যায়নি।</td></tr>';echo '</tbody></table></div>';self::pages($base,$tab,$page,$result->max_num_pages);
  }else{
   echo '<h2>Website product catalog</h2>';$result=wc_get_products(['limit'=>24,'page'=>$page,'paginate'=>true,'status'=>'publish','orderby'=>'date','order'=>'DESC']);echo '<div class="hpbd-cards hpbd-catalog-grid">';
   foreach($result->products as $product){echo '<article>'.wp_kses_post($product->get_image('thumbnail')).'<h3>'.esc_html($product->get_name()).'</h3><p>'.wp_kses_post($product->get_price_html()).'</p><p>SKU: '.esc_html($product->get_sku()).'</p><p>'.esc_html($product->get_stock_status()).' · '.($product->managing_stock()?'Stock: '.esc_html($product->get_stock_quantity()):'Quantity not tracked').'</p><a href="'.esc_url($product->get_permalink()).'" target="_blank" rel="noopener">পণ্য / variants দেখুন</a></article>';}
   echo '</div>';if(!$result->products)echo '<p>কোনো পণ্য নেই।</p>';self::pages($base,$tab,$page,$result->max_num_pages);
  }
 }
 static function pages($base,$tab,$page,$max){echo '<p>';if($page>1)echo '<a href="'.esc_url(add_query_arg(['hpbd_tab'=>$tab,'hpbd_p'=>$page-1],$base)).'">← Previous</a> ';if($page<$max)echo '<a href="'.esc_url(add_query_arg(['hpbd_tab'=>$tab,'hpbd_p'=>$page+1],$base)).'">Next →</a>';echo '</p>';}
 static function connections(){
  HPBD_OPS_Portal_Tools::connections();
  echo '<h2>Integration setup</h2><p>WooCommerce: '.(function_exists('wc_get_orders')?'সরাসরি সংযোগ প্রস্তুত; order tools available':'ইনস্টল করা নেই').'</p><p class="hpbd-notice">নিচেরগুলো generic bridge connector, সরাসরি Meta/Pathao/payment API নয়। Provider-specific bridge service তৈরি/কনফিগার ও credentials সংযুক্ত করতে হবে। URL/key বসালেই provider যাচাই সম্পন্ন হয় না।</p>';
  if(!current_user_can('hpbd_ops_manage')){echo '<p>সংযোগ কনফিগার করতে Manager প্রয়োজন।</p>';return;}
  echo '<p>Installed Pathao adapter: '.(HPBD_OPS_Pathao::available()?'Detected; '.esc_html(HPBD_OPS_Pathao::environment()).' — existing settings reused':'Not detected; courier bridge retained').'</p>';
  $config=self::config();foreach(self::CHANNELS as $key=>$label){$c=$config[$key]??[];echo '<details class="hpbd-connector"><summary>'.esc_html($label).' — '.(!empty($c['enabled'])?'Enabled; end-to-end verification pending':'Disabled').'</summary><p>Incoming endpoint: <code>'.esc_html(rest_url('hpbd-ops/v1/bridge/'.$key)).'</code></p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hpbd_ops_settings"><input type="hidden" name="channel" value="'.esc_attr($key).'">';wp_nonce_field('hpbd_ops_settings');
   echo '<label>Outgoing bridge HTTPS URL (message replies only)<input name="endpoint" type="url" value="'.esc_attr($c['endpoint']??'').'" placeholder="https://your-bridge.example/receive"></label><label>Shared secret · 32–256 characters<input autocomplete="new-password" type="password" name="secret" placeholder="'.(!empty($c['secret'])?'Saved; blank keeps existing secret':'Set the same secret on both sides').'"></label><label><input type="checkbox" name="enabled" value="1" '.checked(!empty($c['enabled']),true,false).'> Enable this bridge</label><button>Save</button></form></details>';}
  echo '<p>Payment/courier receipts কেবল review queue-তে আসে। এগুলো payment verified, stock reserved বা courier booked হিসেবে স্বয়ংক্রিয়ভাবে ধরা হয় না। AI ও scheduled reminders এখনও নেই।</p>';
 }
 static function inbox($base){
  HPBD_OPS_Portal_Tools::inbox($base);
  global $wpdb;$page=max(1,absint(self::scalar($_GET,'hpbd_p','1')));$table=self::table();$where="kind != 'order_submit'";$event=absint(self::scalar($_GET,'inbox_event'));if($event)$where.=$wpdb->prepare(' AND id=%d',$event);$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT 25 OFFSET %d",($page-1)*25),ARRAY_A);$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $where");
  echo '<h2>Inbox / Integration receipts</h2><p>Bridge accepted মানে bridge request গ্রহণ করেছে; customer delivery নিশ্চিত নয়। Unknown হলে provider-এর ফল যাচাই ছাড়া আবার পাঠাবেন না।</p>';
  if(!$rows)echo '<p class="hpbd-notice">কোনো message/receipt আসেনি। সংযোগ ট্যাব থেকে bridge কনফিগার করতে হবে।</p>';
  foreach($rows as $row){echo '<article class="hpbd-message"><strong>'.esc_html(self::CHANNELS[$row['channel']]??$row['channel']).' · '.esc_html($row['sender']).'</strong><p>'.nl2br(esc_html($row['body'])).'</p><small>'.esc_html(HPBD_OPS_Release::time($row['created_at'])).' Asia/Dhaka · '.esc_html($row['kind'].' / '.$row['state']).'</small>';
   if($row['kind']==='message' && $row['channel']!=='facebook_comments'){echo '<details><summary>Reply via bridge</summary><p>Bridge-কে provider policy/window যাচাই করে reply পাঠাতে হবে।</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hpbd_ops_reply"><input type="hidden" name="event_id" value="'.esc_attr($row['id']).'"><input type="hidden" name="request_id" value="'.esc_attr(wp_generate_uuid4()).'">';wp_nonce_field('hpbd_ops_reply');echo '<textarea required maxlength="4000" name="reply" rows="3"></textarea><button>Submit reply request</button></form></details>';}
   echo '</article>';}
  self::pages($base,'inbox',$page,(int)ceil($total/25));
 }
}
