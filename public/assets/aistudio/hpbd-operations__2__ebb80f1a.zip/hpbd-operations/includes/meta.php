<?php
/** Local observation of the installed Meta provider; outbound sync remains owned by Meta for WooCommerce. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Meta {
 const SOURCE_VERSION='3.7.8';
 static function available(){return function_exists('facebook_for_woocommerce') && class_exists('WooCommerce\\Facebook\\Products') && class_exists('WC_Facebookcommerce');}
 static function version(){return self::available()?(string)WC_Facebookcommerce::VERSION:'';}
 static function ready(){HPBD_OPS_Workspace::guard(true);if(!self::available())throw new RuntimeException('Activate the existing Meta for WooCommerce plugin.');if(self::version()!==self::SOURCE_VERSION)throw new RuntimeException('Meta for WooCommerce '.self::version().' requires adapter review; source reviewed: 3.7.8.');}
 static function asset_id($v){return is_scalar($v) && preg_match('/^[0-9]{1,40}$/',(string)$v)?(string)$v:'';}
 static function snapshot(){
  self::ready();$plugin=facebook_for_woocommerce();$integration=$plugin->get_integration();$connection=$plugin->get_connection_handler();
  return ['version'=>self::version(),'token_saved'=>(bool)$connection->is_connected(),'catalog_id'=>self::asset_id($integration->get_product_catalog_id()),'pixel_id'=>self::asset_id($integration->get_facebook_pixel_id()),'sync_enabled'=>(bool)$integration->is_product_sync_enabled(),'remote_verified'=>false,'settings_url'=>current_user_can('manage_woocommerce')?$plugin->get_settings_url():''];
 }
 static function product($p){
  self::ready();$validator=facebook_for_woocommerce()->get_product_sync_validator($p);$reasons=[];
  if(!$validator->passes_product_sync_field_check())$reasons[]='Excluded by the provider product sync setting.';
  if(!$validator->passes_product_terms_check())$reasons[]='Excluded by provider category/tag settings.';
  $eligible=$validator->passes_all_checks();if(!$eligible && !$reasons)$reasons[]='Excluded by provider global sync, publication, visibility or language rules.';
  $price=\WooCommerce\Facebook\Products::get_product_price($p);
  return ['id'=>$p->get_id(),'name'=>$p->get_name(),'sku'=>$p->get_sku(),'type'=>$p->get_type(),'woo_price'=>$p->get_price(),'provider_regular_price'=>wc_format_decimal($price/100,2),'stock'=>$p->get_stock_status(),'sync_eligible'=>$eligible,'visible_by_local_rules'=>(bool)\WooCommerce\Facebook\Products::is_product_visible($p),'item_id'=>self::asset_id($p->get_meta(WC_Facebookcommerce_Integration::FB_PRODUCT_ITEM_ID)),'group_id'=>self::asset_id($p->get_meta(WC_Facebookcommerce_Integration::FB_PRODUCT_GROUP_ID)),'reasons'=>$reasons,'remote_verified'=>false,'edit_url'=>current_user_can('edit_post',$p->get_id())?get_edit_post_link($p->get_id(),'raw'):''];
 }
 static function catalog($q='',$page=1,$parent=0){
  self::ready();$r=HPBD_OPS_Orders::products(['q'=>$q,'page'=>$page,'parent'=>$parent]);$rows=[];foreach($r['products'] as $data){$p=wc_get_product($data['id']);if($p)$rows[]=self::product($p);}return ['rows'=>$rows,'more'=>$r['more'],'limited'=>$r['limited']];
 }
 static function render($base){
  if(!current_user_can('hpbd_ops_manage')){echo '<p>Manager permission required for Meta catalog diagnostics.</p>';return;}
  echo '<h2>Meta Catalog</h2><p>Reads the installed Meta for WooCommerce connection and product rules. Saved IDs and local eligibility do not prove that Meta accepted, approved or published a product. No API request or resync is triggered by opening this page.</p>';
  try{$s=self::snapshot();}catch(Throwable $e){echo '<p role="alert">'.esc_html($e->getMessage()).'</p>';return;}
  echo '<div class="hpbd-panel"><p>Source version: '.esc_html($s['version']).' · Access token saved: '.($s['token_saved']?'Yes — validity not checked':'No').' · Product sync setting: '.($s['sync_enabled']?'Enabled':'Disabled').'</p><p>Saved catalog ID: '.esc_html($s['catalog_id']?:'Not configured').' · Saved Pixel ID: '.esc_html($s['pixel_id']?:'Not configured').'</p><p>Remote catalog / Pixel delivery: NOT VERIFIED.</p>';
  if($s['settings_url'])echo '<a href="'.esc_url($s['settings_url']).'">Open original Meta setup / sync controls</a>';else echo '<p>An existing WooCommerce administrator must open the original Meta setup / sync controls.</p>';
  echo '</div>';$q=sanitize_text_field(wp_unslash(HPBD_OPS_Integrations::scalar($_GET,'meta_q')));$page=max(1,absint($_GET['meta_page']??1));$parent=absint($_GET['meta_parent']??0);
  echo '<form method="get" class="hpbd-filters"><input type="hidden" name="hpbd_tab" value="meta">';if(is_admin())echo '<input type="hidden" name="page" value="hpbd-operations">';echo '<label>Product title, SKU or ID<input name="meta_q" value="'.esc_attr($q).'"></label><button>Search Meta product settings</button></form>';
  try{$r=self::catalog($q,$page,$parent);}catch(Throwable $e){echo '<p role="alert">'.esc_html($e->getMessage()).'</p>';return;}
  echo '<div class="hpbd-table"><table><thead><tr><th>Woo product</th><th>Prices / stock</th><th>Provider local rules</th><th>Saved Meta IDs</th><th>Review</th></tr></thead><tbody>';
  foreach($r['rows'] as $p){echo '<tr><td>#'.esc_html($p['id']).' '.esc_html($p['name']).'<br>'.esc_html($p['sku']?:'No SKU').'</td><td>Woo current: '.esc_html($p['woo_price']).'<br>Meta regular price input: '.esc_html($p['provider_regular_price']).'<br>'.esc_html($p['stock']).'</td><td>'.($p['sync_eligible']?'Locally eligible; remote state unknown':'Excluded by local provider rules').'<br>Visibility setting: '.($p['visible_by_local_rules']?'Visible':'Hidden').'<br>'.esc_html(implode(' ',$p['reasons'])).'</td><td>Item: '.esc_html($p['item_id']?:'None saved').'<br>Group: '.esc_html($p['group_id']?:'None saved').'</td><td>';
   if($p['edit_url'])echo '<a href="'.esc_url($p['edit_url']).'">Original product editor</a> ';
   if($p['type']==='variable')echo '<a href="'.esc_url(add_query_arg(['hpbd_tab'=>'meta','meta_parent'=>$p['id'],'meta_page'=>1,'meta_q'=>''],$base)).'">View variants</a>';echo '</td></tr>';
  }echo '</tbody></table></div>';if(!$r['rows'])echo '<p>No matching published products.</p>';
  if($page>1)echo '<a href="'.esc_url(add_query_arg(['hpbd_tab'=>'meta','meta_page'=>$page-1,'meta_parent'=>$parent,'meta_q'=>$q],$base)).'">Previous</a> ';
  if($r['more'])echo '<a href="'.esc_url(add_query_arg(['hpbd_tab'=>'meta','meta_page'=>$page+1,'meta_parent'=>$parent,'meta_q'=>$q],$base)).'">Next</a>';
  if($r['limited'])echo '<p>Search limited to 100 matches; narrow title, SKU or ID.</p>';
  echo '<p>Price and stock updates continue through the original provider WooCommerce hooks. HPBD does not queue a second sync or emit another Pixel/Purchase event for staff-created orders. Provider regular-price input can differ from current sale price; Meta feed, promotion, tax and account rules determine the final remote display. Use the original provider for synchronization, account repair and API error logs. Messenger/comments/WhatsApp automation remains a separate integration.</p>';
 }
}
