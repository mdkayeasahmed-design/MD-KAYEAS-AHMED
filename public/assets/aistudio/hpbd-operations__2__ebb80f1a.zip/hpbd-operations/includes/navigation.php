<?php
defined('ABSPATH') || exit;
final class HPBD_OPS_Navigation {
 static function render($tabs,$current,$base){
  $used=[];echo '<nav class="hpbd-grouped-nav" data-hpbd-grouped="1" aria-label="Operations navigation">';
  foreach(['overview','team','create','pending','orders','daily','work','customization','production','delivery','qc'] as $key)if(isset($tabs[$key])){self::link($key,$tabs[$key],$current,$base);$used[$key]=true;}
  $groups=[
   'Order tools / অর্ডারের কাজ'=>['woocommerce','customers','catalog','inventory','print','pathao','cases','cod'],
   'Customization lists / কাজের তালিকা'=>['np','embroidery','engraving','taskprint'],
   'Team & setup / টিম ও সেটআপ'=>['messages','points','employees','teamsetup','launch','settings','help'],
   'Optional integrations / অন্যান্য সংযোগ'=>['connections','meta','inbox','diagnostics']
  ];
  foreach($groups as $label=>$keys){$available=array_values(array_filter($keys,function($key)use($tabs){return isset($tabs[$key]);}));if(!$available)continue;echo '<details class="hpbd-nav-group" '.(in_array($current,$available,true)?'open':'').'><summary>'.esc_html($label).'</summary><div class="hpbd-nav-group-links">';foreach($available as $key){self::link($key,$tabs[$key],$current,$base);$used[$key]=true;}echo '</div></details>';}
  // Aliases remain routable, while redundant or context-only links leave the main menu.
  $hidden=['new','edit','wooedit','find','search','profile','notifications','packaging','issues'];foreach($tabs as $key=>$label)if(!isset($used[$key]) && !in_array($key,$hidden,true))self::link($key,$label,$current,$base);
  echo '</nav>';
 }
 static function link($key,$label,$current,$base){if($key==='create')$label='New order / নতুন অর্ডার';echo '<a class="'.($key===$current?'active':'').'" '.($key===$current?'aria-current="page"':'').' href="'.esc_url(add_query_arg('hpbd_tab',$key,$base)).'">'.esc_html($label).'</a>';}
}
