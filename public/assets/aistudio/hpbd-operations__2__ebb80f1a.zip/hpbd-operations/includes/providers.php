<?php
/** Read existing provider configuration; never activate, reset, book or notify from diagnostics. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Providers {
 static function cities(){
  global $wc_city_select;if(!is_object($wc_city_select) || !method_exists($wc_city_select,'get_cities'))return [];$all=$wc_city_select->get_cities('BD');if(!is_array($all))return [];$states=WC()->countries->get_states('BD');$out=[];
  foreach($all as $state=>$cities)if(isset($states[$state]) && is_array($cities)){if(count($cities)>500)throw new RuntimeException('City choices exceed the reviewed limit.');foreach($cities as $c)if(is_string($c) && $c!=='' && strlen($c)<150)$out[$state][]=$c;}
  return $out;
 }
 static function validate_city($customer){$cities=self::cities();if(!$cities)return;if(empty($customer['state']) || !isset($cities[$customer['state']]) || !in_array($customer['city'],$cities[$customer['state']],true))throw new RuntimeException('Select a city/thana from the installed address provider for this district.');}
 static function shipping($rates,$package){
  if(!class_exists('WccFeeFlatShippingCity'))return $rates;
  if(!defined('WCCFEE_VERSION') || WCCFEE_VERSION!=='1.0.3')throw new RuntimeException('Shipping Rates by City needs a version-specific adapter review.');
  WC()->shipping()->load_shipping_methods();if(!class_exists('WccFee_FlatShippingCity_Method'))return $rates;$method=new WccFee_FlatShippingCity_Method();if($method->enabled!=='yes' || !$method->is_available($package))return $rates;
  global $wpdb;$table=$wpdb->prefix.'wccfee_cities';if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table)throw new RuntimeException('City shipping table is missing; configure the existing shipping plugin.');
  // Source 1.0.3 interpolates the city in SQL and uses the staff cart for quantities. Neither is safe here.
  // Read the SAME configured table using a prepared query and this reviewed order package instead.
  $rows=$wpdb->get_col($wpdb->prepare("SELECT cost FROM $table WHERE city_name=%s LIMIT 2",$package['destination']['city']));if(!$rows)return $rates;if(count($rows)!==1 || !is_numeric($rows[0]) || (float)$rows[0]<0)throw new RuntimeException('Duplicate or invalid city shipping charge; fix the existing provider configuration.');
  $cost=(float)$rows[0];if($method->get_option('qty_multi','')==='yes'){$qty=0;foreach($package['contents'] as $item)$qty+=(int)$item['quantity'];$cost*=$qty;}
  $rate=new WC_Shipping_Rate('wccfee',$method->title,$cost,[],'wccfee',0);$rates[$rate->get_id()]=$rate;return $rates;
 }
 static function preorder($p){$parent=HPBD_OPS_ThemeComplete::parent($p);foreach([$p,$parent] as $product){if(!$product)continue;if($product->get_meta('_is_pre_order')==='yes')return ['enabled'=>true,'date'=>(string)$product->get_meta('_pre_order_date')];}return ['enabled'=>false,'date'=>''];}
 static function guard_create($p){$v=self::preorder($p);if($v['enabled'])throw new RuntimeException('Pre-order product: use the existing provider checkout until its scheduling/payment/split-order workflow is verified. Release date: '.$v['date']);}
 static function charts($p){
  if(!class_exists('WPCleverWpcsc'))return [];$reflection=new ReflectionClass('WPCleverWpcsc');$h=get_file_data($reflection->getFileName(),['Version'=>'Version']);if(($h['Version']??'')!=='2.3.5')return [['title'=>'Size chart','html'=>'Size chart provider version requires review.']];
  $provider=WPCleverWpcsc::instance();$out=[];$parent=HPBD_OPS_ThemeComplete::parent($p);$ids=array_values(array_unique(array_map('absint',$provider->get_size_charts($parent->get_id()))));if(count($ids)>10)throw new RuntimeException('More than 10 size charts apply; narrow provider configuration.');
  foreach($ids as $id)if(get_post_type($id)==='wpc_size_chart' && get_post_status($id)==='publish')$out[]=['title'=>get_the_title($id),'html'=>wp_kses_post($provider->size_chart($id))];return $out;
 }
 static function product($p){return ['preorder'=>self::preorder($p),'charts'=>self::charts($p)];}
 static function facts(){
  $active=(array)get_option('active_plugins',[]);if(function_exists('get_site_option'))$active=array_values(array_unique(array_merge($active,array_keys((array)get_site_option('active_sitewide_plugins',[])))));$known=['wpc-product-size-chart'=>'2.3.5','wc-city-select'=>'1.0.10','flat-shipping-rate-by-city-for-woocommerce'=>'1.0.3','pre-orders-for-woocommerce'=>'2.3.1','facebook-for-woocommerce'=>'3.7.8','bp-custom-order-status-for-woocommerce'=>'2.1','alpha-sms'=>'1.0.19','woocommerce-tm-extra-product-options'=>'6.5'];$out=[];
  foreach($known as $slug=>$reviewed){$found='';$matched='';foreach($active as $path){$file=WP_PLUGIN_DIR.'/'.$path;if(!is_readable($file))continue;$h=get_file_data($file,['Version'=>'Version','Domain'=>'Text Domain']);if(strtok($path,'/')===$slug || ($h['Domain']??'')===$slug){$found=$h['Version']??'';$matched=$path;break;}}$out[$slug]=['active_version'=>$found?:'inactive / not identified','reviewed_source'=>$reviewed,'matched_file'=>$matched];}
  $out['area_thana']=['active'=>function_exists('techiepress_my_cities'),'source_version'=>'0.1.0'];
  return $out;
 }
 static function order_notice($o){$d=$o->get_meta('_preorder_date')?:$o->get_meta('preorder_date');if($d)echo '<p class="hpbd-panel">Provider pre-order date: '.esc_html($d).'. Scheduling and release remain managed by the existing Pre-Orders plugin.</p>';}
 static function render(){HPBD_OPS_Workspace::guard(true);echo '<h3>Installed provider connections</h3><p>Installed/active version is separate from merchant account verification.</p><details><summary>Provider versions and technical details</summary><pre>'.esc_html(wp_json_encode(self::facts(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details><p>Meta for WooCommerce retains its catalog/Pixel connection; it does not provide Messenger, comments or WhatsApp inbox automation. Alpha SMS retains its configured WooCommerce new-order/status hooks; HPBD never invokes an additional SMS send. Delivery, account configuration and duplicate behavior inside those providers still require staging verification. Custom order statuses are displayed using WooCommerce labels; unknown paid/stock meanings are not automatically mapped or changed. Pre-order creation uses the original provider checkout until its full lifecycle is verified.</p>';}
}
