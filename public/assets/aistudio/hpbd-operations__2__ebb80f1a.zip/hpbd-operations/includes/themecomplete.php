<?php
/** ThemeComplete 6.5 adapter. Uses the installed provider, never bundles or rewrites it. */
defined('ABSPATH') || exit;
final class HPBD_OPS_ThemeComplete {
 const REVIEWED_VERSION='6.5';
 static function boot(){add_filter('woocommerce_order_item_get_formatted_meta_data',[__CLASS__,'safe_display'],999,2);}
 static function safe_display($meta,$item){
  $json=$item->get_meta('_hpbd_customization');$custom=is_string($json)?json_decode($json,true):$json;if(!is_array($custom))return $meta;$labels=[];
  foreach($custom as $f)if(is_array($f) && ($f['type']??'')!=='file' && is_string($f['label']??null) && is_string($f['value']??null))$labels[$f['label']][]=$f['value'];
  // Preserve raw exact storage; render customer strings as literal text, including in provider email/order views.
  foreach($meta as $m){$key=html_entity_decode(wp_strip_all_tags((string)$m->display_key),ENT_QUOTES,'UTF-8');if(isset($labels[$key])){$m->display_key=esc_html($key);$m->display_value=nl2br(esc_html(implode("\n",$labels[$key])));}else{$m->display_key=wp_kses_post($m->display_key);$m->display_value=wp_kses_post($m->display_value);}}
  return $meta;
 }
 static function version(){if(!defined('THEMECOMPLETE_EPO_PLUGIN_FILE') || !is_readable(THEMECOMPLETE_EPO_PLUGIN_FILE))return ''; $h=get_file_data(THEMECOMPLETE_EPO_PLUGIN_FILE,['Version'=>'Version']);return $h['Version'];}
 static function available(){return function_exists('THEMECOMPLETE_EPO') && function_exists('THEMECOMPLETE_EPO_CART') && function_exists('THEMECOMPLETE_EPO_ORDER');}
 static function parent($p){return $p->is_type('variation')?wc_get_product($p->get_parent_id()):$p;}
 static function data($p){
  $parent=self::parent($p);if(!$parent)throw new RuntimeException('Product parent unavailable.');
  if(!self::available()){
   // Disabling a provider must not turn its configured products into plain, cheaper lines.
   $configured=$parent->get_meta('tm_meta') || $parent->get_meta('tm_meta_cpf');
   if(!$configured)$configured=(bool)get_posts(['post_type'=>'tm_global_cp','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','no_found_rows'=>true]);
   if($configured)throw new RuntimeException('ThemeComplete configuration exists but its plugin is inactive. Activate the existing provider before creating this order.');
   return [];
  }
  if(self::version()!==self::REVIEWED_VERSION)throw new RuntimeException('ThemeComplete version '.self::version().' needs adapter review; supported source version is 6.5.');
  $data=THEMECOMPLETE_EPO()->get_product_tm_epos($parent->get_id(),'',true,true);
  // In reviewed 6.5 this flag disables styled variation presentation, not Woo variation validity.
  // Native selected attributes/variation ID are still checked by Orders::attributes().
  if(!empty($data['local']))throw new RuntimeException('Legacy ThemeComplete Normal fields require a reviewed adapter. Use the original website workflow.');
  return $data;
 }
 static function rows($p){
  $data=self::data($p);$rows=[];$sections=[];$loop=-1;$connectors=[];
  foreach(['before','after'] as $placement)foreach(($data['global']??[]) as $priorities)foreach($priorities as $form)foreach(($form['sections']??[]) as $section){
   $sections[$section['sections_uniqid']]=$section;if(($section['sections_placement']??'before')!==$placement)continue;
   foreach(($section['elements']??[]) as $e){
    if(in_array($e['type'],THEMECOMPLETE_EPO()->element_post_types,true)){if(empty($e['connector']) || !isset($connectors[$e['connector']])){$loop++;if(!empty($e['connector']))$connectors[$e['connector']]=$loop;}$index=empty($e['connector'])?$loop:$connectors[$e['connector']];}else $index=$loop;
    $rows[]=['element'=>$e,'section'=>$section,'loop'=>$index];if(count($rows)>100)throw new RuntimeException('More than 100 product fields; use the original website workflow.');
   }
  }
  return [$rows,$sections];
 }
 static function unsupported($e){
  if(in_array($e['type'],['header','divider','variations'],true))return '';
  if(!in_array($e['type'],['textfield','textarea','select','radio','checkbox','upload'],true))return 'field type '.$e['type'];
  foreach(['connector','quantity','repeater','is_cart_fee','shipping_methods_enable','shipping_methods_disable','hide_element_value_in_order','hide_element_label_in_order','use_url'] as $k)if(!empty($e[$k]))return $k;
  foreach(['extra_multiple_choices','extra_addon_properties'] as $k)foreach((array)($e[$k]['weight']??[]) as $weight)if($weight!=='' && (float)$weight!==0.0)return 'option weight changes';
  foreach((array)($e['is_cart_fee_multiple']??[]) as $v)if($v)return 'option-level cart fee';
  $types=$e['price_rules_type']??[];$walk=function($v)use(&$walk){foreach((array)$v as $x){if(is_array($x)){if(!$walk($x))return false;}elseif(!in_array((string)$x,['','fixed'],true))return false;}return true;};
  if(!$walk($types))return 'non-fixed price formula';
  foreach(['mode','changes_product_image'] as $k)if(!empty($e[$k]) && !in_array($e[$k],['normal',''],true))return $k;
  return '';
 }
 static function input($p,$values,$qty,$attributes=[]){
  if(!is_array($values) || count($values)>100)throw new RuntimeException('Invalid product options.');$post=[];
  foreach($values as $key=>$v){if(!is_string($key) || !preg_match('/^tmcp_[a-zA-Z0-9_]+$/',$key) || !is_string($v) || strlen($v)>16000 || wp_check_invalid_utf8($v)!==$v || strpos($v,"\0")!==false)throw new RuntimeException('Invalid product option value.');$post[$key]=$v;}
  $post['quantity']=$qty;$post['product_id']=self::parent($p)->get_id();$post['variation_id']=$p->is_type('variation')?$p->get_id():0;$post['cpf_product_price']=$p->get_price();$post['tc_form_prefix']='';
  foreach($attributes as $k=>$v)$post[$k]=$v;
  return $post;
 }
 static function scope($post,$callback){
  $before=[$_POST,$_REQUEST,$_FILES];$_POST=wp_slash($post);$_REQUEST=$_POST;$_FILES=[];
  try{return $callback();}finally{[$_POST,$_REQUEST,$_FILES]=$before;}
 }
 static function queue($p,$uid){$map=HPBD_OPS_Workspace::settings()['epo_queues']??[];return $map[$p->get_id()][$uid]??($map[self::parent($p)->get_id()][$uid]??'');}
 static function describe($p,$values=[],$qty=1,$attributes=[]){
  HPBD_OPS_Workspace::guard();list($rows,$sections)=self::rows($p);if(!$rows)return ['provider'=>self::available()?'ThemeComplete 6.5':'none','fields'=>[],'issues'=>[],'schema'=>''];$post=self::input($p,$values,$qty,$attributes);
  return self::scope($post,function()use($p,$rows,$sections){$logic=new THEMECOMPLETE_EPO_Conditional_Logic_Base();$fields=[];$issues=[];
   foreach($rows as $row){$e=$row['element'];$reason=self::unsupported($e);if($reason)$issues[]=wp_strip_all_tags($e['label']?:$e['type']).': unsupported '.$reason;
    if(in_array($e['type'],['header','divider','variations'],true))continue;
    $names=THEMECOMPLETE_EPO()->get_post_names($e['options'],$e['type'],$row['loop'],'','',$e);$choices=[];$keys=array_keys((array)$e['options']);foreach($keys as $index=>$v)$choices[]=['value'=>html_entity_decode((string)$v,ENT_QUOTES,'UTF-8'),'label'=>html_entity_decode(wp_strip_all_tags((string)$e['options'][$v]),ENT_QUOTES,'UTF-8'),'name'=>$names[$index]??($names[0]??''),'price'=>self::fixed_price($e,$v)];
    $fields[]=['uid'=>$e['uniqid'],'label'=>wp_strip_all_tags((string)$e['label']),'type'=>$e['type'],'names'=>array_values(array_unique($names)),'choices'=>$choices,'required'=>!empty($e['required']),'placeholder'=>wp_strip_all_tags((string)($e['placeholder']??'')),'description'=>wp_strip_all_tags((string)($e['description']??'')),'max_chars'=>$e['max_chars']??'','accept'=>$e['type']==='upload'?implode(',',array_intersect(THEMECOMPLETE_EPO()->get_allowed_mimes(),['.jpg','.jpeg','.png','.pdf'])):'','visible'=>$logic->is_visible($e,$row['section'],$sections,''),'production'=>self::queue($p,$e['uniqid']),'supported'=>$reason===''];
   }
   // Exclude visibility from configuration fingerprint. Exact source rules are included separately.
   $hash=[];foreach($rows as $r){$e=$r['element'];unset($e['builder'],$e['original_builder']);$hash[]=[$e,$r['section']['sections_clogic']??null,$r['section']['sections_logicrules']??null];}
   return ['provider'=>'ThemeComplete 6.5','fields'=>$fields,'issues'=>array_values(array_unique($issues)),'schema'=>hash('sha256',wp_json_encode($hash))];
  });
 }
 static function fixed_price($e,$key){$value=$e['rules_filtered'][$key][0]??($e['rules_filtered'][0][0]??'');return is_scalar($value)?(string)$value:'';}
 static function inspect($d){HPBD_OPS_Workspace::guard();$p=wc_get_product(absint($d['id']??0));if(!$p || $p->get_status()!=='publish')throw new RuntimeException('Product unavailable.');return self::describe($p,$d['values']??[],max(1,min(999,(int)($d['qty']??1))),HPBD_OPS_Orders::attributes($p,$d['attributes']??[]));}
 static function prepare($p,$values,$qty,$attributes,$expected=''){
  $desc=self::describe($p,$values,$qty,$attributes);if($desc['issues'])throw new RuntimeException('ThemeComplete: '.implode('; ',$desc['issues']));if(!$desc['fields']){if($values)throw new RuntimeException('Product options are no longer configured.');return ['custom'=>[],'price'=>(float)$p->get_price(),'native'=>[],'values'=>[],'schema'=>$desc['schema']];}
  // The schema fingerprint is a freshness hint, not a reason to reject a moderator's current draft.
  // Every submitted key/value is validated below against the freshly loaded provider configuration,
  // and the returned line stores the current schema. This avoids rejecting legitimate edits while
  // retaining server-side choice, required-field, provider and pricing validation.
  // Global price replacement is deliberately outside this bounded fixed-addition adapter.
  $override=THEMECOMPLETE_EPO_DATA_STORE()->get('tm_epo_global_override_product_price');$meta=self::parent($p)->get_meta('tm_meta_cpf');if($override==='yes' || ($override!=='no' && !empty($meta['price_override'])))throw new RuntimeException('ThemeComplete base-price override requires a reviewed adapter.');
  $post=self::input($p,$values,$qty,$attributes);list($rows,$sections)=self::rows($p);
  $allowed=[];foreach($desc['fields'] as $f)foreach($f['names'] as $n)$allowed[$n]=true;foreach($values as $key=>$v)if(!isset($allowed[$key]))throw new RuntimeException('Unknown product option. Reload the product.');
  return self::scope($post,function()use($p,$values,$qty,$attributes,$post,$rows,$sections,$desc){$logic=new THEMECOMPLETE_EPO_Conditional_Logic_Base();$custom=[];$native=[];$kept=[];$extra=0;
   foreach($rows as $row){$e=$row['element'];if(in_array($e['type'],['header','divider','variations'],true) || !$logic->is_visible($e,$row['section'],$sections,''))continue;
    $names=array_values(array_unique(THEMECOMPLETE_EPO()->get_post_names($e['options'],$e['type'],$row['loop'],'','',$e)));$set=[];$has=false;
    foreach($names as $name){$v=$values[$name]??'';if($v!==''){$set[$name]=$v;$has=true;}}
    if(!$has){if(!empty($e['required']))throw new RuntimeException('Required: '.wp_strip_all_tags($e['label']));continue;}
    if($e['type']==='upload'){
     foreach($set as $name=>$v){if(!ctype_digit($v) || !HPBD_OPS_Workspace::file_exists((int)$v))throw new RuntimeException('Upload the product reference first.');global $wpdb;$file=$wpdb->get_row($wpdb->prepare("SELECT name,mime,content FROM {$wpdb->prefix}hpbd_ops_files WHERE id=%d",(int)$v),ARRAY_A);$allowed=THEMECOMPLETE_EPO()->get_allowed_mimes();if(!$file || !in_array('.'.strtolower(pathinfo($file['name'],PATHINFO_EXTENSION)),$allowed,true) || strlen(base64_decode($file['content'],true))>min(2*1024*1024,wp_max_upload_size()))throw new RuntimeException('Reference file violates the provider file type/size rules.');$price=self::fixed_price($e,0);if($price!=='' && !is_numeric($price))throw new RuntimeException('Invalid upload option price.');$extra+=(float)$price;$custom[]=self::custom($p,$e,$name,$v,'file');$kept[$name]=$v;}
     continue;
    }
    // The provider validates length/format/required choices. Own membership checks also reject forged options.
    $class='THEMECOMPLETE_EPO_FIELDS_'.$e['type'];$field=new $class();$validated=$field->validate_field($post,$e,$row['loop'],'');if(empty($validated['passed']))throw new RuntimeException('Invalid value: '.wp_strip_all_tags($e['label']));
    foreach($set as $name=>$v){
     if(in_array($e['type'],['radio','select','checkbox'],true) && !array_key_exists(esc_attr($v),(array)$e['options']))throw new RuntimeException('Unknown choice: '.wp_strip_all_tags($e['label']));
     if($e['type']==='checkbox'){$all_names=THEMECOMPLETE_EPO()->get_post_names($e['options'],$e['type'],$row['loop'],'','',$e);$pos=array_search($name,$all_names,true);$option_keys=array_keys($e['options']);if($pos===false || (string)$option_keys[$pos]!==esc_attr($v))throw new RuntimeException('Checkbox choice does not match its field.');}
     $field=new $class(self::parent($p)->get_id(),$e,true,$p->get_price(),$p->is_type('variation')?$p->get_id():0,$post);$record=$field->add_cart_item_data($name,$v);if(!is_array($record) || !isset($record['price']) || !is_numeric($record['price']))throw new RuntimeException('Provider could not price this choice.');
     $label_value=in_array($e['type'],['radio','select','checkbox'],true)?html_entity_decode(wp_strip_all_tags((string)$e['options'][esc_attr($v)]),ENT_QUOTES,'UTF-8'):$v;
     $record['value']=$label_value;$native[]=$record;$extra+=(float)$record['price'];$custom[]=self::custom($p,$e,$name,$label_value,$e['type']==='textarea'?'textarea':'text');$kept[$name]=$v;
    }
   }
   $price=(float)$p->get_price()+$extra;if(!is_finite($price) || $price<0)throw new RuntimeException('Invalid configured option total.');
   return ['custom'=>$custom,'price'=>$price,'native'=>$native,'values'=>$kept,'schema'=>$desc['schema']];
  });
 }
 static function custom($p,$e,$name,$value,$type){return ['key'=>'epo_'.substr(hash('sha256',$name),0,24),'label'=>wp_strip_all_tags($e['label']),'value'=>$value,'type'=>$type,'meta_key'=>wp_strip_all_tags($e['label']),'production'=>self::queue($p,$e['uniqid']),'required'=>!empty($e['required']),'provider'=>'themecomplete','provider_field'=>$name,'provider_uid'=>$e['uniqid']];}
 static function order_meta($item,$l){
  if(empty($l['epo']['schema']))return;$d=$l['epo'];$values=['tmcartepo'=>$d['native'],'tm_epo_product_original_price'=>wc_get_product($l['id'])->get_price(),'tm_epo_options_prices'=>$d['price']-(float)wc_get_product($l['id'])->get_price()];
  THEMECOMPLETE_EPO_ORDER()->woocommerce_checkout_create_order_line_item($item,'hpbd',$values);
  // Woo item insertion unslashes nested arrays. Slash once at this boundary, retain JSON for exact values.
  foreach($item->get_meta_data() as $m)if(in_array($m->key,['_tmcartepo_data','_tm_epo_product_original_price','_tm_epo_options_prices','_tm_epo'],true))$item->update_meta_data($m->key,wp_slash($m->value));
  $item->add_meta_data('_hpbd_epo_selection',wp_json_encode(['schema'=>$d['schema'],'values'=>$d['values'],'version'=>self::REVIEWED_VERSION]),true);
 }
 static function stored_fields($item,$existing=[]){
  $native=$item->get_meta('_tmcartepo_data');if(!is_array($native))return [];$out=[];$seen=[];foreach($existing as $f)if(!empty($f['provider_field']))$seen[$f['provider_field']]=true;$p=$item->get_product();if(!$p)return [];
  if(count($native)>100)return [['key'=>'epo_metadata_limit','label'=>'ThemeComplete metadata','value'=>'More than 100 saved option records; review this order in the provider editor.','type'=>'text','meta_key'=>'ThemeComplete metadata','production'=>'','required'=>false,'provider'=>'themecomplete']];
  foreach($native as $n){if(!is_array($n) || !is_scalar($n['value']??null) || !is_string($n['post_name']??null) || isset($seen[$n['post_name']]))continue;$seen[$n['post_name']]=true;$type=in_array($n['element']['type']??'', ['upload','multiple_file_upload'],true)?'file':'text';$uid=(string)($n['section']??'');$label=wp_strip_all_tags((string)($n['name']??'Product option'));$out[]=['key'=>'epo_'.substr(hash('sha256',$n['post_name']),0,24),'label'=>$label,'value'=>(string)$n['value'],'type'=>$type,'meta_key'=>$label,'production'=>self::queue($p,$uid),'required'=>false,'provider'=>'themecomplete','provider_field'=>$n['post_name'],'provider_uid'=>$uid,'provider_reference'=>$type==='file'];}
  return $out;
 }
}
