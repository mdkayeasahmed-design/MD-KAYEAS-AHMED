<?php
/** Shared print identity and native order invoice presentation. */
defined('ABSPATH') || exit;
final class HPBD_OPS_Print_Design {
 static function header($title,$subtitle='',$settings=[]){
  $epoch=time();$stamp=HPBD_OPS_Release::time($epoch,'UTC','d/m/Y g:i a');
  return '<header class="hpbd-print-brand"><table class="hpbd-print-brand-table" role="presentation"><colgroup><col style="width:22%"><col style="width:56%"><col style="width:22%"></colgroup><tbody><tr><td class="hpbd-print-logo"><img src="'.esc_url(plugins_url('assets/logo.jpg',HPBD_OPS_FILE)).'" alt="Health Point BD"></td><td class="hpbd-print-contact"><strong>'.esc_html($settings['print_header']??'Health Point BD').'</strong><p>Katabon Mor. Opposite The Police box,<br>3th floor, BCR Diagnostic Center<br>01831 18 00 17<br>01572 36 39 46</p></td><td class="hpbd-print-heading"><h2>'.esc_html($title).'</h2><p>'.wp_kses_post($subtitle).'</p><p class="hpbd-print-stamp"><strong>Printed:</strong> <time data-hpbd-print-time data-hpbd-epoch="'.esc_attr($epoch).'">'.esc_html($stamp).'</time></p></td></tr></tbody></table></header>';
 }
 static function money($amount,$currency){return esc_html($currency.' '.number_format((float)$amount,wc_get_price_decimals(),wc_get_price_decimal_separator(),wc_get_price_thousand_separator()));}
 static function amount_row($label,$amount,$currency,$class=''){return '<tr class="'.esc_attr($class).'"><th>'.esc_html($label).'</th><td>'.self::money($amount,$currency).'</td></tr>';}
 static function invoice($d,$settings){
  HPBD_OPS_Flow::print_guard();if(HPBD_OPS_Print_Center::cancelled($d))throw new RuntimeException('Cancelled orders cannot be printed.');$o=strpos($d['entity'],'wc:')===0?wc_get_order($d['id']):false;
  if($o && $o->has_status('cancelled'))throw new RuntimeException('Cancelled orders cannot be printed.');$date=$o && $o->get_date_created()?HPBD_OPS_Release::time($o->get_date_created(),'UTC','d/m/Y g:i a'):($d['date']?HPBD_OPS_Release::time($d['date'],wp_timezone_string(),'d/m/Y g:i a'):'Not recorded');
  $address=$d['address'];if($o){$a=$o->get_address('shipping');if(empty($a['address_1']))$a=$o->get_address('billing');$states=WC()->countries->get_states($a['country']??'');$countries=WC()->countries->get_countries();$parts=[$a['address_1']??'',$a['address_2']??'',$a['city']??'',$states[$a['state']??'']??($a['state']??''),$a['postcode']??'',$countries[$a['country']??'']??($a['country']??'')];$address=implode("\n",array_filter($parts));}
  $html=self::header('INVOICE','<strong>Invoice No.</strong> '.esc_html($d['label']).'<br><strong>Order date:</strong> '.esc_html($date),$settings);
  $seller=$o?get_userdata((int)$o->get_meta('_hpbd_created_by')):false;$seller=$seller?$seller->display_name:($o && $o->get_created_via()==='checkout'?'Online checkout':$d['source']);
  $html.='<div class="hpbd-invoice-customer"><section><h3>Customer</h3><strong>'.esc_html($d['customer']).'</strong><pre>'.esc_html($address).'</pre><p><strong>Mobile:</strong> '.esc_html($d['phone']).'</p>';
  if($d['email'])$html.='<p>'.esc_html($d['email']).'</p>';
  if($o && $o->get_customer_id())$html.='<p>Client ID: '.esc_html($o->get_customer_id()).'</p>';
  $html.='</section><section class="hpbd-invoice-sale"><p><strong>Sale by:</strong> '.esc_html($seller?:'Not recorded').'</p><p><strong>Order status:</strong> '.esc_html($o?wc_get_order_status_name($o->get_status()):$d['status']).'</p></section></div>';
  $html.='<table class="hpbd-invoice-items"><colgroup><col style="width:55%"><col style="width:10%"><col style="width:17%"><col style="width:18%"></colgroup><thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead><tbody>';
  if($o){$n=0;foreach($o->get_items() as $item){$qty=(float)$item->get_quantity();$fields=HPBD_OPS_Print_Center::item_fields($item);$known=[];$details=[];foreach($fields as $f){$known[]=$f['meta_key']??$f['label'];$value=($f['type']??'')==='file'?'Reference #'.$f['value']:$f['value'];$details[]=$f['label'].': '.$value;}foreach($item->get_formatted_meta_data() as $meta)if(!in_array($meta->key,$known,true))$details[]=wp_strip_all_tags($meta->display_key).': '.wp_strip_all_tags($meta->display_value);
    $html.='<tr><td>'.esc_html((++$n).'. '.$item->get_name());if($details)$html.='<pre class="hpbd-invoice-options">'.esc_html(implode("\n",array_unique($details))).'</pre>';
    $html.='</td><td>'.esc_html(wc_format_localized_decimal($qty)).'</td><td>'.self::money($qty?(float)$item->get_subtotal()/$qty:0,$o->get_currency()).'</td><td>'.self::money($item->get_subtotal(),$o->get_currency()).'</td></tr>';
   }}else{$html.='<tr><td><pre>'.esc_html($d['products']).'</pre></td><td colspan="3">Item prices not recorded</td></tr>';}
  $html.='</tbody></table><div class="hpbd-invoice-summary"><section><h3>Payment Details</h3><table class="hpbd-invoice-payment"><tbody>';
  if($o){$currency=$o->get_currency();$paid=$o->get_payment_method()!=='cod' && ($o->is_paid() || (bool)$o->get_date_paid());$html.='<tr><th>Method</th><td>'.esc_html($o->get_payment_method_title()?:$o->get_payment_method()).'</td></tr><tr><th>Payment status</th><td>'.($paid?'Recorded as paid':'Payment not confirmed').'</td></tr>';
   if($paid){$html.=self::amount_row('Total paid (original)',$o->get_total(),$currency).self::amount_row('Total due',0,$currency);if($o->get_date_paid())$html.='<tr><th>Paid on</th><td>'.esc_html(HPBD_OPS_Release::time($o->get_date_paid(),'UTC','d/m/Y g:i a')).'</td></tr>';}
   else $html.='<tr><th>Total paid</th><td>Not confirmed</td></tr><tr><th>Total due</th><td>Not reconciled</td></tr>';
   if($o->get_total_refunded()>0)$html.=self::amount_row('Refunded',$o->get_total_refunded(),$currency);
   if($o->get_transaction_id())$html.='<tr><th>Transaction</th><td>'.esc_html($o->get_transaction_id()).'</td></tr>';
  }else $html.='<tr><td>Payment not confirmed</td></tr>';
  $html.='</tbody></table></section><section><h3>Bill Details</h3><table class="hpbd-invoice-totals"><tbody>';
  if($o){$html.=self::amount_row('Subtotal',$o->get_subtotal(),$currency);if((float)$o->get_discount_total())$html.=self::amount_row('Discount',-$o->get_discount_total(),$currency);$html.=self::amount_row('Shipping Charges',$o->get_shipping_total(),$currency);foreach($o->get_items('fee') as $fee)$html.=self::amount_row($fee->get_name(),$fee->get_total(),$currency);if((float)$o->get_total_tax())$html.=self::amount_row('Tax',$o->get_total_tax(),$currency);$html.=self::amount_row('Total',$o->get_total(),$currency,'hpbd-invoice-grand-total');
  }else $html.='<tr class="hpbd-invoice-grand-total"><th>Total</th><td>'.esc_html($d['currency'].' '.$d['amount']).'</td></tr>';
  $html.='</tbody></table></section></div>';
  if($d['custom']){$html.='<section class="hpbd-invoice-custom"><h3>Customization instructions</h3>';foreach($d['custom'] as $q=>$texts)$html.='<pre>'.esc_html($q.":\n".implode("\n",$texts)).'</pre>';$html.='</section>';}
  if($o && $o->get_customer_note())$html.='<p><strong>Customer note:</strong> '.esc_html($o->get_customer_note()).'</p>';
  if($d['missing'])$html.='<p class="hpbd-error">Missing: '.esc_html(implode(', ',$d['missing'])).'</p>';
  $html.='<div class="hpbd-invoice-close"><div class="hpbd-invoice-signatures"><span>Customer signature</span><span>Authorized signature</span></div><footer><strong><em>Thanks for your business</em></strong><p>'.esc_html($settings['print_footer']).'</p></footer></div>';
  return $html;
 }
}
