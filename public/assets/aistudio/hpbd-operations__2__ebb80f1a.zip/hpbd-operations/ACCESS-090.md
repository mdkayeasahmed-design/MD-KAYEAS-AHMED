# 0.9.0 work profiles

| Work profile | Permitted work | Excluded |
|---|---|---|
| WordPress Administrator | Every HPBD Operations feature and staff setup | No new restriction |
| Existing Staff / Manager | Original permissions retained | Original manager gates retained |
| HPBD Order Entry Moderator | Real native Woo Pending create; own unpaid Pending customer and reviewed destination edits | Other/confirmed/paid orders, legacy Ops form, status transitions, product-line changes, finance, bulk export, integrations, global search |
| HPBD Delivery Team | Processing orders packing; reviewed courier booking; customization read and task print | Order creation, finance/status change, task edits, settings |
| HPBD Customization Team | Customization read, task create/progress/claim, exact task print | Financial order edits/create, payment/refund/confirmation, settings |

Same shortcode and dashboard URL; login redirect opens that portal for the three new roles. Admin can use Staff access setup, or WordPress Users. This is a reviewed explicit role replacement for a dedicated Operations/subscriber account; it does not remove old roles globally or reset existing accounts. Admin/self/other privileged WordPress roles cannot be changed in this form. Role changes are audited in append-only `hpbd_access_audit` user metadata. A user with multiple restricted work roles receives the most restrictive matching profile in order Moderator, Delivery, Production; Administrator takes precedence. Use one dedicated work role per account. Existing managers without native WordPress promote permissions cannot assign roles.

Authorization applies to portal tabs, workspace AJAX operations, legacy admin-post actions, private file downloads and original native Pathao AJAX booking actions. Restricted users must book through the reviewed delivery form. Both HPOS and legacy author queries use supported Woo query APIs/custom query mapping, never Woo order SQL. Ownership is native `_hpbd_created_by`; no attribution is guessed for old records. Pending access also requires unpaid/unrefunded/unpacked. After confirmation, moderator has no order detail, destination editing or notification for that order. Order financial and production/fulfillment meanings remain independent.

Delivery updates use an existing-order edit lock and revision signature; only fulfillment is accepted, only processing orders may be updated. Dispatch requires a saved supported consignment booking. A dispatched order cannot be stepped back through this limited form. No status or payment update occurs. Courier booking retains the original explicit reviewed workflow, validation and idempotency, and requires a supported/configured existing provider.

Production print for the two relevant work profiles retains exact task signatures, order-snapshot freshness, reviewed checkbox, canonical counts and 100-task batches. It grants no CSV/export manager capability. Customization lists include all canonical records by default; use All customization or NP/Embroidery/Engraving filters for known mappings, and Review for unknown fields. Filters/search use the background index; the explicitly labeled direct Website view offers unfiltered immediate native visibility. Do not mistake an unfinished/stale index for a complete batch. No task backfill or mutation occurs from viewing an order.

New options: `hpbd_ops_access_schema=1`, three additive `hpbd_ops_*` roles. No table change, deletion or rewrite of historical orders/settings; existing role permissions untouched. Unknown external plugins and target-site live credential/OAuth compatibility remain unverified. This release is an installable candidate for target staging validation, not a claim of fully verified live production compatibility.
