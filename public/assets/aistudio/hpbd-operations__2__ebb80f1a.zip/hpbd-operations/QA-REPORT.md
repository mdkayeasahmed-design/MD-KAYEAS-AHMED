# Release validation 1.5.0

- `v150-team-hpos.log`: 93 assertions; final marker verified.
- `v150-team-legacy.log`: 93 assertions; final marker verified.
- `v150-regression-hpos.log`: 77 assertions; final marker verified.
- `v150-regression-legacy.log`: 77 assertions; final marker verified.
- `v150-print-hpos.log`: 120 assertions; final marker verified.
- `v150-print-legacy.log`: 120 assertions; final marker verified.
- `v150-dom.log`: 62 assertions; final marker verified.
- `v150-edit-dom.log`: 13 assertions; final marker verified.
- `v150-team-dom.log`: 18 assertions; final marker verified.
- `v150-print-dom.log`: 29 assertions; final marker verified.

Total: 702 functional assertions. PHP8.3 syntax35 runtime files. Node syntax11 scripts.

JSDOM tests execute the actual PHP WordPress AJAX dispatcher: selected staff array, single save on double submit, exact group resolution, per-recipient visibility, private message escaping/seen, transfer journal, profile fields and header update. This is DOM behavior, not physical browser geometry or network transport measurement. Expected JSDOM location.reload-not-implemented messages do not change passing final markers.

Backend suites cover username/password/cache/authentication, creator/account identity, private complaint and message scope, manager visibility, legacy owner fields, legacy import idempotency, exact resolver, no reopen farming, cancellation ledger, no guessed website creator, insufficient/self/malformed transfers, manager journal access, ordinary history scope and contended transfer lock.

Carried-forward regressions exercise native stock hooks, edit guards, preserved provider metadata/addresses/tax, fresh revisions, per-item customization, selected printing and cancellation exclusions. Current print CSS and logo remain byte-identical to1.4.1.

Limits: no live-site install, production MySQL stock-reservation test, external SMS/provider send, physical mobile/desktop device geometry or physical A4 print test. The earlier SQLite managed-stock reservation failure is still documented and the native Woo safety guard remains enabled.
